# Authoring Talkdown Documents

Talkdown is a workflow orchestration language written in Markdown. Each document is a self-contained program that an LLM executes directly. This guide teaches you how to write them.

## What is a Talkdown Document?

A Talkdown document is a Markdown file with:
- **YAML frontmatter** that declares what the document is, what it needs, and what it produces
- **Structured sections** that tell the LLM what to do
- **Optional routing** that chains documents into multi-step workflows

The LLM reads the document, follows the instructions, and produces the specified output. No code interpreter or runtime is needed — the document IS the program.

## Document Types

### Directives

A directive is a stateless transformation — like a pure function. It takes input, does work, and produces output. No routing, no state.

Use directives for standalone tasks: summarizing text, generating ideas, transforming data, validating results.

```yaml
---
type: directive
title: "Summarize Article"
description: "Produces a structured summary of an article"
inputs:
  - name: article
    type: text
    required: true
    description: "The article to summarize"
outputs:
  - name: summary
    type: text
    description: "The structured summary"
---
```

### Steps

A step is one stage in a multi-step workflow. It has routing that determines what happens next — advance to the next step, loop back for refinement, or terminate.

```yaml
---
type: step
title: "Review Draft"
description: "Reviews a draft for accuracy and completeness"
inputs:
  - name: draft
    type: text
    required: true
    description: "The draft to review"
outputs:
  - name: review_feedback
    type: text
    description: "Review findings and verdict"
---
```

### Processes

A process is an orchestrator — it defines a workflow by listing its steps and describing how they connect. Think of it as a table of contents for a workflow.

```yaml
---
type: process
title: "Content Pipeline"
description: "Research, draft, review, and polish an article"
inputs:
  - name: topic
    type: text
    required: true
    description: "The topic to write about"
outputs:
  - name: article
    type: text
    description: "The finished article"
---
```

### Guards

A guard is a quality gate — it validates output from a previous step and decides whether the workflow advances or loops back. Guards use `## Checks` instead of `## Execution`, and `## Verdict` instead of `## Output`.

```yaml
---
type: guard
title: "Fact Check Gate"
description: "Validates all claims are supported and accurate"
inputs:
  - name: draft
    type: data
    required: true
    description: "The article draft to fact-check"
---
```

Guard routing uses `on_pass` and `on_fail` instead of conditional `if/then`:

```markdown
## Routing

- on_pass: ./03-editorial-review.md
- on_fail: ./01-draft.md
```

### Personas

A persona is a reusable identity definition. Instead of writing `## Context` in every step, define a persona once and reference it.

```yaml
---
type: persona
title: "Senior Editor"
description: "Experienced editor focused on clarity and engagement"
---
```

Steps reference a persona in their frontmatter:

```yaml
persona: ./personas/editor.md
```

### Schemas

A schema defines the exact shape of data flowing between steps. Steps reference schemas in their input/output definitions.

```yaml
---
type: schema
title: "Article"
description: "The canonical shape of a blog article"
---
```

Steps reference schemas on their inputs and outputs:

```yaml
outputs:
  - name: draft
    type: data
    schema: ./schemas/article.md
```

### Triggers and Tests

**Triggers** define when and how a workflow activates — what event fires, what data it provides, and which process to start.

**Tests** define input/expected-output pairs for validating that directives and steps behave correctly.

See the [Format Reference](format-reference.md) for complete specifications of all eight types.

## Writing Your First Directive

Let's build a directive from scratch that generates user personas for a project.

### 1. Start with Frontmatter

Define what the document is, what it needs, and what it produces:

```yaml
---
type: directive
title: "Generate User Personas"
description: "Creates user personas for a project based on its target audience"
inputs:
  - name: project_description
    type: text
    required: true
    description: "A description of the project and its goals"
  - name: target_audience
    type: text
    required: true
    description: "Who the project is for"
outputs:
  - name: personas
    type: text
    description: "A set of user personas with goals, pain points, and behaviors"
tags: [product, user-research]
---
```

### 2. Add the Title and Introduction

```markdown
# Generate User Personas

Creates detailed user personas based on a project description and target
audience. Each persona represents a distinct user archetype with specific
goals, pain points, and behaviors.
```

### 3. Write the Inputs Section

Expand on what each input should contain:

```markdown
## Inputs

- **project_description** (text, required): A description of the project
  including its purpose, key features, and value proposition. The more
  detail, the better the personas.
- **target_audience** (text, required): Who the project is designed for.
  Can be broad ("small business owners") or specific ("SaaS marketing
  managers at companies with 50-200 employees").
```

### 4. Write the Execution Section

This is where the work happens. Use numbered steps and AI blocks:

```markdown
## Execution

1. Analyze the project description to understand what the product does
2. Identify distinct user segments within the target audience
3. Generate personas that represent each segment

​```ai
Based on this project:
{{project_description}}

And this target audience:
{{target_audience}}

Generate 3-4 distinct user personas. For each persona, provide:
- **Name and Role**: A realistic name and job title/role
- **Background**: 2-3 sentences on their context
- **Goals**: What they want to achieve with this product
- **Pain Points**: What frustrates them today
- **Behaviors**: How they currently work (tools, habits, preferences)
- **Key Scenario**: One specific situation where they'd use this product
​```
```

### 5. Write the Output Section

Specify what the LLM should produce and how to format it:

```markdown
## Output

- **personas** (text): A set of 3-4 user personas.

### Output Format

For each persona, use this structure:

​```
## [Name] — [Role]

**Background:** [2-3 sentences]

**Goals:**
- [Goal 1]
- [Goal 2]

**Pain Points:**
- [Pain point 1]
- [Pain point 2]

**Behaviors:** [How they work today]

**Key Scenario:** [Specific usage situation]
​```
```

That's it — you have a complete directive.

## Building a Multi-Step Workflow

To chain documents together, you need:
1. A **process** document that defines the workflow
2. **Step** documents for each stage
3. **Routing** in each step that points to the next

### The Process Document

```markdown
---
type: process
title: "Research Pipeline"
description: "Gathers data, analyzes it, and produces a report"
inputs:
  - name: topic
    type: text
    required: true
    description: "What to research"
outputs:
  - name: report
    type: text
    description: "The final research report"
tags: [research]
---

# Research Pipeline

## Steps

| Step | Document | Description |
|------|----------|-------------|
| 1 | [Gather](./01-gather.md) | Collect relevant information |
| 2 | [Analyze](./02-analyze.md) | Analyze findings |
| 3 | [Report](./03-report.md) | Produce the final report |

## Routing

- next: ./01-gather.md
```

### Step Documents

Each step has a `## Routing` section. The simplest form:

```markdown
## Routing

- next: ./02-analyze.md
```

The last step terminates the workflow:

```markdown
## Routing

- next: none
```

## Routing Patterns

### Linear

Each step advances to the next unconditionally. Use for simple pipelines.

```
Step 1 → Step 2 → Step 3 → done
```

### Conditional Branching

Choose the next step based on the output:

```markdown
## Routing

- if: "analysis found significant issues"
  then: ./04-deep-dive.md
- if: "analysis found minor issues"
  then: ./05-summary.md
- default: ./05-summary.md
```

### Self-Loop (Iterative Refinement)

A step routes back to itself (or a previous step) when the work isn't done yet:

```markdown
## Routing

- if: "the hypothesis is well-formed and testable"
  then: ./03-mathematical-modeling.md
- default: ./02-hypothesis-generation.md
```

This is powerful for tasks that need iteration — the LLM keeps refining until it meets the criteria.

### Circular (Full Cycle)

The last step can route back to the first, creating a continuous improvement loop:

```markdown
## Routing

- if: "peer review passed with no major issues"
  then: none
- default: ./01-literature-review.md
```

## Execution Blocks

The `## Execution` section supports three kinds of blocks:

### Natural Language Steps

Numbered instructions the LLM follows in order:

```markdown
1. Read the input data carefully
2. Identify the three most important patterns
3. Rank them by significance
```

### AI Blocks

Self-contained prompts fenced with ` ```ai `. Use `{{variable}}` to inject inputs:

~~~markdown
```ai
Given this data:
{{input_data}}

Generate a summary focusing on trends and anomalies.
```
~~~

AI blocks are the primary execution mechanism. Write them as clear, well-structured prompts.

### Code Blocks

Standard fenced code blocks with a language identifier. The LLM runs them if it has tool-use capability:

```python
import json
data = json.loads(raw_input)
results = [item for item in data if item["score"] > 0.8]
```

### Mixing Blocks

Blocks process in document order. Each block's output feeds the next:

```markdown
## Execution

1. Parse the input data

​```python
import csv
rows = list(csv.DictReader(data.splitlines()))
​```

2. Analyze the parsed data for patterns

​```ai
Analyze these data rows for significant patterns:
{{parsed_data}}
​```

3. Format the analysis as a report
```

## Best Practices

**Keep directives focused.** Each directive should do one thing well. If you're writing a directive that tries to do five things, split it into a workflow.

**Write clear execution steps.** The LLM follows your instructions literally. Vague instructions produce vague output. "Analyze the data" is weak; "Identify the three most significant trends and explain each with supporting evidence" is strong.

**Use structured output formats.** Define exactly what the output should look like. The `### Output Format` subsection is your best tool for getting consistent results.

**Use template variables.** Reference inputs with `{{variable_name}}` in AI blocks. This makes your documents reusable and self-documenting.

**Use relative paths.** All routing and file references should use `./filename.md`. Never use absolute paths.

**Test with different LLMs.** Talkdown is LLM-agnostic. A well-written document should produce good results with any capable model.
