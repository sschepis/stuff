# Talkdown Examples

This document walks through complete working examples and common patterns. All examples referenced here exist as files in the `examples/` directory.

## Example 1: Simple Directive — Summarize Article

The simplest Talkdown document: a directive that takes input and produces output with no routing.

**File:** `examples/summarize-article.md`

```yaml
---
type: directive
title: "Summarize Article"
description: "Produces a structured summary of an article or document"
inputs:
  - name: article
    type: text
    required: true
    description: "The full text of the article to summarize"
  - name: audience
    type: text
    required: false
    description: "Who the summary is for"
outputs:
  - name: summary
    type: text
    description: "A structured summary with key points and takeaways"
tags: [writing, analysis, summarization]
---
```

**What makes this a good directive:**
- Single, focused purpose
- Clear input/output contract
- Optional input with a sensible default
- Structured output format (Thesis, Key Points, Limitations, Takeaway)
- The `ai` block in Execution is specific about what to produce

## Example 2: Linear Workflow — Content Pipeline

A four-step process that takes a topic from research to polished article. Demonstrates linear routing and self-loops.

**Directory:** `examples/content-pipeline/`

```
process.md          → defines the workflow
01-research.md      → gathers background material
02-draft.md         → writes the first draft
03-review.md        → reviews (may loop back to 02)
04-polish.md        → final editing pass
```

**Flow:**
```
Research → Draft → Review ─┬─→ Polish → done
                           │
                           └─→ Draft (if needs revision)
```

**Key patterns demonstrated:**

### Process Orchestrator
The `process.md` defines the steps table and routes to the first step:

```markdown
## Steps

| Step | Document | Description |
|------|----------|-------------|
| 1 | [Research](./01-research.md) | Gathers key facts and sources |
| 2 | [Draft](./02-draft.md) | Writes the first draft |
| 3 | [Review](./03-review.md) | Reviews for accuracy and completeness |
| 4 | [Polish](./04-polish.md) | Final editing pass |

## Routing

- next: ./01-research.md
```

### Self-Loop for Quality
The Review step can route back to Draft if the quality isn't there:

```markdown
## Routing

- if: "the verdict is READY FOR POLISH"
  then: ./04-polish.md
- default: ./02-draft.md
```

This is the **validator pattern** — do work, check quality, loop until it passes.

### Context for Persona
The Draft and Polish steps use `## Context` to set the right mindset:

```markdown
## Context

You are an editor doing a final polish — the substance is already correct.
Focus on making every sentence as clear and engaging as possible without
changing the meaning or structure.
```

## Example 3: Multi-Step Workflow — Code Review

A three-step workflow that reviews code changes across multiple dimensions.

**Directory:** `examples/code-review-workflow/`

```
process.md                → orchestrator
01-correctness-review.md  → bugs and logic errors
02-style-review.md        → style and best practices
03-review-report.md       → synthesizes into final report
```

**Key patterns demonstrated:**

### Accumulated Context
Each step builds on the previous. The Style Review step receives both the diff AND the correctness findings, so it doesn't duplicate work:

```markdown
## Inputs

- **code_diff** (text, required): The code diff to review.
- **correctness_findings** (text, required): The correctness review from the
  previous step. Do not duplicate these findings.
```

### Synthesis Step
The final step doesn't do new analysis — it aggregates and prioritizes findings from the earlier steps into a unified report with a verdict.

## Example 4: Iterative Research Process

The `processes/researcher/` workflow demonstrates a sophisticated 8-step research cycle with self-loops and a full circular loop.

```
01-literature-review.md    → review source material
02-hypothesis-generation.md → form hypotheses (can self-loop)
03-mathematical-modeling.md → build models (can self-loop)
04-simulation-design.md    → design simulations (can self-loop)
05-self-review.md          → critique own work (can self-loop)
06-research-refinement.md  → refine based on critique (can self-loop)
07-research-presentation.md → compile into a paper (can self-loop)
08-peer-review.md          → simulate peer review → loops to 01
```

**Key patterns:**

### Self-Loops for Depth
Every step from 02 onward can route back to itself:

```markdown
## Routing

- if: "the hypothesis is well-formed, testable, and grounded in the literature"
  then: ./03-mathematical-modeling.md
- default: ./02-hypothesis-generation.md
```

The LLM keeps working on a step until it meets the quality bar, then advances.

### Full Cycle
Step 08 (Peer Review) can route back to Step 01 (Literature Review), creating a complete research iteration cycle. Each cycle deepens the research.

## Example 5: Full-Featured Workflow — Blog Editorial

The `examples/blog-editorial/` workflow demonstrates all five supporting types (persona, schema, guard, trigger, test) working together in a realistic editorial pipeline.

**Directory:** `examples/blog-editorial/`

```
process.md                → orchestrator
personas/editor.md        → senior editor persona
personas/fact-checker.md  → fact-checker persona
schemas/article.md        → article data contract
schemas/review-feedback.md → review feedback schema
01-draft.md               → writes the first draft (uses editor persona)
02-fact-check.md          → GUARD: validates factual claims
03-editorial-review.md    → editorial review (uses editor persona)
04-quality-gate.md        → GUARD: checks publication standards
05-publish.md             → final publication step
trigger.md                → event that activates the workflow
tests/test-draft.md       → test cases for the draft step
tests/test-fact-check.md  → test cases for the fact-check guard
```

**Flow:**
```
Draft → Fact Check Gate ─┬─→ Editorial Review → Quality Gate ─┬─→ Publish → done
         (guard)         │                       (guard)       │
                         └─→ Draft (on fail)                   └─→ Editorial Review (on fail)
```

**Key patterns demonstrated:**

### Personas for Context Reuse
The editor persona is defined once and referenced by both the Draft and Editorial Review steps:

```yaml
# In 01-draft.md frontmatter:
persona: ./personas/editor.md
```

The persona's identity, expertise, and behavior are automatically adopted — no need to write a `## Context` section in every step.

### Schemas for Data Contracts
The article schema defines exactly what an article looks like as it flows through the pipeline:

```yaml
# In step frontmatter:
outputs:
  - name: draft
    type: data
    schema: ./schemas/article.md
```

Every step that produces or consumes an article references the same schema, ensuring consistency.

### Guards as Quality Gates
The fact-check guard sits between Draft and Editorial Review. It validates claims, checks sources, and routes back to Draft if anything fails:

```markdown
## Routing

- on_pass: ./03-editorial-review.md
- on_fail: ./01-draft.md
```

Guards make the quality loop explicit — instead of embedding validation logic inside a step, it's a standalone, reusable document.

### Triggers for Entry Points
The trigger document defines what event starts the workflow:

```markdown
## Event

- **Source**: Content submission form, editorial meeting, or manual request
- **Condition**: A new topic is approved for publication
```

### Tests for Validation
Test documents define expected behavior with concrete cases:

```markdown
### Case 2: Article with fabricated statistics

**Input:**
- `draft`: An article containing "Studies show 87% of developers prefer..."

**Expected Output:**
- Verdict should be `fail`
- Issues should cite the specific unsupported statistic
```

## Common Patterns

### The Validator Pattern

Do work → validate → loop or advance.

```markdown
## Routing

- if: "validation passed"
  then: ./next-step.md
- default: ./current-step.md
```

Use when quality matters and you want the LLM to self-correct before advancing.

### The Refinement Pattern

Draft → review → refine → review again.

```markdown
# Step: Refine
## Routing

- if: "review found no significant issues"
  then: ./final-step.md
- default: ./draft-step.md
```

Use for creative work where iteration improves quality.

### The Accumulator Pattern

Each step adds to a growing body of work. Later steps receive all previous outputs:

```yaml
inputs:
  - name: literature_review
    type: text
    required: true
  - name: hypothesis
    type: text
    required: true
  - name: model
    type: text
    required: true
```

Use when later steps need context from the entire workflow, not just the previous step.

### The Dimensional Analysis Pattern

Analyze the same input from multiple independent angles, then synthesize:

```
Input → Dimension A analysis ─┐
Input → Dimension B analysis ──┼─→ Synthesis → Output
Input → Dimension C analysis ─┘
```

The code review example uses this — correctness and style are independent dimensions analyzed separately, then synthesized into a report.

### The Fan-Out Pattern

One input spawns multiple parallel workflows. The process orchestrator defines which workflow to use based on input characteristics:

```markdown
## Routing

- if: "input is a bug report"
  then: ./triage-bug.md
- if: "input is a feature request"
  then: ./evaluate-feature.md
- default: ./general-intake.md
```

Use for intake/classification workflows where different inputs need different processing.

### The Guard Gate Pattern

Insert a guard between steps to enforce quality standards:

```
Step A → Guard ─┬─→ Step B (on pass)
                └─→ Step A (on fail, with feedback)
```

```markdown
## Routing

- on_pass: ./next-step.md
- on_fail: ./previous-step.md
```

Guards are reusable — the same guard can be inserted at multiple points in different workflows. Unlike the validator pattern (which embeds validation in a step's routing), guards are standalone documents with explicit checks and verdicts.

### The Shared Persona Pattern

Define a persona once, reference it from many steps:

```yaml
# personas/analyst.md — defined once
type: persona
title: "Data Analyst"
```

```yaml
# Multiple steps reference it:
persona: ./personas/analyst.md
```

Use when multiple steps in a workflow should operate from the same perspective. The persona provides consistent framing without copying `## Context` sections everywhere.

### The Schema Contract Pattern

Define data shapes as schemas, reference them in inputs and outputs:

```yaml
# Step A output references a schema:
outputs:
  - name: findings
    type: data
    schema: ./schemas/finding.md

# Step B input references the same schema:
inputs:
  - name: findings
    type: data
    schema: ./schemas/finding.md
```

This creates an explicit contract between producers and consumers. If the schema changes, both sides see it.
