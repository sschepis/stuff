# Talkdown Format Reference

This is the complete specification for the Talkdown document format.

## YAML Frontmatter

Every Talkdown document begins with YAML frontmatter enclosed in `---` fences.

### Required Fields

| Field | Type | Description |
|-------|------|-------------|
| `type` | `directive` \| `step` \| `process` \| `guard` \| `persona` \| `schema` \| `trigger` \| `test` | The document type |
| `title` | string | Human-readable title |
| `description` | string | One-line purpose statement |

### Optional Fields

| Field | Type | Description |
|-------|------|-------------|
| `inputs` | array | What the document expects (see Input Schema) |
| `outputs` | array | What the document produces (see Output Schema) |
| `tags` | array of strings | For discovery and organization |

### Input Schema

Each entry in the `inputs` array:

```yaml
inputs:
  - name: input_name        # identifier, snake_case
    type: text               # text | file | data | url
    required: true           # true | false
    description: "..."       # what this input is
```

**Types:**
- `text` — free-form text content
- `file` — a file path or file contents
- `data` — structured data (JSON, CSV, etc.)
- `url` — a URL to fetch or reference

### Output Schema

Each entry in the `outputs` array:

```yaml
outputs:
  - name: output_name       # identifier, snake_case
    type: text               # text | file | data
    description: "..."       # what this output is
```

## Document Sections

Sections appear in this order. All use `##` level headings.

### Title (`# Title`)

**Required.** The document title as an H1 heading. Should match the frontmatter `title`.

### Prose Introduction

**Required.** 1-3 sentences immediately after the title describing what the document does. No heading — just body text.

### Context (`## Context`)

**Optional.** Persona, domain knowledge, or framing the LLM should adopt while processing this document. Use this to set the right mindset for execution.

```markdown
## Context

You are a senior security engineer reviewing code for vulnerabilities.
Focus on OWASP Top 10 categories and common language-specific pitfalls.
```

### Inputs (`## Inputs`)

**Required.** Detailed descriptions of each input. Format each as:

```markdown
- **input_name** (type, required/optional): Detailed description including
  expected format, constraints, and examples.
```

### Execution (`## Execution`)

**Required.** The core instructions. Contains three kinds of blocks processed in document order:

#### Natural Language Steps

Numbered instructions:

```markdown
1. Read the input data
2. Identify key patterns
3. Generate recommendations
```

#### AI Blocks

Self-contained prompts fenced with ` ```ai `:

~~~markdown
```ai
Analyze the following for {{analysis_type}}:

{{input_data}}

Provide your findings in bullet-point format.
```
~~~

**Template variables:** Use `{{variable_name}}` to reference inputs or results from previous blocks. Variable names match the `name` field in the frontmatter inputs, or names assigned in earlier execution steps.

##### Template Syntax Reference

| Syntax | Example | Description |
|--------|---------|-------------|
| Simple substitution | `{{variable_name}}` | Replaced with the value of the named input or previous output |
| Property access | `{{object.field}}` | Access a nested field using dot notation |
| Filter (length) | `{{variable \| length}}` | Length of a string or array |
| Filter (condition) | `{{items \| filter(severity="critical")}}` | Filter an array by a key-value condition |
| Chained filters | `{{issues \| filter(severity="critical") \| length}}` | Apply multiple filters left to right |
| Conditional block | `{{#if variable}}...{{/if}}` | Include the block content only when the variable is present and non-empty |

Conditional blocks are evaluated before variable substitution. Nested conditionals are not supported.

#### Code Blocks

Standard fenced code blocks with a language identifier:

```python
result = process(data)
```

The LLM executes these if it has code execution capability, or describes the expected output if it doesn't.

### Output (`## Output`)

**Required.** Describes what the document produces. Format each output as:

```markdown
- **output_name** (type): Description of this output, including any
  constraints on format or content.
```

#### Output Format (`### Output Format`)

**Optional subsection.** Specifies the exact structure of the expected output using a template or example:

```markdown
### Output Format

For each finding:
- **Title**: [short description]
- **Severity**: [critical / warning / note]
- **Details**: [explanation]
```

### Routing (`## Routing`)

**Required for `step`, `process`, and `guard` types. Absent for `directive` type.**

Controls where execution flows after this document completes.

#### Linear Routing

```markdown
## Routing

- next: ./next-step.md
```

#### Conditional Routing

```markdown
## Routing

- if: "condition describing when to take this route"
  then: ./target-step.md
- if: "another condition"
  then: ./other-step.md
- default: ./fallback-step.md
```

The LLM evaluates conditions against its output and the accumulated context. It takes the first matching route.

#### Termination

```markdown
## Routing

- next: none
```

## File Naming Conventions

- Use lowercase with hyphens: `generate-user-stories.md`
- Step files in a process use numbered prefixes: `01-data-collection.md`
- Process orchestrators are named `process.md`
- All paths in routing are relative: `./filename.md`

## Template Variable Syntax

Variables use double-brace syntax: `{{variable_name}}`

- Variables reference inputs by their `name` field from the frontmatter
- In multi-step workflows, variables can also reference outputs from previous steps
- Variables are substituted when the LLM processes the `ai` block
- Variable names should be `snake_case`

### Scoping Rules

When resolving a variable name, the LLM follows this precedence:

1. The current document's own frontmatter inputs.
2. Outputs from the most recently completed step that declared that output name.
3. If multiple previous steps produced an output with the same name, the step executed most recently takes precedence.
4. Use dot-notation (`{{step_output.field}}`) to disambiguate.

### Output Protocol

After completing a document, the LLM appends a routing line to indicate the next document:

```
Routing: ./next-document.md
```

Or, for terminal documents:

```
Routing: none
```

This routing line is the formal contract between documents. Orchestrators and workflow runners use it to determine which document to load next.

### Path Restrictions

All paths are relative to the referencing document. Paths must use `./` prefix for peer and child directories. Path traversal (`../`) outside the workflow's directory tree is forbidden.

## Additional Frontmatter Fields

### Persona Reference

Steps, directives, and guards can reference a persona document:

```yaml
persona: ./personas/security-engineer.md
```

When present, the LLM loads the persona and adopts its identity, expertise, and behavior. If the document also has a `## Context` section, both are merged — persona provides base framing, local context adds step-specific guidance.

### Schema Reference

Inputs and outputs can reference a schema document:

```yaml
inputs:
  - name: findings
    type: data
    schema: ./schemas/review-finding.md
    required: true
    description: "Review findings conforming to the review-finding schema"
outputs:
  - name: report
    type: data
    schema: ./schemas/review-report.md
    description: "Final report conforming to the review-report schema"
```

### Trigger Target

Trigger documents specify their target workflow:

```yaml
target: ./process.md
```

### Test Target

Test documents specify the document under test:

```yaml
target: ./directive-or-step.md
```

---

## Guard Documents (`type: guard`)

Guards are quality gates that validate output before a workflow advances.

### Sections

| Section | Required | Purpose |
|---------|----------|---------|
| `# Title` | Yes | Guard title |
| Prose intro | Yes | What this guard checks |
| `## Context` | Optional | Persona, domain knowledge, or framing to adopt during validation |
| `## Inputs` | Yes | The data to validate |
| `## Checks` | Yes | Validation criteria (replaces Execution) |
| `## Verdict` | Yes | How to produce pass/fail result (replaces Output) |
| `## Routing` | Yes | Where to go on pass vs. fail |

Guards support the `persona` frontmatter field. When a persona is referenced, adopt its identity, expertise, and behavior for the entire validation pass. If `## Context` is also present, merge the two — the persona provides base framing, the Context adds guard-specific guidance.

### Guard Routing

```markdown
## Routing

- on_pass: ./next-step.md
- on_fail: ./previous-step.md
```

---

## Persona Documents (`type: persona`)

Personas define reusable identities that steps and directives can adopt.

### Sections

| Section | Required | Purpose |
|---------|----------|---------|
| `# Title` | Yes | Persona name |
| Prose intro | Yes | Who this persona is |
| `## Identity` | Yes | Role, background, perspective |
| `## Expertise` | Yes | Domain knowledge, skills |
| `## Behavior` | Yes | Work style, priorities, tendencies |

Personas have no Execution, Output, or Routing.

---

## Schema Documents (`type: schema`)

Schemas define data contracts — the exact shape of data flowing between steps.

### Sections

| Section | Required | Purpose |
|---------|----------|---------|
| `# Title` | Yes | Schema name |
| Prose intro | Yes | What this data represents |
| `## Fields` | Yes | Each field with name, type, required, description |
| `## Constraints` | Optional | Validation rules, ranges, required combinations |
| `## Example` | Yes | A concrete example of valid data |

Schemas have no Execution, Output, or Routing.

---

## Trigger Documents (`type: trigger`)

Triggers define when and how a workflow activates.

### Sections

| Section | Required | Purpose |
|---------|----------|---------|
| `# Title` | Yes | Trigger name |
| Prose intro | Yes | When this trigger fires |
| `## Event` | Yes | The activating condition or event |
| `## Inputs` | Yes | What data the event provides |
| `## Target` | Yes | The process to activate, with input mapping |

Triggers have no Execution or Routing — they are declarative.

---

## Test Documents (`type: test`)

Tests define test cases for directives or steps.

### Sections

| Section | Required | Purpose |
|---------|----------|---------|
| `# Title` | Yes | Test name |
| Prose intro | Yes | What behavior is tested |
| `## Target` | Yes | The document under test |
| `## Cases` | Yes | Test cases with inputs and expected outputs |
| `## Assertions` | Optional | Cross-cutting checks beyond specific cases |

### Test Case Format

Each case has a descriptive name, Input block, and Expected Output block:

```markdown
### Case 1: Happy path

**Input:**
- `input_name`: "value"

**Expected Output:**
- `output_name` should contain [specific content]
```

---

## Document Type Rules

| Feature | Directive | Step | Process | Guard | Persona | Schema | Trigger | Test |
|---------|-----------|------|---------|-------|---------|--------|---------|------|
| Has frontmatter | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| Has Inputs | Yes | Yes | Yes | Yes | No | No | Yes | No |
| Has Execution | Yes | Yes | Optional | No | No | No | No | No |
| Has Checks | No | No | No | Yes | No | No | No | No |
| Has Output | Yes | Yes | Yes | No | No | No | No | No |
| Has Verdict | No | No | No | Yes | No | No | No | No |
| Has Routing | No | Yes | Yes | Yes | No | No | No | No |
| Has Context | Optional | Optional | Optional | Optional | No | No | No | No |
| Has Target | No | No | No | No | No | No | Yes | Yes |
| Has Identity | No | No | No | No | Yes | No | No | No |
| Has Fields | No | No | No | No | No | Yes | No | No |
| Has Cases | No | No | No | No | No | No | No | Yes |
| Can self-loop | N/A | Yes | N/A | N/A | N/A | N/A | N/A | N/A |
| Stateless | Yes | No | No | Yes | N/A | N/A | N/A | N/A |
| Referenceable | No | No | No | No | Yes | Yes | No | No |
