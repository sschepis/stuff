---
name: talkdown
description: Talkdown is a Markdown-based workflow language. Documents are programs, you are the runtime. Use when processing Talkdown documents, executing workflow steps, or following routing between documents. Supports directives, steps, processes, guards, personas, schemas, triggers, and tests.
---

# Talkdown

Talkdown is a Markdown-based workflow language. Documents are programs. You are the runtime.

When given a Talkdown document, you read its structure, execute its instructions, produce the specified output, and follow its routing to the next document. No interpreter is needed — you process the Markdown directly.

## Document Structure

Every Talkdown document has YAML frontmatter and a standard set of sections.

### Frontmatter

```yaml
---
type: directive | step | process | guard | persona | schema | trigger | test
title: "Document Title"
description: "One-line purpose"
inputs:
  - name: input_name
    type: text | file | data | url
    required: true
    description: "What this input is"
outputs:
  - name: output_name
    type: text | file | data
    description: "What this produces"
tags: [optional, tags]
---
```

**Document types:**
- `directive` — A stateless transformation. Takes input, produces output, no routing. Like a pure function.
- `step` — One stage in a multi-step workflow. Has routing to chain to other steps.
- `process` — An orchestrator that defines a workflow: which steps exist, their order, and how they connect.
- `guard` — A quality gate that validates output before a workflow advances. Returns a pass/fail verdict with routing for each outcome.
- `persona` — A reusable identity definition. Steps and directives reference a persona instead of duplicating `## Context` sections.
- `schema` — A data contract that defines the exact shape of data flowing between steps. Steps reference schemas to validate their inputs and outputs.
- `trigger` — An event definition that specifies when and how a workflow should activate.
- `test` — A test case that validates a directive or step produces correct output for known inputs.

### Sections

Documents contain sections that vary by type. The standard sections are:

| Section | Purpose | Used By |
|---------|---------|---------|
| `# Title` | Document title | All types |
| _Prose introduction_ | 1-3 sentence description of what this document does | All types |
| `## Context` | _(Optional)_ Persona, domain knowledge, or framing you should adopt | directive, step, guard |
| `## Inputs` | Detailed description of each expected input | directive, step, process, guard, trigger |
| `## Execution` | The instructions to carry out — the core of the document | directive, step, process (optional) |
| `## Output` | What to produce and how to format it | directive, step, process |
| `## Routing` | Where control flows next | step, process, guard

### Type-Specific Sections

Some types have unique sections instead of or in addition to the standard ones:

| Type | Unique Section(s) | Replaces |
|------|-------------------|----------|
| `guard` | `## Checks`, `## Verdict` | `## Execution`, `## Output` |
| `persona` | `## Identity`, `## Expertise`, `## Behavior` | (no execution or output) |
| `schema` | `## Fields`, `## Constraints`, `## Example` | (no execution or output) |
| `trigger` | `## Event`, `## Target` | (no execution or routing; declarative) |
| `test` | `## Target`, `## Cases`, `## Assertions` | (no execution or output) |

---

## How to Process a Document

### Step 1: Read the Frontmatter

Identify the document type, its inputs, and its expected outputs. Note what you need before you can begin.

### Step 2: Adopt the Context

If a `## Context` section exists, adopt the persona, framing, or domain knowledge it describes. Carry this framing through your entire execution of the document.

### Step 3: Validate Inputs

Check that all required inputs (from frontmatter and the `## Inputs` section) are available. If an input is missing and marked `required: true`, report what is missing and stop.

### Step 4: Execute

Process the `## Execution` section from top to bottom. This section contains three kinds of blocks:

#### Natural Language Steps

Numbered instructions you follow sequentially. Each step's result feeds into the next.

```
1. Analyze the input data for patterns
2. Group related items by category
3. Rank each group by relevance
```

#### AI Blocks

Fenced with ` ```ai `. These are self-contained prompts you execute as sub-tasks. Use `{{variable_name}}` to reference inputs or results from previous steps.

~~~
```ai
Given the following project description:
{{project_description}}

Generate three distinct user personas, each with:
- A name and background
- Their primary goals
- Their pain points
```
~~~

Execute the prompt, capture your response, and make it available to subsequent blocks.

##### Template Syntax

Template variables use these forms:

- **Simple substitution**: `{{variable_name}}` — replaced with the value of the named input or previous output.
- **Property access**: `{{object.field}}` — access a nested field (e.g., `{{article.summary}}`).
- **Filters**: `{{variable | filter}}` — apply a transformation:
  - `| length` — the length of a string or array.
  - `| filter(condition)` — filter an array by a key-value condition (e.g., `filter(severity="critical")`).
  - Filters can be chained: `{{feedback.issues | filter(severity="critical") | length}}`.
- **Conditional blocks**: Wrap content that should only appear when a variable is present:
  ```
  {{#if variable_name}}
  Content shown only when variable_name has a value.
  {{/if}}
  ```
  Conditionals are evaluated before variable substitution. Nested conditionals are not supported.

#### Code Blocks

Fenced with a language identifier (` ```python `, ` ```javascript `, etc.). If you have code execution capability, run the code and capture its output. If not, analyze the code, describe what it would produce, and use that as the block's result.

```python
import json
data = json.loads(raw_input)
summary = {k: len(v) for k, v in data.items()}
```

#### Mixed Execution

Steps, AI blocks, and code blocks can be interleaved. Process them in document order. Each block's output is available to all subsequent blocks.

### Step 5: Produce Output

Follow the `## Output` section to format your results. This section specifies:
- Which output fields to include (matching the frontmatter `outputs`)
- The exact format (Markdown structure, JSON schema, headings, etc.)
- Any constraints on length, style, or content

### Step 6: Follow Routing

If the document has a `## Routing` section, determine where control flows next.

---

## Routing

Routing controls the flow between documents in a workflow. Only `step` and `process` type documents have routing.

### Linear Routing

The simplest form — proceed to the next document unconditionally.

```markdown
## Routing

- next: ./03-report-generation.md
```

### Conditional Routing

Choose the next document based on the current state or output.

```markdown
## Routing

- if: "all findings are verified and complete"
  then: ./07-research-presentation.md
- if: "findings need additional verification"
  then: ./05-self-review.md
- default: ./05-self-review.md
```

Evaluate each condition against your output and the accumulated context. Take the first matching route. If no condition matches, take the `default` route.

### Self-Loops

A step can route back to itself, indicating iterative refinement.

```markdown
## Routing

- if: "the model is validated and complete"
  then: ./04-simulation-design.md
- default: ./03-mathematical-modeling.md
```

When self-looping, carry forward your accumulated work and build on it — don't restart from scratch. Track how many iterations you have completed. If a self-loop runs more than 5 iterations without reaching a termination condition, stop and report: describe what has been accomplished, what condition remains unmet, and suggest manual intervention.

### Circuit Breaker

To prevent infinite loops in multi-step cycles (e.g., guard fails → revise → guard fails → revise...), track iteration counts per step. If any step executes more than 10 times within a single workflow run, stop and report the loop with details about what condition is unresolved.

### Termination

When routing specifies `none` or the section is absent, the workflow is complete.

```markdown
## Routing

- next: none
```

---

## Chaining Documents

In a multi-step workflow, documents chain together:

1. You process document A and produce output + a routing line
2. The orchestrator (or you, if self-directing) loads document B
3. Document B receives your output from A as its input
4. You process B, carrying forward the accumulated context
5. Repeat until routing is `none`

### State Across Steps

- Carry forward all outputs from previous steps as accumulated context
- When a document references inputs produced by earlier steps, draw from your accumulated context
- Each document is self-contained — re-read its instructions fresh, don't assume carry-over from previous documents' execution logic
- Never fabricate inputs that were not produced by earlier steps

---

## Process Documents

A document with `type: process` is a workflow orchestrator. It defines:

- The steps in the workflow and their order
- The flow between steps (linear, branching, looping)
- Entry and exit points

When you encounter a process document:

1. Read its step listing to understand the full workflow
2. Begin at the first step
3. Follow routing from each step to determine the next
4. Continue until a step routes to `none` or the process defines completion

---

## Guard Documents

A document with `type: guard` is a quality gate. It evaluates output from a previous step and decides whether the workflow should advance or loop back.

### Structure

Guards have a unique section structure:

| Section | Purpose |
|---------|---------|
| `# Title` | Guard title |
| _Prose introduction_ | What this guard checks |
| `## Inputs` | The data to validate |
| `## Checks` | The validation criteria (replaces `## Execution`) |
| `## Verdict` | How to produce the pass/fail result (replaces `## Output`) |
| `## Routing` | Where to go on pass vs. fail |

### Routing Format for Guards

```markdown
## Routing

- on_pass: ./next-step.md
- on_fail: ./previous-step.md
```

### How to Process a Guard

1. Read the inputs — typically the output from the preceding step
2. Evaluate every check in the `## Checks` section
3. Produce a verdict: `pass` if all checks succeed, `fail` if any fail
4. Include specific feedback on what failed (so the preceding step can fix it on retry)
5. Route according to the verdict

Guards are reusable — the same guard can be inserted between different steps in different workflows.

---

## Persona Documents

A document with `type: persona` defines a reusable identity. Instead of writing `## Context` sections in every step, define a persona once and reference it.

### Structure

```yaml
---
type: persona
title: "Persona Name"
description: "One-line role description"
tags: [domain, tags]
---
```

| Section | Purpose |
|---------|---------|
| `# Title` | Persona name |
| _Prose introduction_ | Brief description of who this persona is |
| `## Identity` | Role, background, and perspective |
| `## Expertise` | Domain knowledge and skills |
| `## Behavior` | How this persona approaches work — tone, priorities, methods |

### Referencing a Persona

Steps, directives, and guards reference a persona via a `persona` field in their frontmatter:

```yaml
---
type: step
title: "Review Code"
persona: ./personas/security-engineer.md
---
```

### How to Process a Persona Reference

When a document has a `persona` field:

1. Load the referenced persona document
2. Adopt the identity, expertise, and behavior described in it
3. If the document also has its own `## Context` section, merge them — the persona provides the base framing, the local context adds step-specific guidance
4. Carry the persona through the entire execution of the document

Personas have no Execution, no Output, and no Routing — they are pure definitions.

---

## Schema Documents

A document with `type: schema` defines a data contract — the exact shape of data flowing between steps.

### Structure

```yaml
---
type: schema
title: "Schema Name"
description: "What data this schema describes"
tags: [domain, tags]
---
```

| Section | Purpose |
|---------|---------|
| `# Title` | Schema name |
| _Prose introduction_ | What this data represents |
| `## Fields` | Each field with its name, type, and description |
| `## Constraints` | Validation rules, required combinations, value ranges |
| `## Example` | A concrete example of valid data matching this schema |

### Referencing a Schema

Steps and directives reference schemas in their frontmatter inputs/outputs:

```yaml
---
type: step
inputs:
  - name: review_findings
    type: data
    schema: ./schemas/review-finding.md
    required: true
    description: "Code review findings conforming to the review-finding schema"
outputs:
  - name: report
    type: data
    schema: ./schemas/review-report.md
    description: "Final report conforming to the review-report schema"
---
```

### How to Process Schema References

When an input or output references a schema:

1. Load the schema document
2. For **inputs**: validate that the incoming data matches the schema's fields and constraints. Report mismatches.
3. For **outputs**: structure your output to match the schema exactly. Include all required fields in the specified format.
4. Use the schema's `## Example` as a reference for the expected shape.

Schemas have no Execution, no Routing — they are pure definitions.

---

## Trigger Documents

A document with `type: trigger` defines when and how a workflow activates.

### Structure

```yaml
---
type: trigger
title: "Trigger Name"
description: "What event activates this trigger"
target: ./process.md
tags: [domain, tags]
---
```

| Section | Purpose |
|---------|---------|
| `# Title` | Trigger name |
| _Prose introduction_ | When this trigger fires |
| `## Event` | The condition or event that activates the trigger |
| `## Inputs` | What data the event provides to the target workflow |
| `## Target` | The process or step to activate, with any input mapping |

### How to Process a Trigger

Triggers are declarative — they don't execute themselves. They define the contract between an event source and a workflow:

1. When the described event occurs, the trigger fires
2. The trigger maps event data to the target workflow's expected inputs
3. The target workflow begins execution with those inputs

Triggers are useful for documenting the entry points of workflows and what external events drive them.

---

## Test Documents

A document with `type: test` defines test cases for a directive or step.

### Structure

```yaml
---
type: test
title: "Test Name"
description: "What this test validates"
target: ./directive-or-step.md
tags: [testing, domain]
---
```

| Section | Purpose |
|---------|---------|
| `# Title` | Test name |
| _Prose introduction_ | What behavior is being tested |
| `## Target` | The directive or step under test |
| `## Cases` | Test cases with inputs and expected outputs |
| `## Assertions` | What to check beyond exact output match |

### Test Case Format

```markdown
## Cases

### Case 1: [descriptive name]

**Input:**
- input_name: "value"

**Expected Output:**
- output_name should contain [specific content]
- output_name should NOT contain [specific content]

### Case 2: [edge case name]

**Input:**
- input_name: ""

**Expected Output:**
- Should report missing required input
```

### How to Process a Test

1. Load the target directive or step
2. For each test case:
   - Provide the specified inputs to the target document
   - Execute the target document
   - Compare the actual output against the expected output
   - Check all assertions
3. Report results: which cases passed, which failed, and why

Tests validate that Talkdown documents behave correctly. They are especially useful for directives, which are stateless and easy to test in isolation.

---

## Error Handling

- **Missing inputs**: Report what is missing and which document needs it. Do not proceed without required inputs.
- **Execution failure**: Describe what failed and why. Suggest recovery steps if possible.
- **Ambiguous routing**: Choose the most conservative path (prefer self-loops over advancing, prefer default routes). Explain your reasoning.
- **Unreachable documents**: If routing points to a document you cannot access, report the broken link and stop.

---

## Conventions

- All file references use relative paths (`./filename.md`) within the same directory tree. Path traversal (`../`) outside the workflow directory is forbidden — only peer and child directories are accessible.
- Template variables use double-brace syntax: `{{variable_name}}`
- AI blocks are fenced with ` ```ai `
- Documents are self-describing — the frontmatter tells you everything you need to know about a document's interface
- Process orchestrators reference their steps by relative path
- Tags in frontmatter are for discovery and organization, not execution
- **Template variable scoping**: Variable resolution follows these precedence rules:
  1. The current document's own inputs (from frontmatter).
  2. Outputs from the most recently completed step that declared that output name.
  3. If multiple previous steps produced an output with the same name, the step executed most recently takes precedence.
  4. Use dot-notation (`{{step_output.field}}`) to disambiguate when needed.
- **Routing output protocol**: After completing a document, end your response with a routing line:
  ```
  Routing: ./next-document.md
  ```
  Or, for terminal documents:
  ```
  Routing: none
  ```
