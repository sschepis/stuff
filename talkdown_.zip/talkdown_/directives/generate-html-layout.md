---
type: directive
title: "Generate HTML Layout"
description: "Generate semantic HTML with inline styles from a UI element description"
inputs:
  - name: ui_description
    type: data
    required: true
    description: "Array of UI element descriptors, each with type, label, and optional action"
outputs:
  - name: html
    type: text
    description: "Generated HTML markup with inline styles implementing the described layout"
tags: [html, ui, layout, frontend, code-generation]
---

# Generate HTML Layout

Generates well-structured HTML with inline styling from a description of user interface elements and actions. Produces a layout optimized for usability with proper semantic markup, accessibility attributes, and responsive inline styles.

## Inputs

**ui_description** (data, required): An array of UI element descriptors. Each element should include:
- `type`: The HTML input type or element kind (e.g., "text", "button", "select", "textarea", "checkbox")
- `label`: The display label for the element
- `action`: (optional) A function name or action identifier to bind to the element

## Execution

1. Parse the `ui_description` to catalog all UI elements and their properties.
2. Determine the optimal layout strategy based on the types and number of elements (form layout, grid, flexbox).
3. Generate the HTML:

```ai
You are a frontend UI developer. Generate clean, semantic HTML with inline styles for the following UI elements.

UI Elements: {{ui_description}}

Requirements:
1. Use semantic HTML5 elements (form, label, input, button, fieldset, etc.).
2. Every input must have an associated <label> element with a matching `for`/`id` pair.
3. Add accessibility attributes: aria-labels where helpful, proper input types, required attributes.
4. Apply inline styles for layout:
   - Use a consistent spacing system (8px base unit)
   - Ensure inputs are full-width within their container
   - Group related elements visually
   - Add clear visual hierarchy between labels, inputs, and actions
5. If an element has an `action`, bind it to an onclick handler calling that function name.
6. Wrap everything in a containing <div> with max-width and centered alignment.

Output ONLY the HTML markup, no surrounding explanation.
```

4. Validate that every element from the input description appears in the generated HTML.

## Output

**html** (text): Complete HTML markup with inline styles implementing the described UI layout.

### Output Format

A single string of HTML code containing all described UI elements, wrapped in a container `<div>`, with inline styles for layout and spacing. Each interactive element has proper labels, ids, and accessibility attributes.
