---
type: directive
title: "Generate Project Description"
description: "Expand a brief project idea into a comprehensive, structured project description"
inputs:
  - name: project_idea
    type: text
    required: true
    description: "A brief explanation of the project or product idea"
  - name: project_goals
    type: text
    required: false
    description: "Specific goals the project aims to achieve"
  - name: target_audience
    type: text
    required: false
    description: "The intended users or demographic for the project"
  - name: expected_outcomes
    type: text
    required: false
    description: "The expected results or impact of the project"
  - name: project_challenges
    type: text
    required: false
    description: "Known or anticipated challenges"
  - name: overcoming_strategies
    type: text
    required: false
    description: "Strategies for addressing anticipated challenges"
outputs:
  - name: project_description
    type: text
    description: "A detailed, structured description of the project covering purpose, audience, outcomes, challenges, and strategies"
tags: [project-planning, product-design, ideation, documentation, strategy]
---

# Generate Project Description

Expands a brief project or product idea into a detailed, structured description. Covers the project's purpose, target audience, expected outcomes, potential challenges, and mitigation strategies to provide a comprehensive foundation for planning and communication.

## Inputs

**project_idea** (text, required): A brief explanation of the project or product idea. Even a single sentence can work, but more detail produces better results.

**project_goals** (text, optional): Specific goals the project aims to achieve. Helps focus the description on concrete objectives.

**target_audience** (text, optional): The demographic or user group the project is intended for. Shapes the tone and focus of the description.

**expected_outcomes** (text, optional): The expected results, deliverables, or measurable impact of the project.

**project_challenges** (text, optional): Known or anticipated challenges, risks, or constraints.

**overcoming_strategies** (text, optional): Pre-identified strategies for addressing the anticipated challenges.

## Execution

1. Analyze the project idea to identify its core value proposition and domain.
2. Incorporate any provided optional inputs to constrain and enrich the description.
3. Generate the comprehensive project description:

```ai
You are a product strategist and technical writer. Generate a detailed project description from the following inputs.

Project Idea: {{project_idea}}
Goals: {{project_goals}}
Target Audience: {{target_audience}}
Expected Outcomes: {{expected_outcomes}}
Known Challenges: {{project_challenges}}
Mitigation Strategies: {{overcoming_strategies}}

Produce a structured project description with these sections:

1. **Project Overview**: 2-3 paragraphs explaining what the project is, why it matters, and the problem it solves.

2. **Goals and Objectives**: Concrete, measurable goals. If goals were provided, expand on them. If not, infer reasonable goals from the idea.

3. **Target Audience**: Who will use this and why. Include user characteristics, needs, and how this project serves them.

4. **Expected Outcomes**: What success looks like — deliverables, metrics, and impact.

5. **Challenges and Risks**: Realistic challenges the project may face (technical, market, resource, etc.).

6. **Mitigation Strategies**: Actionable approaches to address each identified challenge.

7. **Summary**: A concise closing paragraph suitable for stakeholder communication.

Where optional inputs are not provided, infer reasonable content from the project idea. Flag any significant assumptions you made.
```

4. Review the description for internal consistency and completeness.

## Output

**project_description** (text): A structured project description covering all major planning dimensions.

### Output Format

A document with clearly labeled sections: Project Overview, Goals and Objectives, Target Audience, Expected Outcomes, Challenges and Risks, Mitigation Strategies, and Summary.
