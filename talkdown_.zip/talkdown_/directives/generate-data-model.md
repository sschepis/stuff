---
type: directive
title: "Generate Data Model"
description: "Generate a structured data model from a project, process, or domain description"
inputs:
  - name: description
    type: text
    required: true
    description: "Description of the project, process, or domain to model"
  - name: model_type
    type: text
    required: false
    description: "Type of model to generate: ER, UML, BPMN, or other notation (default: ER)"
outputs:
  - name: data_model
    type: text
    description: "The generated data model in the requested notation"
tags: [data-modeling, architecture, ER, UML, schema-design]
---

# Generate Data Model

Generates a structured data model from a natural-language description of a project, process, or domain. Supports multiple notations including Entity-Relationship diagrams, UML class diagrams, and BPMN process models.

## Inputs

**description** (text, required): A description of the project, task, process, or data domain to be modeled. Should include the key entities, their relationships, and any constraints or business rules.

**model_type** (text, optional): The notation to use for the generated model. Defaults to "ER". Supported values include "ER" (Entity-Relationship), "UML" (class diagram), "BPMN" (business process), or any other standard modeling notation.

## Execution

1. Parse the description to extract key entities, attributes, relationships, and constraints.
2. Identify cardinalities and relationship types (one-to-one, one-to-many, many-to-many).
3. Generate the model in the requested notation:

```ai
You are a data modeling expert. Given the following description, generate a {{model_type}} data model.

Description: {{description}}
Model type: {{model_type}}

Steps:
1. Identify all entities (or classes/processes, depending on model type) mentioned or implied.
2. For each entity, list its attributes with data types and constraints (primary key, nullable, unique, etc.).
3. Define all relationships between entities, specifying cardinality and directionality.
4. Note any business rules or constraints that affect the model structure.

Output the model as:
- A text-based diagram using standard notation for the requested model type
- A summary table listing each entity, its attributes, and its relationships
- Any assumptions you made where the description was ambiguous
```

4. Validate the model for completeness — every entity from the description should appear, and all stated relationships should be represented.

## Output

**data_model** (text): The generated data model in the requested notation, including a diagram representation, entity/attribute summary, and any modeling assumptions.

### Output Format

The output contains three sections:
- **Diagram**: Text-based representation in the requested notation
- **Entity Summary**: Table of entities with their attributes and types
- **Assumptions**: List of any ambiguities resolved during modeling
