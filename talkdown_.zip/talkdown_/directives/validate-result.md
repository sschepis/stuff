---
type: directive
title: "Validate Result"
description: "Validate a task result against a reference for quality, completeness, and detail"
inputs:
  - name: task_result
    type: text
    required: true
    description: "The result of the task to be validated"
  - name: result_reference
    type: text
    required: true
    description: "The reference specification against which the result is validated"
outputs:
  - name: validation_status
    type: text
    description: "Whether the result passed validation: true or false"
  - name: remaining_tasks
    type: data
    description: "List of remaining tasks needed to bring the result to specification (empty if validated)"
tags: [validation, quality-assurance, review, completeness-check]
---

# Validate Result

Validates a task result against a reference specification by checking for quality equivalence, completeness, and appropriate level of detail. Returns a validation status and, if the result falls short, a specific list of remaining tasks needed to bring it to specification.

## Inputs

**task_result** (text, required): The result of the task to be validated. This is the actual output that needs to be checked against the reference.

**result_reference** (text, required): The reference specification that defines what a complete, correct result looks like. This is the standard against which the task result is evaluated.

## Execution

1. Parse both the task result and the reference to understand their scope and content.
2. Perform a structured comparison:

```ai
You are a quality assurance reviewer. Compare the following task result against its reference specification and determine whether the result meets the standard.

Task Result:
{{task_result}}

Reference Specification:
{{result_reference}}

Perform this evaluation:

1. **Completeness Check**: Identify every requirement, topic, or component specified in the reference. For each, determine whether it is present in the task result.

2. **Quality Check**: For components that are present, assess whether they match the reference in depth, accuracy, and quality — not necessarily word-for-word, but in substance.

3. **Detail Check**: Assess whether the task result provides the appropriate level of detail compared to what the reference implies or specifies.

4. **Verdict**: Set validation_status to true ONLY if all requirements from the reference are adequately addressed. Otherwise, set it to false.

5. **Gap Analysis**: If validation fails, produce a specific, actionable list of remaining tasks. Each task should describe exactly what needs to be added, revised, or expanded to meet the reference specification.

Be strict but fair — the result does not need to be identical to the reference, but it must be equivalent in coverage and quality.
```

3. Compile the validation verdict and any remaining tasks into the output.

## Output

**validation_status** (text): The validation result — `true` if the task result meets the reference specification, `false` if gaps remain.

**remaining_tasks** (data): An array of specific, actionable tasks that must be completed to bring the result to specification. Empty if validation_status is true.

### Output Format

- `validation_status`: "true" or "false"
- `remaining_tasks`: A list of strings, each describing one specific action needed (e.g., "Add SWOT analysis section", "Expand market trends with current data"). Empty list `[]` when validated.
