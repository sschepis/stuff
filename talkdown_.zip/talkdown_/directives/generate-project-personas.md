---
type: directive
title: "Generate Project Personas"
description: "Create detailed user personas and roles for a project or product"
inputs:
  - name: project_idea
    type: text
    required: true
    description: "A brief description of the project or product idea"
  - name: target_audience
    type: text
    required: true
    description: "The intended users or audience for the system"
outputs:
  - name: personas
    type: data
    description: "A list of user personas with demographics, motivations, behaviors, and system roles"
tags: [user-research, personas, product-design, ux, role-definition]
---

# Generate Project Personas

Creates detailed user personas and system roles for a project or product. Each persona represents a distinct user archetype with demographics, motivations, behaviors, and a defined role in the system, providing a human-centered foundation for design and development decisions.

## Inputs

**project_idea** (text, required): A brief description of the project or product idea. Should convey the core functionality and value proposition.

**target_audience** (text, required): The intended users of the system. Can be broad (e.g., "small business owners") or specific (e.g., "freelance graphic designers aged 25-40 in urban areas").

## Execution

1. Analyze the project idea to understand the system's capabilities and interaction surfaces.
2. Segment the target audience into distinct user types based on their needs and relationship to the system.
3. Generate detailed personas for each user type:

```ai
You are a UX researcher specializing in persona development. Create detailed user personas for the following project.

Project Idea: {{project_idea}}
Target Audience: {{target_audience}}

For each distinct user type you identify, create a persona with:

1. **Name**: A realistic name that reflects the target demographic
2. **Demographics**: Age range, occupation, technical proficiency, relevant background
3. **Motivations**: What drives them to use this system — their goals and desired outcomes
4. **Pain Points**: Current frustrations or unmet needs this project addresses
5. **Behaviors**: How they would typically interact with the system — frequency, context, preferred features
6. **System Role**: Their functional role (e.g., admin, contributor, viewer, moderator) and what actions/data access that role entails
7. **Key Scenarios**: 2-3 brief usage scenarios showing this persona interacting with the system

Identify at least 3 distinct personas. Ensure they collectively cover:
- Primary users (core value recipients)
- Secondary users (supporting or administrative roles)
- Edge cases or power users (if applicable)

Make the personas specific enough to guide design decisions, not generic archetypes.
```

4. Review personas for distinctness — each should represent a meaningfully different relationship with the system.
5. Verify that the full range of system interactions is covered across all personas.

## Output

**personas** (data): A list of user personas, each containing name, demographics, motivations, pain points, behaviors, system role, and key usage scenarios.

### Output Format

A structured list where each persona entry contains:
- **persona_name**: The persona's name
- **demographics**: Age, occupation, tech proficiency, background
- **motivations**: Goals and desired outcomes
- **pain_points**: Current frustrations this project addresses
- **behaviors**: Interaction patterns and preferences
- **role**: System role with associated permissions and actions
- **scenarios**: 2-3 usage scenarios
