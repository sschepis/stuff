---
type: directive
title: "Generate Directive"
description: "Meta-directive that generates a new Talkdown directive in canonical format"
inputs:
  - name: name
    type: text
    required: true
    description: "The name of the directive to generate (used as filename and title)"
  - name: description
    type: text
    required: true
    description: "A description of what the directive should accomplish"
  - name: tags
    type: data
    required: false
    description: "A list of tags to associate with the directive"
  - name: parameters
    type: data
    required: false
    description: "A list of input parameters the directive should accept"
  - name: output
    type: data
    required: false
    description: "A list of outputs the directive should produce"
outputs:
  - name: directive
    type: file
    description: "A complete Talkdown directive in canonical Markdown format"
tags: [meta, directive-generation, talkdown, scaffolding, authoring]
---

# Generate Directive

Generates a new Talkdown directive in canonical format from a task description. The output is a complete, well-structured Markdown file that an LLM can execute with the appropriate inputs to accomplish the described task.

## Inputs

**name** (text, required): The name of the directive. Used as the document title and should be descriptive and kebab-case-friendly (e.g., "Analyze Sentiment", "Generate Report").

**description** (text, required): A description of what task the directive should accomplish. The more specific this is, the better the generated directive will be.

**tags** (data, optional): A list of tags to categorize the directive for discovery and organization.

**parameters** (data, optional): Explicit input parameters the directive should accept. Each should have a name, type, and description.

**output** (data, optional): Explicit outputs the directive should produce. Each should have a name, type, and description.

## Execution

1. Validate that both `name` and `description` are provided. If either is missing, halt and report the missing field.
2. Analyze the description to determine what inputs and outputs the directive needs (unless explicitly provided).
3. Design the execution steps that will accomplish the described task.
4. Generate the directive in canonical Talkdown format:

```ai
You are a Talkdown directive author. Generate a complete directive in canonical format for the following task.

Name: {{name}}
Description: {{description}}
Tags: {{tags}}
Explicit parameters: {{parameters}}
Explicit outputs: {{output}}

The directive MUST follow this exact structure:

1. YAML frontmatter with these fields:
   - type: directive
   - title: "Human-Readable Title"
   - description: "One-line purpose"
   - inputs: array of {name, type (text|file|data|url), required (bool), description}
   - outputs: array of {name, type (text|file|data), description}
   - tags: [relevant, tags]

2. A level-1 heading matching the frontmatter title

3. A brief prose description (1-3 sentences)

4. An "## Inputs" section with each input as:
   **name** (type, required/optional): description

5. An "## Execution" section with numbered steps. Include ```ai blocks for any LLM prompts, using {{variable}} syntax for input references.

6. An "## Output" section with each output as:
   **name** (type): description
   Include a "### Output Format" subsection if the output has specific structure.

IMPORTANT rules:
- Do NOT include a "## Routing" section (directives are stateless)
- Do NOT include an "Examples" section
- Make the ```ai prompt blocks specific, well-crafted, and actionable
- Use good, specific tags relevant to the directive's domain
- Inputs must use types: text, file, data, or url
- Outputs must use types: text, file, or data
```

5. Review the generated directive for completeness and adherence to the canonical format.

## Output

**directive** (file): A complete Talkdown directive document in Markdown format, ready to be saved and executed.

### Output Format

A Markdown document beginning with YAML frontmatter (`---` delimited), followed by the title, description, Inputs, Execution, and Output sections as specified in the canonical Talkdown directive format.
