---
type: directive
title: "Generate User Stories"
description: "Generate a comprehensive set of user stories for a specific role in a project"
inputs:
  - name: project
    type: text
    required: true
    description: "The project or product idea to generate stories for"
  - name: role
    type: text
    required: true
    description: "The user role whose perspective the stories are written from"
outputs:
  - name: user_stories
    type: data
    description: "A list of user stories in standard format with acceptance criteria"
tags: [agile, user-stories, requirements, product-management, scrum]
---

# Generate User Stories

Generates a comprehensive set of user stories for a specific role within a project or product. Each story follows the standard "As a [role], I want [capability], so that [benefit]" format and includes acceptance criteria to define completion.

## Inputs

**project** (text, required): The project or product idea. Should describe what the system does and its core value proposition.

**role** (text, required): The user role to generate stories for (e.g., "administrator", "end user", "content creator"). Stories will be written from this role's perspective.

## Execution

1. Analyze the project description to understand the system's capabilities and scope.
2. Understand the role's relationship to the system — what they need, what they can do, and what value they derive.
3. Generate user stories covering the full range of the role's interactions:

```ai
You are an experienced product manager writing user stories for an agile team. Generate a comprehensive set of user stories for the following role and project.

Project: {{project}}
Role: {{role}}

For each user story, provide:

1. **Story**: Written in standard format: "As a {{role}}, I want [specific capability], so that [concrete benefit]."
2. **Acceptance Criteria**: 2-4 testable conditions that define when this story is complete (use "Given/When/Then" format).
3. **Priority**: Must-have, Should-have, or Nice-to-have (MoSCoW).
4. **Size**: S, M, L, or XL relative effort estimate.

Cover these categories of interaction:
- **Onboarding**: How the user first engages with the system
- **Core workflows**: The primary tasks this role performs
- **Data management**: Creating, reading, updating, deleting relevant data
- **Configuration**: Settings and preferences this role controls
- **Edge cases**: Error handling, recovery, and boundary conditions

Generate at least 10 user stories. Order them by priority (must-haves first), then by natural workflow sequence within each priority level.
```

4. Review stories for completeness — ensure no major capability for this role is missing.
5. Check that acceptance criteria are specific and testable, not vague.

## Output

**user_stories** (data): A prioritized list of user stories with acceptance criteria, priority classification, and size estimates.

### Output Format

An ordered list where each entry contains:
- **story**: The user story in "As a... I want... so that..." format
- **acceptance_criteria**: 2-4 testable Given/When/Then conditions
- **priority**: Must-have | Should-have | Nice-to-have
- **size**: S | M | L | XL
