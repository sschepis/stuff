---
type: directive
title: "Decompose Task"
description: "Break a complex task into ordered, actionable subtasks with priorities and dependencies"
inputs:
  - name: task
    type: text
    required: true
    description: "The task to decompose into smaller subtasks"
outputs:
  - name: decomposed_tasks
    type: data
    description: "Ordered list of subtasks with priorities, dependencies, and time estimates"
tags: [planning, decomposition, task-management, prioritization]
---

# Decompose Task

Breaks a complex task into smaller, actionable subtasks. Each subtask is ordered by dependency and urgency, with clear scope so it can be executed independently or delegated.

## Inputs

**task** (text, required): The task to decompose. Can be a brief description or a detailed specification. The more context provided, the more precise the decomposition.

## Execution

1. Analyze the task to identify its main objectives and implicit sub-objectives.
2. Break each objective into concrete, independently executable subtasks.
3. Identify dependencies between subtasks (which must complete before others can begin).
4. Estimate relative effort for each subtask (small, medium, large).
5. Produce the ordered task list using the following prompt:

```ai
You are a project planning expert. Decompose the following task into a structured list of subtasks.

Task: {{task}}

For each subtask, provide:
- A clear, action-oriented title
- A one-sentence description of what "done" looks like
- Dependencies (which other subtasks must finish first, by number)
- Effort estimate (small / medium / large)
- Priority (critical / high / medium / low)

Order the subtasks so that dependencies come before the tasks that need them. Group related subtasks when it aids clarity. Aim for subtasks that are each completable in a single focused session.

Return the result as a numbered list with the fields above for each entry.
```

6. Review the decomposition for completeness — ensure no major objective from the original task is left uncovered.

## Output

**decomposed_tasks** (data): An ordered list of subtasks. Each entry contains a title, completion criteria, dependency references, effort estimate, and priority level.

### Output Format

A numbered list where each item includes:
- **title**: Action-oriented subtask name
- **done_when**: One sentence defining completion
- **depends_on**: List of subtask numbers this depends on (empty if none)
- **effort**: small | medium | large
- **priority**: critical | high | medium | low
