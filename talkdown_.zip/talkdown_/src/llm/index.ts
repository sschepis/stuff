import type { LLMRequest, LLMResponse, ConditionRequest, ConditionResponse } from './types.js';

export type { LLMRequest, LLMResponse, ConditionRequest, ConditionResponse } from './types.js';

/**
 * Interface for LLM providers. Implementations handle text completion
 * and boolean condition evaluation.
 */
export interface LLMProvider {
  /** Complete a prompt and return the generated text. */
  complete(request: LLMRequest): Promise<LLMResponse>;

  /** Evaluate a boolean condition against a context. */
  evaluateCondition(request: ConditionRequest): Promise<ConditionResponse>;

  /** Human-readable provider name. */
  readonly name: string;
}

/**
 * A mock LLM provider for testing. Uses canned responses keyed by
 * prompt substring matching.
 *
 * Usage:
 * ```ts
 * const provider = new MockProvider(new Map([
 *   ['summarize', 'This is a summary.'],
 *   ['translate', 'Translated text here.'],
 * ]));
 *
 * // Prompt containing "summarize" will return "This is a summary."
 * const response = await provider.complete({ prompt: 'Please summarize this text' });
 * ```
 */
export class MockProvider implements LLMProvider {
  readonly name = 'mock';

  /** Canned responses: if a key is a substring of the prompt, return that value. */
  private responses: Map<string, string>;

  /** Canned condition responses: if a key is a substring of the condition, return that result. */
  private conditionResponses: Map<string, boolean>;

  /** Default response when no match is found. */
  private defaultResponse: string;

  /** Default condition result when no match is found. */
  private defaultConditionResult: boolean;

  /** Records of all requests made, for test assertions. */
  private completionLog: LLMRequest[] = [];
  private conditionLog: ConditionRequest[] = [];

  constructor(
    responses: Map<string, string> = new Map(),
    options?: {
      conditionResponses?: Map<string, boolean>;
      defaultResponse?: string;
      defaultConditionResult?: boolean;
    }
  ) {
    this.responses = new Map(responses);
    this.conditionResponses = new Map(options?.conditionResponses ?? []);
    this.defaultResponse = options?.defaultResponse ?? '';
    this.defaultConditionResult = options?.defaultConditionResult ?? true;
  }

  /**
   * Complete a prompt using canned responses. Searches for the first key
   * that appears as a substring in the prompt.
   */
  async complete(request: LLMRequest): Promise<LLMResponse> {
    this.completionLog.push(request);

    let content = this.defaultResponse;
    for (const [key, value] of this.responses) {
      if (request.prompt.includes(key)) {
        content = value;
        break;
      }
    }

    return {
      content,
      model: 'mock',
      finishReason: 'stop',
      usage: {
        inputTokens: request.prompt.length,
        outputTokens: content.length,
      },
    };
  }

  /**
   * Evaluate a condition using canned condition responses. Searches for
   * the first key that appears as a substring in the condition.
   */
  async evaluateCondition(request: ConditionRequest): Promise<ConditionResponse> {
    this.conditionLog.push(request);

    let result = this.defaultConditionResult;
    for (const [key, value] of this.conditionResponses) {
      if (request.condition.includes(key)) {
        result = value;
        break;
      }
    }

    return {
      result,
      explanation: 'mock',
      confidence: 1.0,
    };
  }

  // ── Test helpers ───────────────────────────────────────────────────

  /**
   * Add or overwrite a canned response.
   */
  setResponse(promptSubstring: string, response: string): void {
    this.responses.set(promptSubstring, response);
  }

  /**
   * Add or overwrite a canned condition response.
   */
  setConditionResponse(conditionSubstring: string, result: boolean): void {
    this.conditionResponses.set(conditionSubstring, result);
  }

  /**
   * Get the log of all completion requests made.
   */
  getCompletionLog(): readonly LLMRequest[] {
    return this.completionLog;
  }

  /**
   * Get the log of all condition evaluation requests made.
   */
  getConditionLog(): readonly ConditionRequest[] {
    return this.conditionLog;
  }

  /**
   * Clear request logs.
   */
  clearLogs(): void {
    this.completionLog = [];
    this.conditionLog = [];
  }

  /**
   * Reset all canned responses and logs.
   */
  reset(): void {
    this.responses.clear();
    this.conditionResponses.clear();
    this.completionLog = [];
    this.conditionLog = [];
  }
}
