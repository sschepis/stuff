/**
 * Request to an LLM provider for text completion.
 */
export interface LLMRequest {
  /** System prompt / instructions. */
  system?: string;

  /** The user prompt to complete. */
  prompt: string;

  /** Sampling temperature (0-2). */
  temperature?: number;

  /** Maximum tokens to generate. */
  maxTokens?: number;

  /** Expected response format. */
  responseFormat?: 'text' | 'json';

  /** Metadata about the calling context, useful for logging and routing. */
  metadata?: {
    documentPath: string;
    blockType: 'ai_block' | 'guard_check' | 'routing_condition' | 'test_eval';
  };
}

/**
 * Response from an LLM provider.
 */
export interface LLMResponse {
  /** The generated text content. */
  content: string;

  /** Token usage statistics. */
  usage?: {
    inputTokens: number;
    outputTokens: number;
  };

  /** The model identifier that produced this response. */
  model: string;

  /** Reason the generation stopped. */
  finishReason: 'stop' | 'length' | 'error';
}

/**
 * Request to evaluate a boolean condition using an LLM.
 */
export interface ConditionRequest {
  /** The condition to evaluate (natural language). */
  condition: string;

  /** Context data to evaluate the condition against. */
  context: string;

  /** Optional system prompt for the evaluation. */
  system?: string;
}

/**
 * Response from a condition evaluation.
 */
export interface ConditionResponse {
  /** Whether the condition evaluated to true or false. */
  result: boolean;

  /** Explanation of the evaluation reasoning. */
  explanation: string;

  /** Optional confidence score (0-1). */
  confidence?: number;
}
