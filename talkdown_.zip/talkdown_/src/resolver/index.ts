// ── Workflow resolver ─────────────────────────────────────────────
//
// Starting from a process document, recursively loads all referenced
// steps, personas, and schemas, building a complete workflow graph
// with edges derived from routing declarations.

import type { TalkdownDocument } from '../types/ast.js';
import { DocumentLoader } from './document-loader.js';
import { resolvePath } from './path-resolver.js';

// ── Re-exports ───────────────────────────────────────────────────

export { DocumentLoader } from './document-loader.js';
export { resolvePath, validateRoutingPaths } from './path-resolver.js';
export type { PathValidationResult } from './path-resolver.js';

// ── Types ────────────────────────────────────────────────────────

export interface WorkflowEdge {
  from: string;
  to: string;
  condition?: string;
}

export interface WorkflowGraph {
  /** The root process document. */
  process: TalkdownDocument;
  /** All step documents, keyed by absolute path. */
  steps: Map<string, TalkdownDocument>;
  /** All persona documents, keyed by absolute path. */
  personas: Map<string, TalkdownDocument>;
  /** All schema documents, keyed by absolute path. */
  schemas: Map<string, TalkdownDocument>;
  /** Edges between documents derived from routing. */
  edges: Array<WorkflowEdge>;
  /** Any broken references or load errors encountered. */
  errors: string[];
}

// ── Helpers ──────────────────────────────────────────────────────

const TERMINAL_TARGETS = new Set(['none', 'end', 'done', 'DONE', '']);

function isTerminal(target: string): boolean {
  return TERMINAL_TARGETS.has(target.trim());
}

/**
 * Extract all routing target paths from a document's routing section.
 * Returns an array of { path, condition? } tuples.
 */
function extractRoutingTargets(
  doc: TalkdownDocument,
): Array<{ path: string; condition?: string }> {
  if (!doc.routing) return [];

  const targets: Array<{ path: string; condition?: string }> = [];

  switch (doc.routing.kind) {
    case 'linear':
      if (!isTerminal(doc.routing.next)) {
        targets.push({ path: doc.routing.next });
      }
      break;

    case 'guard':
      if (!isTerminal(doc.routing.onPass)) {
        targets.push({ path: doc.routing.onPass, condition: 'pass' });
      }
      if (!isTerminal(doc.routing.onFail)) {
        targets.push({ path: doc.routing.onFail, condition: 'fail' });
      }
      break;

    case 'conditional':
      for (const branch of doc.routing.branches) {
        if (!isTerminal(branch.then)) {
          targets.push({ path: branch.then, condition: branch.condition });
        }
      }
      if (doc.routing.default && !isTerminal(doc.routing.default)) {
        targets.push({ path: doc.routing.default, condition: 'default' });
      }
      break;

    case 'terminal':
      break;
  }

  return targets;
}

/**
 * Try to load a document, capturing errors instead of throwing.
 */
async function tryLoad(
  loader: DocumentLoader,
  fromFile: string,
  relativePath: string,
  errors: string[],
): Promise<TalkdownDocument | null> {
  try {
    return await loader.loadRelative(fromFile, relativePath);
  } catch (err) {
    errors.push(
      `Failed to load "${relativePath}" referenced from "${fromFile}": ${(err as Error).message}`,
    );
    return null;
  }
}

// ── Public API ───────────────────────────────────────────────────

/**
 * Resolve a complete workflow graph starting from a process document.
 *
 * 1. Loads the process document
 * 2. Extracts all step references from the ## Steps table and routing
 * 3. Recursively loads each step, following routing paths
 * 4. Collects all persona and schema references
 * 5. Builds the edge list from routing declarations
 * 6. Reports any broken references as errors
 *
 * @param processPath - Absolute path to the process document
 * @param loader - DocumentLoader instance to use for loading
 * @returns A complete WorkflowGraph
 */
export async function resolveWorkflow(
  processPath: string,
  loader: DocumentLoader,
): Promise<WorkflowGraph> {
  const steps = new Map<string, TalkdownDocument>();
  const personas = new Map<string, TalkdownDocument>();
  const schemas = new Map<string, TalkdownDocument>();
  const edges: WorkflowEdge[] = [];
  const errors: string[] = [];

  // 1. Load the process document
  let process: TalkdownDocument;
  try {
    process = await loader.load(processPath);
  } catch (err) {
    throw new Error(
      `Failed to load process document "${processPath}": ${(err as Error).message}`,
    );
  }

  if (process.frontmatter.type !== 'process') {
    errors.push(
      `Expected a process document but got type "${process.frontmatter.type}" at "${processPath}"`,
    );
  }

  // Track which paths we've visited to avoid infinite loops
  const visited = new Set<string>();
  visited.add(processPath);

  // 2. Load steps from the ## Steps table
  if (process.steps) {
    for (const step of process.steps) {
      await loadStepRecursive(
        step.path,
        processPath,
        loader,
        steps,
        personas,
        schemas,
        edges,
        errors,
        visited,
      );
    }

    // Create edges from process to first step
    if (process.steps.length > 0) {
      const firstStepPath = process.steps[0].path;
      const resolvedFirst = safeResolvePath(processPath, firstStepPath);
      if (resolvedFirst) {
        edges.push({ from: processPath, to: resolvedFirst });
      }

      // Create edges between sequential steps in the table
      for (let i = 0; i < process.steps.length - 1; i++) {
        const currentPath = safeResolvePath(processPath, process.steps[i].path);
        const nextPath = safeResolvePath(processPath, process.steps[i + 1].path);
        if (currentPath && nextPath) {
          // Only add implicit sequential edges if the step doesn't have explicit routing
          const stepDoc = steps.get(currentPath);
          if (stepDoc && !stepDoc.routing) {
            edges.push({ from: currentPath, to: nextPath });
          }
        }
      }
    }
  }

  // 3. Collect persona references from the process itself
  await collectReference(
    process,
    processPath,
    'persona',
    loader,
    personas,
    errors,
  );

  return {
    process,
    steps,
    personas,
    schemas,
    edges,
    errors,
  };
}

// ── Recursive step loader ────────────────────────────────────────

async function loadStepRecursive(
  relativePath: string,
  fromFile: string,
  loader: DocumentLoader,
  steps: Map<string, TalkdownDocument>,
  personas: Map<string, TalkdownDocument>,
  schemas: Map<string, TalkdownDocument>,
  edges: WorkflowEdge[],
  errors: string[],
  visited: Set<string>,
): Promise<void> {
  // Resolve to absolute path
  const absolutePath = safeResolvePath(fromFile, relativePath);
  if (!absolutePath) {
    errors.push(
      `Invalid path "${relativePath}" referenced from "${fromFile}"`,
    );
    return;
  }

  // Skip if already visited
  if (visited.has(absolutePath)) {
    return;
  }
  visited.add(absolutePath);

  // Load the document
  const doc = await tryLoad(loader, fromFile, relativePath, errors);
  if (!doc) return;

  // Store based on type
  const docType = doc.frontmatter.type;
  if (docType === 'step' || docType === 'directive' || docType === 'guard') {
    steps.set(absolutePath, doc);
  }

  // Collect persona and schema references
  await collectReference(doc, absolutePath, 'persona', loader, personas, errors);
  await collectSchemaReferences(doc, absolutePath, loader, schemas, errors);

  // Follow routing targets recursively
  const targets = extractRoutingTargets(doc);
  for (const target of targets) {
    // Add edge
    const targetAbsolute = safeResolvePath(absolutePath, target.path);
    if (targetAbsolute) {
      edges.push({
        from: absolutePath,
        to: targetAbsolute,
        condition: target.condition,
      });

      // Recursively load the target
      await loadStepRecursive(
        target.path,
        absolutePath,
        loader,
        steps,
        personas,
        schemas,
        edges,
        errors,
        visited,
      );
    }
  }
}

// ── Reference collectors ─────────────────────────────────────────

async function collectReference(
  doc: TalkdownDocument,
  docPath: string,
  kind: 'persona',
  loader: DocumentLoader,
  collection: Map<string, TalkdownDocument>,
  errors: string[],
): Promise<void> {
  const ref = doc.frontmatter.persona;
  if (!ref) return;

  // Only resolve file references (not inline persona names)
  if (!ref.startsWith('./') && !ref.endsWith('.md')) return;

  const absolutePath = safeResolvePath(docPath, ref);
  if (!absolutePath) return;

  if (collection.has(absolutePath)) return;

  const loaded = await tryLoad(loader, docPath, ref, errors);
  if (loaded) {
    collection.set(absolutePath, loaded);
  }
}

async function collectSchemaReferences(
  doc: TalkdownDocument,
  docPath: string,
  loader: DocumentLoader,
  schemas: Map<string, TalkdownDocument>,
  errors: string[],
): Promise<void> {
  // Collect schema references from input/output definitions
  const allDefs = [
    ...(doc.frontmatter.inputs ?? []),
    ...(doc.frontmatter.outputs ?? []),
  ];

  for (const def of allDefs) {
    if (def.schema && (def.schema.startsWith('./') || def.schema.endsWith('.md'))) {
      const absolutePath = safeResolvePath(docPath, def.schema);
      if (!absolutePath || schemas.has(absolutePath)) continue;

      const loaded = await tryLoad(loader, docPath, def.schema, errors);
      if (loaded) {
        schemas.set(absolutePath, loaded);
      }
    }
  }
}

// ── Path helpers ─────────────────────────────────────────────────

function safeResolvePath(
  fromFile: string,
  relativePath: string,
): string | null {
  try {
    return resolvePath(fromFile, relativePath);
  } catch {
    return null;
  }
}
