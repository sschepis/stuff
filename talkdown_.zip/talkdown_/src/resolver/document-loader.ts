// ── Document loader ───────────────────────────────────────────────
//
// Loads and caches parsed Talkdown documents from the filesystem.
// Uses async file reads and caches results to avoid re-parsing.

import { readFile } from 'node:fs/promises';
import type { TalkdownDocument } from '../types/ast.js';
import { parseDocument } from '../parser/index.js';
import { resolvePath } from './path-resolver.js';

/**
 * Loads Talkdown documents from disk, parsing and caching them.
 *
 * The cache is keyed by absolute file path, so the same document
 * is never parsed twice within the lifetime of a loader instance.
 */
export class DocumentLoader {
  private cache: Map<string, TalkdownDocument>;

  /**
   * @param basePath - The root directory for resolving document paths
   */
  constructor(private basePath: string) {
    this.cache = new Map();
  }

  /**
   * Load a Talkdown document from an absolute or base-relative path.
   *
   * If the document has already been loaded, returns the cached version.
   * Otherwise reads the file from disk, parses it, caches it, and
   * returns the parsed document.
   *
   * @param filePath - Absolute path or path relative to basePath
   * @returns The parsed TalkdownDocument
   * @throws If the file cannot be read or parsed
   */
  async load(filePath: string): Promise<TalkdownDocument> {
    // Normalize to absolute path
    const absolutePath = filePath.startsWith('/')
      ? filePath
      : resolvePath(this.basePath + '/dummy', filePath);

    // Return cached document if available
    const cached = this.cache.get(absolutePath);
    if (cached) {
      return cached;
    }

    // Read and parse
    const source = await readFile(absolutePath, 'utf-8');
    const doc = parseDocument(absolutePath, source);

    // Cache and return
    this.cache.set(absolutePath, doc);
    return doc;
  }

  /**
   * Load a document referenced by a relative path from another file.
   *
   * Resolves the relative path against the referencing file's directory,
   * then delegates to {@link load}.
   *
   * @param fromFile - Absolute path of the file containing the reference
   * @param relativePath - Relative path like `./02-step.md`
   * @returns The parsed TalkdownDocument
   * @throws If path traversal is attempted or the file cannot be read
   */
  async loadRelative(
    fromFile: string,
    relativePath: string,
  ): Promise<TalkdownDocument> {
    const resolved = resolvePath(fromFile, relativePath);
    return this.load(resolved);
  }

  /**
   * Clear the document cache, forcing all future loads to re-read
   * and re-parse from disk.
   */
  clearCache(): void {
    this.cache.clear();
  }
}
