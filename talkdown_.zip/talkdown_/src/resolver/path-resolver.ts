// ── Path resolver ─────────────────────────────────────────────────
//
// Functions for resolving and validating Talkdown document paths.
// Path traversal (../) is forbidden by the Talkdown spec.

import path from 'node:path';
import { existsSync } from 'node:fs';
import type { TalkdownDocument } from '../types/ast.js';

// ── Types ─────────────────────────────────────────────────────────

export interface PathValidationResult {
  valid: boolean;
  errors: string[];
}

// ── Public API ────────────────────────────────────────────────────

/**
 * Resolve a relative path from the referencing file's location.
 *
 * @param fromFile - Absolute path of the file containing the reference
 * @param relativePath - Relative path like `./02-step.md`
 * @returns The absolute resolved path
 * @throws If the relative path contains `../` (path traversal is forbidden)
 */
export function resolvePath(fromFile: string, relativePath: string): string {
  if (relativePath.includes('../')) {
    throw new Error(
      `Path traversal is forbidden: "${relativePath}" contains "../". ` +
        `Referenced from "${fromFile}".`,
    );
  }

  const fromDir = path.dirname(fromFile);
  return path.resolve(fromDir, relativePath);
}

/**
 * Check all routing targets in a document resolve to existing files.
 *
 * @param doc - The parsed Talkdown document to validate
 * @param basePath - The base path for resolving relative references
 * @returns A validation result with any errors found
 */
export function validateRoutingPaths(
  doc: TalkdownDocument,
  basePath: string,
): PathValidationResult {
  const errors: string[] = [];

  if (!doc.routing) {
    return { valid: true, errors };
  }

  const routing = doc.routing;

  switch (routing.kind) {
    case 'linear': {
      validateTarget(routing.next, basePath, doc.filePath, errors);
      break;
    }

    case 'guard': {
      validateTarget(routing.onPass, basePath, doc.filePath, errors);
      validateTarget(routing.onFail, basePath, doc.filePath, errors);
      break;
    }

    case 'conditional': {
      for (const branch of routing.branches) {
        validateTarget(branch.then, basePath, doc.filePath, errors);
      }
      if (routing.default) {
        validateTarget(routing.default, basePath, doc.filePath, errors);
      }
      break;
    }

    case 'terminal':
      // No paths to validate
      break;
  }

  // Also validate persona reference if present
  if (doc.frontmatter.persona) {
    const personaPath = doc.frontmatter.persona;
    if (personaPath.startsWith('./') || personaPath.endsWith('.md')) {
      validateTarget(personaPath, basePath, doc.filePath, errors);
    }
  }

  // Validate process step paths
  if (doc.steps) {
    for (const step of doc.steps) {
      validateTarget(step.path, basePath, doc.filePath, errors);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// ── Helpers ───────────────────────────────────────────────────────

/**
 * Validate a single routing target path.
 * Skips special values like "none", "end", "done".
 */
function validateTarget(
  target: string,
  basePath: string,
  sourceFile: string,
  errors: string[],
): void {
  const trimmed = target.trim();

  // Skip terminal/special routing values
  if (
    trimmed === 'none' ||
    trimmed === 'end' ||
    trimmed === 'done' ||
    trimmed === '' ||
    trimmed === 'DONE'
  ) {
    return;
  }

  // Check for path traversal
  if (trimmed.includes('../')) {
    errors.push(
      `Path traversal forbidden: "${trimmed}" in ${sourceFile}`,
    );
    return;
  }

  // Resolve and check existence
  try {
    const resolved = path.resolve(basePath, trimmed);
    if (!existsSync(resolved)) {
      errors.push(
        `Routing target not found: "${trimmed}" (resolved to ${resolved}) in ${sourceFile}`,
      );
    }
  } catch (err) {
    errors.push(
      `Failed to resolve path "${trimmed}" in ${sourceFile}: ${(err as Error).message}`,
    );
  }
}
