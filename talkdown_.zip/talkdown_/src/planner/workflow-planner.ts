// ── Workflow planner ──────────────────────────────────────────────
//
// Combines individual document plans with the workflow graph edges
// to produce a high-level WorkflowPlan. This is the top-level plan
// structure that the runtime uses to orchestrate multi-step workflows.

import type { AnalyzedDocument } from '../types/compiled.js';
import type { WorkflowGraph } from '../resolver/index.js';
import type { DocumentPlan } from './document-planner.js';
import { planDocument } from './document-planner.js';

// ── Types ────────────────────────────────────────────────────────

export interface WorkflowEdge {
  from: string;
  to: string;
  condition?: string;
  conditionType: 'deterministic' | 'semantic';
}

export interface CircuitBreakerConfig {
  /** Maximum times a step can route back to itself. */
  maxSelfLoops: number;
  /** Maximum total executions across all steps. */
  maxStepExecutions: number;
}

export interface WorkflowPlan {
  /** Path to the entry (process) document. */
  entryDocument: string;
  /** Plans for each document in the workflow, keyed by path. */
  documentPlans: Map<string, DocumentPlan>;
  /** Edges connecting document plans, with classified conditions. */
  edges: WorkflowEdge[];
  /** Circuit breaker configuration to prevent infinite loops. */
  circuitBreakerConfig: CircuitBreakerConfig;
  /** Resolution errors collected during workflow loading. */
  errors: string[];
}

// ── Default configuration ────────────────────────────────────────

const DEFAULT_CIRCUIT_BREAKER: CircuitBreakerConfig = {
  maxSelfLoops: 3,
  maxStepExecutions: 100,
};

// ── Public API ───────────────────────────────────────────────────

/**
 * Combine individual document plans with the workflow graph to
 * produce a complete {@link WorkflowPlan}.
 *
 * Each document in the workflow graph is planned individually, and
 * the routing edges from the graph are classified and included in
 * the workflow plan.
 *
 * @param graph - The resolved workflow graph
 * @param analyzedDocs - Analysis results for each document, keyed by path
 * @returns A WorkflowPlan ready for the runtime
 */
export function planWorkflow(
  graph: WorkflowGraph,
  analyzedDocs: Map<string, AnalyzedDocument>,
): WorkflowPlan {
  const documentPlans = new Map<string, DocumentPlan>();

  // Plan the process document itself
  const processPath = graph.process.filePath;
  const processAnalysis = analyzedDocs.get(processPath);
  if (processAnalysis) {
    documentPlans.set(processPath, planDocument(graph.process, processAnalysis));
  }

  // Plan each step document
  for (const [stepPath, stepDoc] of graph.steps) {
    const analysis = analyzedDocs.get(stepPath);
    if (analysis) {
      documentPlans.set(stepPath, planDocument(stepDoc, analysis));
    }
  }

  // Plan persona documents (usually just loaded, not executed,
  // but we include them for completeness)
  for (const [personaPath, personaDoc] of graph.personas) {
    const analysis = analyzedDocs.get(personaPath);
    if (analysis) {
      documentPlans.set(personaPath, planDocument(personaDoc, analysis));
    }
  }

  // Plan schema documents
  for (const [schemaPath, schemaDoc] of graph.schemas) {
    const analysis = analyzedDocs.get(schemaPath);
    if (analysis) {
      documentPlans.set(schemaPath, planDocument(schemaDoc, analysis));
    }
  }

  // Classify and collect edges
  const edges: WorkflowEdge[] = graph.edges.map((edge) => {
    const conditionType = classifyEdgeCondition(
      edge.condition,
      edge.from,
      analyzedDocs,
    );
    return {
      from: edge.from,
      to: edge.to,
      condition: edge.condition,
      conditionType,
    };
  });

  // Detect self-loops and adjust circuit breaker if needed
  const circuitBreakerConfig = computeCircuitBreaker(edges);

  return {
    entryDocument: processPath,
    documentPlans,
    edges,
    circuitBreakerConfig,
    errors: graph.errors,
  };
}

// ── Helpers ──────────────────────────────────────────────────────

/**
 * Classify an edge condition as deterministic or semantic based on
 * the analyzed routing conditions of the source document.
 */
function classifyEdgeCondition(
  condition: string | undefined,
  fromPath: string,
  analyzedDocs: Map<string, AnalyzedDocument>,
): 'deterministic' | 'semantic' {
  if (!condition) return 'deterministic';

  // Guard route conditions (pass/fail) are always deterministic
  if (condition === 'pass' || condition === 'fail' || condition === 'default') {
    return 'deterministic';
  }

  // Check if the source document's analysis classified this condition
  const analysis = analyzedDocs.get(fromPath);
  if (analysis?.classifiedRouting) {
    const classified = analysis.classifiedRouting.find(
      (r) => r.raw === condition,
    );
    if (classified) {
      return classified.classification;
    }
  }

  // Default to semantic for unclassified conditions
  return 'semantic';
}

/**
 * Compute circuit breaker configuration based on the edge structure.
 * If self-loops are detected, use tighter limits.
 */
function computeCircuitBreaker(edges: WorkflowEdge[]): CircuitBreakerConfig {
  const hasSelfLoops = edges.some((e) => e.from === e.to);

  if (hasSelfLoops) {
    return {
      maxSelfLoops: 3,
      maxStepExecutions: 50,
    };
  }

  return { ...DEFAULT_CIRCUIT_BREAKER };
}
