// ── Document planner ──────────────────────────────────────────────
//
// Generates an execution plan for a single Talkdown document.
// The plan is a linear sequence of PlanNode objects that describe
// what the runtime should do to execute the document.

import type { TalkdownDocument, ExecutionBlock } from '../types/ast.js';
import type {
  AnalyzedDocument,
  ClassifiedGuardCheck,
} from '../types/compiled.js';

// ── Types ────────────────────────────────────────────────────────

export interface PlanNode {
  /** Unique node identifier within the document plan (n1, n2, ...). */
  id: string;
  /** The kind of operation this node performs. */
  kind: string;
  /** Human-readable label for display/debugging. */
  label: string;
  /** IDs of nodes whose outputs this node depends on. */
  inputs: string[];
  /** Whether this node runs deterministic code, calls an LLM, or both. */
  executionMode: 'deterministic' | 'llm' | 'hybrid';
  /** Kind-specific configuration. */
  config: Record<string, unknown>;
}

export interface DocumentPlan {
  /** Path to the source document. */
  documentPath: string;
  /** Ordered list of plan nodes. */
  nodes: PlanNode[];
  /** ID of the first node to execute. */
  entryNode: string;
}

// ── Node ID generator ────────────────────────────────────────────

class NodeIdGenerator {
  private counter = 0;

  next(): string {
    this.counter++;
    return `n${this.counter}`;
  }
}

// ── Plan builders ────────────────────────────────────────────────

function planStepOrDirective(
  doc: TalkdownDocument,
  analyzed: AnalyzedDocument,
  gen: NodeIdGenerator,
): PlanNode[] {
  const nodes: PlanNode[] = [];

  // 1. Validate inputs
  const validateNode: PlanNode = {
    id: gen.next(),
    kind: 'validate_inputs',
    label: 'Validate required inputs',
    inputs: [],
    executionMode: 'deterministic',
    config: {
      requiredInputs: (doc.frontmatter.inputs ?? [])
        .filter((i) => i.required)
        .map((i) => i.name),
    },
  };
  nodes.push(validateNode);

  // 2. Load persona (if referenced)
  let lastNodeId = validateNode.id;
  if (doc.frontmatter.persona) {
    const personaNode: PlanNode = {
      id: gen.next(),
      kind: 'load_persona',
      label: `Load persona: ${doc.frontmatter.persona}`,
      inputs: [lastNodeId],
      executionMode: 'deterministic',
      config: {
        personaRef: doc.frontmatter.persona,
      },
    };
    nodes.push(personaNode);
    lastNodeId = personaNode.id;
  }

  // 3. Execution blocks
  if (doc.execution) {
    for (const block of doc.execution) {
      const blockNodes = planExecutionBlock(block, lastNodeId, gen);
      nodes.push(...blockNodes);
      if (blockNodes.length > 0) {
        lastNodeId = blockNodes[blockNodes.length - 1].id;
      }
    }
  }

  // 4. Format output
  if (doc.output) {
    const formatNode: PlanNode = {
      id: gen.next(),
      kind: 'format_output',
      label: 'Format output',
      inputs: [lastNodeId],
      executionMode: 'deterministic',
      config: {
        outputDefs: doc.frontmatter.outputs ?? [],
      },
    };
    nodes.push(formatNode);
    lastNodeId = formatNode.id;
  }

  // 5. Evaluate routing (steps only)
  if (doc.routing && doc.frontmatter.type === 'step') {
    const routingMode = computeRoutingMode(analyzed);
    const routeNode: PlanNode = {
      id: gen.next(),
      kind: 'evaluate_routing',
      label: 'Evaluate routing',
      inputs: [lastNodeId],
      executionMode: routingMode,
      config: {
        routingKind: doc.routing.kind,
        classifiedRouting: analyzed.classifiedRouting ?? [],
      },
    };
    nodes.push(routeNode);
  }

  return nodes;
}

function planGuard(
  doc: TalkdownDocument,
  analyzed: AnalyzedDocument,
  gen: NodeIdGenerator,
): PlanNode[] {
  const nodes: PlanNode[] = [];

  // 1. Validate inputs
  const validateNode: PlanNode = {
    id: gen.next(),
    kind: 'validate_inputs',
    label: 'Validate guard inputs',
    inputs: [],
    executionMode: 'deterministic',
    config: {
      requiredInputs: (doc.frontmatter.inputs ?? [])
        .filter((i) => i.required)
        .map((i) => i.name),
    },
  };
  nodes.push(validateNode);

  // 2. Load persona (if referenced)
  let lastNodeId = validateNode.id;
  if (doc.frontmatter.persona) {
    const personaNode: PlanNode = {
      id: gen.next(),
      kind: 'load_persona',
      label: `Load persona: ${doc.frontmatter.persona}`,
      inputs: [lastNodeId],
      executionMode: 'deterministic',
      config: {
        personaRef: doc.frontmatter.persona,
      },
    };
    nodes.push(personaNode);
    lastNodeId = personaNode.id;
  }

  // 3. Guard checks
  const classifiedChecks = analyzed.classifiedChecks ?? [];
  const checkNodeIds: string[] = [];

  for (const classified of classifiedChecks) {
    const checkNodes = planGuardCheck(classified, lastNodeId, gen);
    nodes.push(...checkNodes);
    if (checkNodes.length > 0) {
      checkNodeIds.push(checkNodes[checkNodes.length - 1].id);
    }
  }

  // 4. Compute verdict
  const verdictInputs = checkNodeIds.length > 0 ? checkNodeIds : [lastNodeId];
  const verdictNode: PlanNode = {
    id: gen.next(),
    kind: 'compute_verdict',
    label: 'Compute guard verdict',
    inputs: verdictInputs,
    executionMode: 'deterministic',
    config: {
      verdictFields: doc.verdict?.fields ?? [],
    },
  };
  nodes.push(verdictNode);

  // 5. Evaluate routing (on_pass/on_fail)
  if (doc.routing) {
    const routeNode: PlanNode = {
      id: gen.next(),
      kind: 'evaluate_routing',
      label: 'Route based on verdict',
      inputs: [verdictNode.id],
      executionMode: 'deterministic',
      config: {
        routingKind: doc.routing.kind,
      },
    };
    nodes.push(routeNode);
  }

  return nodes;
}

// ── Execution block planning ─────────────────────────────────────

function planExecutionBlock(
  block: ExecutionBlock,
  prevNodeId: string,
  gen: NodeIdGenerator,
): PlanNode[] {
  switch (block.kind) {
    case 'nl_step':
      return [
        {
          id: gen.next(),
          kind: 'execute_nl_step',
          label: `Step ${block.number}: ${truncate(block.text, 50)}`,
          inputs: [prevNodeId],
          executionMode: 'llm',
          config: {
            stepNumber: block.number,
            text: block.text,
          },
        },
      ];

    case 'ai_block': {
      const expandId = gen.next();
      const execId = gen.next();
      return [
        {
          id: expandId,
          kind: 'template_expand',
          label: 'Expand AI template',
          inputs: [prevNodeId],
          executionMode: 'deterministic',
          config: {
            template: block.template,
          },
        },
        {
          id: execId,
          kind: 'execute_ai_block',
          label: 'Execute AI block',
          inputs: [expandId],
          executionMode: 'llm',
          config: {},
        },
      ];
    }

    case 'code_block':
      return [
        {
          id: gen.next(),
          kind: 'execute_code_block',
          label: `Execute ${block.language} code`,
          inputs: [prevNodeId],
          executionMode: 'deterministic',
          config: {
            language: block.language,
            source: block.source,
          },
        },
      ];
  }
}

// ── Guard check planning ─────────────────────────────────────────

function planGuardCheck(
  classified: ClassifiedGuardCheck,
  prevNodeId: string,
  gen: NodeIdGenerator,
): PlanNode[] {
  const nodes: PlanNode[] = [];
  const check = classified.original;

  switch (classified.classification) {
    case 'deterministic': {
      const node: PlanNode = {
        id: gen.next(),
        kind: 'deterministic_check',
        label: `Check: ${truncate(check.title, 40)}`,
        inputs: [prevNodeId],
        executionMode: 'deterministic',
        config: {
          checkNumber: check.number,
          title: check.title,
          gates: classified.deterministicGates,
        },
      };
      nodes.push(node);
      break;
    }

    case 'semantic': {
      const node: PlanNode = {
        id: gen.next(),
        kind: 'llm_guard_check',
        label: `LLM check: ${truncate(check.title, 40)}`,
        inputs: [prevNodeId],
        executionMode: 'llm',
        config: {
          checkNumber: check.number,
          title: check.title,
          description: check.description,
          semanticResidual: classified.semanticResidual,
        },
      };
      nodes.push(node);
      break;
    }

    case 'hybrid': {
      // First: deterministic gate check
      const detNode: PlanNode = {
        id: gen.next(),
        kind: 'deterministic_check',
        label: `Gate: ${truncate(check.title, 40)}`,
        inputs: [prevNodeId],
        executionMode: 'deterministic',
        config: {
          checkNumber: check.number,
          title: check.title,
          gates: classified.deterministicGates,
        },
      };
      nodes.push(detNode);

      // Then: conditional LLM check (only runs if gate passes)
      const llmNode: PlanNode = {
        id: gen.next(),
        kind: 'llm_guard_check',
        label: `LLM check (conditional): ${truncate(check.title, 40)}`,
        inputs: [detNode.id],
        executionMode: 'llm',
        config: {
          checkNumber: check.number,
          title: check.title,
          description: check.description,
          semanticResidual: classified.semanticResidual,
          conditional: true,
        },
      };
      nodes.push(llmNode);
      break;
    }
  }

  return nodes;
}

// ── Helpers ──────────────────────────────────────────────────────

function computeRoutingMode(
  analyzed: AnalyzedDocument,
): 'deterministic' | 'llm' | 'hybrid' {
  if (!analyzed.classifiedRouting || analyzed.classifiedRouting.length === 0) {
    return 'deterministic';
  }

  const hasDet = analyzed.classifiedRouting.some(
    (r) => r.classification === 'deterministic',
  );
  const hasSem = analyzed.classifiedRouting.some(
    (r) => r.classification === 'semantic',
  );

  if (hasDet && hasSem) return 'hybrid';
  if (hasSem) return 'llm';
  return 'deterministic';
}

function truncate(text: string, maxLen: number): string {
  const oneLine = text.replace(/\n/g, ' ').trim();
  if (oneLine.length <= maxLen) return oneLine;
  return oneLine.slice(0, maxLen - 3) + '...';
}

// ── Public API ───────────────────────────────────────────────────

/**
 * Generate an execution plan for a single Talkdown document.
 *
 * The plan is a linear sequence of {@link PlanNode} objects in
 * execution order. The shape of the plan depends on the document
 * type: steps/directives produce execution-block nodes, while
 * guards produce check nodes with a verdict aggregation.
 *
 * @param doc - The parsed Talkdown document
 * @param analyzed - The analyzed version of the same document
 * @returns A DocumentPlan with ordered nodes
 */
export function planDocument(
  doc: TalkdownDocument,
  analyzed: AnalyzedDocument,
): DocumentPlan {
  const gen = new NodeIdGenerator();
  let nodes: PlanNode[];

  const docType = doc.frontmatter.type;

  switch (docType) {
    case 'guard':
      nodes = planGuard(doc, analyzed, gen);
      break;

    case 'step':
    case 'directive':
      nodes = planStepOrDirective(doc, analyzed, gen);
      break;

    default:
      // For other document types (process, persona, schema, trigger, test),
      // generate a minimal plan with just input validation.
      nodes = [
        {
          id: gen.next(),
          kind: 'validate_inputs',
          label: `Validate ${docType} inputs`,
          inputs: [],
          executionMode: 'deterministic',
          config: {
            requiredInputs: (doc.frontmatter.inputs ?? [])
              .filter((i) => i.required)
              .map((i) => i.name),
          },
        },
      ];
      break;
  }

  return {
    documentPath: doc.filePath,
    nodes,
    entryNode: nodes.length > 0 ? nodes[0].id : '',
  };
}
