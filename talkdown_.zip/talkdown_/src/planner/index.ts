// ── Planner entry point ───────────────────────────────────────────
//
// Orchestrates the full planning pipeline: load workflow graph,
// analyze each document, plan each document, combine into a
// WorkflowPlan.

import type { AnalyzedDocument } from '../types/compiled.js';
import { analyzeDocument } from '../analyzer/index.js';
import { resolveWorkflow, DocumentLoader } from '../resolver/index.js';
import { planDocument } from './document-planner.js';
import { planWorkflow } from './workflow-planner.js';
import type { WorkflowPlan } from './workflow-planner.js';
import type { DocumentPlan, PlanNode } from './document-planner.js';

// ── Re-exports ───────────────────────────────────────────────────

export { planDocument } from './document-planner.js';
export type { DocumentPlan, PlanNode } from './document-planner.js';
export { planWorkflow } from './workflow-planner.js';
export type { WorkflowPlan, WorkflowEdge, CircuitBreakerConfig } from './workflow-planner.js';

// ── Public API ───────────────────────────────────────────────────

/**
 * Build a complete workflow plan from a process document path.
 *
 * This is the main entry point for the planning pipeline. It:
 * 1. Resolves the workflow graph (loads all referenced documents)
 * 2. Analyzes each document (classifies constraints/checks/routing)
 * 3. Plans each document (generates execution plan nodes)
 * 4. Combines everything into a WorkflowPlan
 *
 * @param processPath - Absolute path to the process document
 * @param loader - DocumentLoader instance to use for loading files
 * @returns A complete WorkflowPlan
 */
export async function buildPlan(
  processPath: string,
  loader: DocumentLoader,
): Promise<WorkflowPlan> {
  // 1. Resolve the workflow graph
  const graph = await resolveWorkflow(processPath, loader);

  // 2. Analyze each document
  const analyzedDocs = new Map<string, AnalyzedDocument>();

  // Analyze the process document
  analyzedDocs.set(graph.process.filePath, analyzeDocument(graph.process));

  // Analyze all step documents
  for (const [stepPath, stepDoc] of graph.steps) {
    analyzedDocs.set(stepPath, analyzeDocument(stepDoc));
  }

  // Analyze persona documents
  for (const [personaPath, personaDoc] of graph.personas) {
    analyzedDocs.set(personaPath, analyzeDocument(personaDoc));
  }

  // Analyze schema documents
  for (const [schemaPath, schemaDoc] of graph.schemas) {
    analyzedDocs.set(schemaPath, analyzeDocument(schemaDoc));
  }

  // 3. Combine into workflow plan
  const plan = planWorkflow(graph, analyzedDocs);

  return plan;
}
