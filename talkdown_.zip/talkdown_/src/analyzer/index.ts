import type { TalkdownDocument } from '../types/ast.js';
import type {
  AnalyzedDocument,
  ClassifiedCondition,
  ClassifiedConstraint,
  ClassifiedGuardCheck,
} from '../types/compiled.js';
import { classifyConstraint } from './constraint-classifier.js';
import { classifyGuardChecks } from './guard-classifier.js';
import { classifyRoutingCondition } from './routing-classifier.js';

// ── Re-exports ────────────────────────────────────────────────────

export { matchConstraint } from './pattern-matcher.js';
export { classifyConstraint } from './constraint-classifier.js';
export { classifyGuardCheck, classifyGuardChecks } from './guard-classifier.js';
export { classifyRoutingCondition } from './routing-classifier.js';

export type {
  ClassifiedConstraint,
  ClassifiedGuardCheck,
  ClassifiedCondition,
  AnalyzedDocument,
} from '../types/compiled.js';

// ── Helpers ───────────────────────────────────────────────────────

function extractRoutingConditions(doc: TalkdownDocument): string[] {
  if (!doc.routing || doc.routing.kind !== 'conditional') {
    return [];
  }
  return doc.routing.branches.map((b) => b.condition);
}

// ── Public API ────────────────────────────────────────────────────

/**
 * Analyze an entire TalkdownDocument, dispatching to the appropriate
 * sub-classifiers based on document type. Returns an AnalyzedDocument
 * with classified elements and aggregate statistics.
 */
export function analyzeDocument(doc: TalkdownDocument): AnalyzedDocument {
  let classifiedConstraints: ClassifiedConstraint[] | undefined;
  let classifiedChecks: ClassifiedGuardCheck[] | undefined;
  let classifiedRouting: ClassifiedCondition[] | undefined;

  const docType = doc.frontmatter.type;

  // Schema documents: classify constraints
  if (docType === 'schema' && doc.constraints) {
    classifiedConstraints = doc.constraints.map((c) =>
      classifyConstraint({ raw: c.raw })
    );
  }

  // Guard documents: classify checks and routing conditions
  if (docType === 'guard') {
    if (doc.checks) {
      classifiedChecks = classifyGuardChecks(doc.checks);
    }

    const conditions = extractRoutingConditions(doc);
    if (conditions.length > 0) {
      classifiedRouting = conditions.map(classifyRoutingCondition);
    }
  }

  // Steps with conditional routing: classify routing conditions
  if (docType === 'step') {
    const conditions = extractRoutingConditions(doc);
    if (conditions.length > 0) {
      classifiedRouting = conditions.map(classifyRoutingCondition);
    }
  }

  // Compute aggregate statistics
  const stats = computeStats(
    classifiedConstraints,
    classifiedChecks,
    classifiedRouting,
  );

  return {
    document: doc,
    classifiedConstraints,
    classifiedChecks,
    classifiedRouting,
    stats,
  };
}

// ── Statistics ────────────────────────────────────────────────────

function computeStats(
  constraints?: ClassifiedConstraint[],
  checks?: ClassifiedGuardCheck[],
  routing?: ClassifiedCondition[],
): AnalyzedDocument['stats'] {
  let totalElements = 0;
  let deterministic = 0;
  let semantic = 0;
  let hybrid = 0;

  if (constraints) {
    for (const c of constraints) {
      totalElements++;
      if (c.classification === 'deterministic') {
        deterministic++;
      } else {
        semantic++;
      }
    }
  }

  if (checks) {
    for (const c of checks) {
      totalElements++;
      switch (c.classification) {
        case 'deterministic':
          deterministic++;
          break;
        case 'semantic':
          semantic++;
          break;
        case 'hybrid':
          hybrid++;
          break;
      }
    }
  }

  if (routing) {
    for (const c of routing) {
      totalElements++;
      if (c.classification === 'deterministic') {
        deterministic++;
      } else {
        semantic++;
      }
    }
  }

  return { totalElements, deterministic, semantic, hybrid };
}
