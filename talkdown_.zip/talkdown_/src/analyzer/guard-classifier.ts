import type { GuardCheck } from '../types/ast.js';
import type { ClassifiedGuardCheck, CompiledExpr } from '../types/compiled.js';
import { matchConstraint } from './pattern-matcher.js';

// ── Helpers ───────────────────────────────────────────────────────

/**
 * Split a guard check description into sentences or clauses
 * to allow partial (hybrid) matching. Splits on period, semicolon,
 * or " and " at clause boundaries.
 */
function splitClauses(text: string): string[] {
  return text
    .split(/(?:\.\s+|\s*;\s*|\s+and\s+(?=[A-Z]))/g)
    .map((s) => s.trim())
    .filter(Boolean);
}

// ── Public API ────────────────────────────────────────────────────

/**
 * Classify a single guard check as deterministic, semantic, or hybrid.
 *
 * The check description is matched against known patterns. If the
 * entire description matches, it is deterministic. If no part matches,
 * it is semantic. If only part matches, it is hybrid -- the matched
 * portions become deterministic gates and the remainder becomes the
 * semantic residual.
 */
export function classifyGuardCheck(check: GuardCheck): ClassifiedGuardCheck {
  // First, try to match the entire description as one constraint.
  const fullMatch = matchConstraint(check.description);

  if (fullMatch) {
    return {
      original: check,
      classification: 'deterministic',
      deterministicGates: [fullMatch.compiled],
      semanticResidual: null,
    };
  }

  // Try clause-level matching for hybrid detection.
  const clauses = splitClauses(check.description);

  // Only attempt hybrid splitting if there are multiple clauses.
  if (clauses.length > 1) {
    const deterministicGates: CompiledExpr[] = [];
    const semanticClauses: string[] = [];

    for (const clause of clauses) {
      const result = matchConstraint(clause);
      if (result) {
        deterministicGates.push(result.compiled);
      } else {
        semanticClauses.push(clause);
      }
    }

    if (deterministicGates.length > 0 && semanticClauses.length > 0) {
      return {
        original: check,
        classification: 'hybrid',
        deterministicGates,
        semanticResidual: semanticClauses.join('. '),
      };
    }

    if (deterministicGates.length > 0 && semanticClauses.length === 0) {
      return {
        original: check,
        classification: 'deterministic',
        deterministicGates,
        semanticResidual: null,
      };
    }
  }

  // No patterns matched -- fully semantic.
  return {
    original: check,
    classification: 'semantic',
    deterministicGates: [],
    semanticResidual: check.description,
  };
}

/**
 * Classify an array of guard checks, mapping each through
 * classifyGuardCheck.
 */
export function classifyGuardChecks(
  checks: GuardCheck[],
): ClassifiedGuardCheck[] {
  return checks.map(classifyGuardCheck);
}
