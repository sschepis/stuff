import type { ClassifiedCondition } from '../types/compiled.js';
import { matchConstraint } from './pattern-matcher.js';

// ── Routing-specific patterns ─────────────────────────────────────

/**
 * Patterns that are specific to routing conditions (not general
 * constraints). These are checked before falling through to the
 * general pattern matcher.
 */

const verdictPattern = /^(?:the\s+)?verdict\s+is\s+[""`]?(\w+)[""`]?$/i;
const allChecksPattern = /^all\s+checks\s+pass(?:ed)?$/i;

// ── Public API ────────────────────────────────────────────────────

/**
 * Classify a routing condition string as deterministic or semantic.
 *
 * Routing conditions appear in conditional routes (e.g. "if the
 * verdict is approved, go to publish-step"). Recognizable patterns
 * like verdict comparisons are compiled to deterministic expressions.
 * Everything else is classified as semantic.
 */
export function classifyRoutingCondition(
  condition: string,
): ClassifiedCondition {
  const trimmed = condition.trim();

  // Check verdict pattern: "the verdict is X" / "verdict is X"
  const verdictMatch = trimmed.match(verdictPattern);
  if (verdictMatch) {
    return {
      raw: condition,
      classification: 'deterministic',
      compiled: {
        kind: 'field_equals',
        field: 'verdict',
        value: verdictMatch[1]!,
      },
    };
  }

  // Check "all checks pass" pattern
  if (allChecksPattern.test(trimmed)) {
    return {
      raw: condition,
      classification: 'deterministic',
      compiled: {
        kind: 'field_equals',
        field: '_all_checks',
        value: 'pass',
      },
    };
  }

  // Fall through to general pattern matcher
  const result = matchConstraint(trimmed);
  if (result) {
    return {
      raw: condition,
      classification: 'deterministic',
      compiled: result.compiled,
    };
  }

  // No pattern matched -- semantic routing
  return {
    raw: condition,
    classification: 'semantic',
  };
}
