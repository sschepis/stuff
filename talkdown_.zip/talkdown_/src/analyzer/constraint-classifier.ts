import type { ClassifiedConstraint } from '../types/compiled.js';
import { matchConstraint } from './pattern-matcher.js';

// ── Public API ────────────────────────────────────────────────────

/**
 * Classify a schema constraint as deterministic or semantic.
 *
 * If the constraint text matches a known deterministic pattern,
 * it is classified as 'deterministic' and the compiled expression
 * is attached. Otherwise it is classified as 'semantic' (requires
 * LLM evaluation at runtime).
 */
export function classifyConstraint(constraint: {
  raw: string;
}): ClassifiedConstraint {
  const result = matchConstraint(constraint.raw);

  if (result) {
    return {
      raw: constraint.raw,
      classification: 'deterministic',
      compiled: result.compiled,
    };
  }

  return {
    raw: constraint.raw,
    classification: 'semantic',
  };
}
