import type { CompiledExpr } from '../types/compiled.js';

// ── Helpers ───────────────────────────────────────────────────────

/** Strip backticks from a field name (e.g. `field_name` -> field_name). */
function stripBackticks(s: string): string {
  return s.replace(/`/g, '').trim();
}

/** Normalize whitespace in a string for matching. */
function norm(s: string): string {
  return s.replace(/\s+/g, ' ').trim();
}

// ── Rule definition ───────────────────────────────────────────────

interface MatchResult {
  compiled: CompiledExpr;
  matchedText: string;
}

interface PatternRule {
  name: string;
  pattern: RegExp;
  extract: (match: RegExpMatchArray, fieldContext?: string) => CompiledExpr;
}

// ── Pattern rules (priority order) ────────────────────────────────

const rules: PatternRule[] = [
  // 1. max_string_length
  //    "X must be no longer than N characters"
  //    "X is no more than N characters"
  //    "max N characters"
  {
    name: 'max_string_length',
    pattern:
      /(?:(?:`?(\w[\w\s]*\w|\w)`?)\s+(?:must be no longer than|is no more than)\s+(\d+)\s+characters|max\s+(\d+)\s+characters)/i,
    extract(match, fieldContext) {
      const field = match[1]
        ? stripBackticks(match[1])
        : fieldContext || 'value';
      const value = parseInt(match[2] || match[3]!, 10);
      return { kind: 'string_length', field, op: 'lte', value };
    },
  },

  // 2. word_count_range
  //    "X must be between N and M words"
  //    "between N and M words"
  {
    name: 'word_count_range',
    pattern:
      /(?:`?(\w[\w\s]*\w|\w)`?\s+must be\s+)?between\s+(\d+)\s+and\s+(\d+)\s+words/i,
    extract(match, fieldContext) {
      const field = match[1]
        ? stripBackticks(match[1])
        : fieldContext || 'body';
      const value = parseInt(match[2]!, 10);
      const value2 = parseInt(match[3]!, 10);
      return { kind: 'word_count', field, op: 'between', value, value2 };
    },
  },

  // 3. word_count_range_guard
  //    "word count between N and M"
  //    "word count N-M"
  {
    name: 'word_count_range_guard',
    pattern: /word\s+count\s+(?:between\s+(\d+)\s+and\s+(\d+)|(\d+)\s*[-–]\s*(\d+))/i,
    extract(match, fieldContext) {
      const field = fieldContext || 'body';
      const value = parseInt(match[1] || match[3]!, 10);
      const value2 = parseInt(match[2] || match[4]!, 10);
      return { kind: 'word_count', field, op: 'between', value, value2 };
    },
  },

  // 4. enum_membership
  //    "X must be one of: A, B, C"
  //    "X must be one of: "A", "B", "C"
  {
    name: 'enum_membership',
    pattern: /`?(\w[\w\s]*\w|\w)`?\s+must be one of:\s*(.+)/i,
    extract(match) {
      const field = stripBackticks(match[1]!);
      const listPart = match[2]!;
      const allowed = parseEnumList(listPart);
      return { kind: 'enum_check', field, allowed };
    },
  },

  // 5. not_empty
  //    "X must not be empty"
  //    "X must be non-empty"
  {
    name: 'not_empty',
    pattern: /`?(\w[\w\s]*\w|\w)`?\s+must\s+(?:not be empty|be non-empty)/i,
    extract(match) {
      const field = stripBackticks(match[1]!);
      return { kind: 'not_empty', field };
    },
  },

  // 6. populated
  //    "X is populated"
  //    "X is present"
  //    "X is non-empty"
  {
    name: 'populated',
    pattern: /`?(\w[\w\s]*\w|\w)`?\s+is\s+(?:populated|present|non-empty)/i,
    extract(match) {
      const field = stripBackticks(match[1]!);
      return { kind: 'populated', field };
    },
  },

  // 7. conditional_gt
  //    "if X > N, Y must be Z"
  //    "if X is greater than N, Y must be Z"
  {
    name: 'conditional_gt',
    pattern:
      /if\s+`?(\w[\w\s]*\w|\w)`?\s+(?:>|is greater than)\s+(\d+)\s*,\s*`?(\w[\w\s]*\w|\w)`?\s+must be\s+[""]?(\w[\w\s]*\w|\w)[""]?/i,
    extract(match) {
      const condField = stripBackticks(match[1]!);
      const condValue = parseInt(match[2]!, 10);
      const thenField = stripBackticks(match[3]!);
      const thenValue = match[4]!.trim();
      return {
        kind: 'conditional_rule',
        condition: {
          kind: 'numeric_compare',
          field: condField,
          op: 'gt',
          value: condValue,
        },
        then: {
          kind: 'field_equals',
          field: thenField,
          value: thenValue,
        },
      };
    },
  },

  // 8. sum_equality
  //    "X + Y + Z must equal length of W"
  //    "X + Y + Z must equal the length of W"
  {
    name: 'sum_equality',
    pattern:
      /(`?\w[\w\s]*\w`?(?:\s*\+\s*`?\w[\w\s]*\w`?)+)\s+must equal\s+(?:the\s+)?length of\s+`?(\w[\w\s]*\w|\w)`?/i,
    extract(match) {
      const fieldsRaw = match[1]!;
      const totalField = stripBackticks(match[2]!);
      const fields = fieldsRaw
        .split('+')
        .map((f) => stripBackticks(f.trim()));
      return {
        kind: 'sum_equality',
        fields,
        total: { kind: 'field_ref', field: totalField },
      };
    },
  },

  // 9. field_equality
  //    "if X is "value""
  {
    name: 'field_equality',
    pattern:
      /(?:if\s+)?`?(\w[\w\s]*\w|\w)`?\s+is\s+[""“](\w[\w\s]*\w|\w)[""”]/i,
    extract(match) {
      const field = stripBackticks(match[1]!);
      const value = match[2]!.trim();
      return { kind: 'field_equals', field, value };
    },
  },
];

// ── Enum list parser ──────────────────────────────────────────────

function parseEnumList(raw: string): string[] {
  // Handle values wrapped in backticks, double-quotes, smart-quotes,
  // or bare words, separated by commas. Strip trailing "and" before
  // the last item.
  const items: string[] = [];

  // Split on commas first
  const parts = raw.split(',').map((p) => p.trim()).filter(Boolean);

  for (const part of parts) {
    // Remove leading "and " or "or "
    let cleaned = part.replace(/^(?:and|or)\s+/i, '');

    // Strip surrounding quotes/backticks
    cleaned = cleaned
      .replace(/^[`""“”"']+/, '')
      .replace(/[`""“”"']+$/, '')
      .trim();

    if (cleaned) {
      items.push(cleaned);
    }
  }

  return items;
}

// ── Public API ────────────────────────────────────────────────────

/**
 * Attempt to match a natural-language constraint string against
 * known deterministic patterns. Returns the compiled expression
 * and the matched portion of text, or null if no pattern matches.
 */
export function matchConstraint(
  text: string,
  fieldContext?: string,
): MatchResult | null {
  const normalized = norm(text);

  for (const rule of rules) {
    const match = normalized.match(rule.pattern);
    if (match) {
      return {
        compiled: rule.extract(match, fieldContext),
        matchedText: match[0],
      };
    }
  }

  return null;
}
