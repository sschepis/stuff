import type { Routing, ConditionalBranch } from '../types/ast.js';

function stripBullet(line: string): string {
  return line.replace(/^-\s+/, '');
}

function stripQuotes(value: string): string {
  const trimmed = value.trim();
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

function splitKV(text: string): [string, string] | null {
  const idx = text.indexOf(': ');
  if (idx === -1) return null;
  return [text.slice(0, idx).trim(), text.slice(idx + 2).trim()];
}

/**
 * Parse the raw content of a ## Routing section into a Routing node.
 *
 * Recognises three patterns:
 *  - Linear:      `- next: ./path.md`  (or `- next: none` -> terminal)
 *  - Guard:       `- on_pass: ./path.md` + `- on_fail: ./path.md`
 *  - Conditional: `- if: "cond"` + `then: ./path.md` (repeatable)
 *                 + optional `- default: ./path.md`
 */
export function parseRouting(rawContent: string): Routing {
  const lines = rawContent.split('\n');
  const kvPairs: [string, string][] = [];

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;

    const stripped = stripBullet(line);
    const kv = splitKV(stripped);
    if (kv) {
      kvPairs.push(kv);
    }
  }

  const map = new Map<string, string>();
  const branches: ConditionalBranch[] = [];

  let i = 0;
  while (i < kvPairs.length) {
    const [key, value] = kvPairs[i];

    if (key === 'if') {
      const condition = stripQuotes(value);
      let thenPath = '';
      if (i + 1 < kvPairs.length && kvPairs[i + 1][0] === 'then') {
        thenPath = kvPairs[i + 1][1];
        i += 2;
      } else {
        i++;
      }
      branches.push({ condition, then: thenPath });
    } else {
      map.set(key, value);
      i++;
    }
  }

  // Guard route: on_pass + on_fail
  if (map.has('on_pass') && map.has('on_fail')) {
    return {
      kind: 'guard',
      onPass: map.get('on_pass')!,
      onFail: map.get('on_fail')!,
    };
  }

  // Conditional route: at least one if/then branch
  if (branches.length > 0) {
    return {
      kind: 'conditional',
      branches,
      default: map.get('default') ?? '',
    };
  }

  // Terminal route: next is "none"
  const next = map.get('next') ?? 'none';
  if (next === 'none') {
    return { kind: 'terminal' };
  }

  // Linear route
  return {
    kind: 'linear',
    next,
  };
}
