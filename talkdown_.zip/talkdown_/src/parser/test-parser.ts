import type { TestCase, TestInput, TestExpectation, TestAssertion } from '../types/ast.js';

/** Match ### Case N: name headings */
const CASE_HEADING = /^###\s+(?:Case\s+)?(\d+)[\s:.-]+(.+)/i;

/** Match backtick-quoted input field: `field_name`: value */
const INPUT_FIELD = /^-\s+`([^`]+)`:\s*(.*)/;

/** Match expected output with backtick field ref: `field_name` should/must/... */
const OUTPUT_FIELD = /^-\s+`([^`]+)`\s+(.*)/;

/** Match expected output without field ref: - raw text */
const OUTPUT_RAW = /^-\s+(.*)/;

const FENCE_OPEN = /^```(\w*)\s*$/;
const FENCE_CLOSE = /^```\s*$/;

/**
 * Parse the raw content of a ## Cases section into TestCase items.
 *
 * Each ### Case N: name subsection contains **Input:** and
 * **Expected Output:** subsections.
 */
export function parseTestCases(rawContent: string): TestCase[] {
  const lines = rawContent.split('\n');
  const cases: TestCase[] = [];

  let currentCase: { name: string; number: number } | null = null;
  let currentInputs: TestInput[] = [];
  let currentExpected: TestExpectation[] = [];
  let section: 'none' | 'input' | 'expected' = 'none';

  let i = 0;

  function flushCase() {
    if (currentCase) {
      cases.push({
        name: currentCase.name,
        number: currentCase.number,
        inputs: currentInputs,
        expected: currentExpected,
      });
    }
  }

  while (i < lines.length) {
    const cur = lines[i].trim();

    // Check for case heading
    const caseMatch = cur.match(CASE_HEADING);
    if (caseMatch) {
      flushCase();
      currentCase = {
        number: parseInt(caseMatch[1], 10),
        name: caseMatch[2].trim(),
      };
      currentInputs = [];
      currentExpected = [];
      section = 'none';
      i++;
      continue;
    }

    if (!currentCase) {
      i++;
      continue;
    }

    // Detect section markers
    if (cur.startsWith('**Input') && cur.includes(':')) {
      section = 'input';
      i++;
      continue;
    }
    if (cur.startsWith('**Expected Output') || cur.startsWith('**Expected')) {
      section = 'expected';
      i++;
      continue;
    }

    if (section === 'input') {
      const inputMatch = cur.match(INPUT_FIELD);
      if (inputMatch) {
        const fieldName = inputMatch[1];
        let valueText = inputMatch[2].trim();

        // Check if the value is a multiline fenced block
        if (valueText === '' || valueText === '\\') {
          const nextLine = i + 1 < lines.length ? lines[i + 1].trim() : '';
          if (FENCE_OPEN.test(nextLine)) {
            i += 2; // skip the input line and opening fence
            const blockLines: string[] = [];
            while (i < lines.length && !FENCE_CLOSE.test(lines[i].trim())) {
              blockLines.push(lines[i]);
              i++;
            }
            i++; // skip closing fence
            valueText = blockLines.join('\n').trim();
            currentInputs.push({ name: fieldName, value: valueText });
            continue;
          }
        }

        // Strip surrounding quotes for simple string values
        if (
          (valueText.startsWith('"') && valueText.endsWith('"')) ||
          (valueText.startsWith("'") && valueText.endsWith("'"))
        ) {
          valueText = valueText.slice(1, -1);
        }

        currentInputs.push({ name: fieldName, value: valueText });
        i++;
        continue;
      }
    }

    if (section === 'expected') {
      const fieldOutputMatch = cur.match(OUTPUT_FIELD);
      if (fieldOutputMatch) {
        currentExpected.push({
          field: fieldOutputMatch[1],
          condition: fieldOutputMatch[2].trim(),
        });
        i++;
        continue;
      }

      const rawOutputMatch = cur.match(OUTPUT_RAW);
      if (rawOutputMatch) {
        currentExpected.push({
          field: '',
          condition: rawOutputMatch[1].trim(),
        });
        i++;
        continue;
      }
    }

    i++;
  }

  flushCase();
  return cases;
}

/**
 * Parse the raw content of a ## Assertions section into TestAssertion
 * items.
 *
 * Each `- ` bullet line becomes a TestAssertion with the raw text.
 */
export function parseTestAssertions(rawContent: string): TestAssertion[] {
  const assertions: TestAssertion[] = [];
  const lines = rawContent.split('\n');

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      assertions.push({ text: trimmed.slice(2).trim() });
    }
  }

  return assertions;
}
