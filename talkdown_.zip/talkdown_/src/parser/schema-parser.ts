import type { SchemaField, SchemaConstraint } from '../types/ast.js';

/** Strip backtick quoting from a field name: `field_name` -> field_name */
function stripBackticks(s: string): string {
  const trimmed = s.trim();
  if (trimmed.startsWith('`') && trimmed.endsWith('`')) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

/** Determine if a line is a Markdown table separator (e.g. |---|---|). */
function isTableSeparator(line: string): boolean {
  return /^\|[\s\-:|]+\|$/.test(line.trim());
}

/** Parse a single table row into cell values. */
function parseTableRow(line: string): string[] {
  const trimmed = line.trim();
  const inner = trimmed.replace(/^\|/, '').replace(/\|$/, '');
  return inner.split('|').map((cell) => cell.trim());
}

/**
 * Parse a Markdown table (header + separator + rows) starting at the
 * given line index. Returns the parsed rows (excluding header and
 * separator) and the index after the table.
 */
function parseTable(lines: string[], startIdx: number): { rows: string[][]; endIdx: number } {
  const rows: string[][] = [];
  let i = startIdx;

  // Skip lines until we find a table header row (starts with |)
  while (i < lines.length && !lines[i].trim().startsWith('|')) {
    i++;
  }

  if (i >= lines.length) return { rows, endIdx: i };

  // Skip header row
  i++;

  // Skip separator row
  if (i < lines.length && isTableSeparator(lines[i])) {
    i++;
  }

  // Parse data rows
  while (i < lines.length && lines[i].trim().startsWith('|')) {
    rows.push(parseTableRow(lines[i]));
    i++;
  }

  return { rows, endIdx: i };
}

/**
 * Parse the raw content of a ## Fields section into an array of
 * SchemaField definitions.
 *
 * Handles a primary Markdown table with columns:
 *   | Field | Type | Required | Description |
 *
 * If ### subsection headings exist (e.g. `### nested_object`), their
 * tables are attached as subfields of the matching parent field.
 */
export function parseSchemaFields(rawContent: string): SchemaField[] {
  const lines = rawContent.split('\n');
  const fields: SchemaField[] = [];
  const fieldsByName = new Map<string, SchemaField>();

  let i = 0;

  // Parse the primary table first (before any ### headings)
  while (i < lines.length) {
    const line = lines[i].trim();

    // Stop at first ### subsection
    if (line.startsWith('### ')) break;

    // Found a table header row
    if (line.startsWith('|')) {
      const { rows, endIdx } = parseTable(lines, i);

      for (const cells of rows) {
        if (cells.length < 4) continue;
        const field: SchemaField = {
          name: stripBackticks(cells[0]),
          type: cells[1].trim(),
          required: cells[2].trim().toLowerCase() === 'yes',
          description: cells[3].trim(),
        };
        fields.push(field);
        fieldsByName.set(field.name, field);
      }

      i = endIdx;
      continue;
    }

    i++;
  }

  // Parse ### subsections for nested object fields
  while (i < lines.length) {
    const line = lines[i].trim();

    if (line.startsWith('### ')) {
      const parentName = stripBackticks(line.slice(4).trim());
      i++;

      const { rows, endIdx } = parseTable(lines, i);
      const subfields: SchemaField[] = [];

      for (const cells of rows) {
        if (cells.length < 4) continue;
        subfields.push({
          name: stripBackticks(cells[0]),
          type: cells[1].trim(),
          required: cells[2].trim().toLowerCase() === 'yes',
          description: cells[3].trim(),
        });
      }

      // Attach subfields to the parent field if it exists
      const parent = fieldsByName.get(parentName);
      if (parent) {
        parent.subfields = subfields;
      } else if (subfields.length > 0) {
        // Create a synthetic parent if one wasn't in the main table
        const syntheticParent: SchemaField = {
          name: parentName,
          type: 'object',
          required: false,
          description: '',
          subfields,
        };
        fields.push(syntheticParent);
        fieldsByName.set(parentName, syntheticParent);
      }

      i = endIdx;
      continue;
    }

    i++;
  }

  return fields;
}

/**
 * Parse the raw content of a ## Constraints section into an array
 * of SchemaConstraint items.
 *
 * Each `- ` bullet line becomes a constraint with the raw text
 * preserved (including any backtick-quoted field references).
 */
export function parseSchemaConstraints(rawContent: string): SchemaConstraint[] {
  const constraints: SchemaConstraint[] = [];
  const lines = rawContent.split('\n');

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      constraints.push({ raw: trimmed.slice(2).trim() });
    }
  }

  return constraints;
}
