import type { GuardCheck, AIBlock } from '../types/ast.js';
import { parseTemplate } from './template-parser.js';

export interface GuardChecksResult {
  checks: GuardCheck[];
  aiBlock?: AIBlock;
}

/** Match numbered items with bold title: `1. **Title**: description` */
const NUMBERED_CHECK = /^(\d+)\.\s+\*\*(.+?)\*\*\s*[-:]\s*(.*)/;

/** Match numbered items without bold title: `1. Description text` */
const NUMBERED_PLAIN = /^(\d+)\.\s+(.*)/;

const FENCE_OPEN = /^```(\w*)\s*$/;
const FENCE_CLOSE = /^```\s*$/;

/**
 * Parse the raw content of a ## Checks section.
 *
 * Returns an array of GuardCheck items and an optional AIBlock
 * (the evaluation prompt enclosed in ```ai fences).
 */
export function parseGuardChecks(rawContent: string): GuardChecksResult {
  const lines = rawContent.split('\n');
  const checks: GuardCheck[] = [];
  let aiBlock: AIBlock | undefined;

  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // -- Fenced block --
    const fenceMatch = line.match(FENCE_OPEN);
    if (fenceMatch) {
      const language = fenceMatch[1] || '';
      const contentLines: string[] = [];
      i++; // skip opening fence

      while (i < lines.length && !FENCE_CLOSE.test(lines[i])) {
        contentLines.push(lines[i]);
        i++;
      }
      i++; // skip closing fence

      if (language === 'ai') {
        const raw = contentLines.join('\n');
        aiBlock = {
          kind: 'ai_block',
          template: parseTemplate(raw),
        };
      }

      continue;
    }

    // -- Numbered check with bold title --
    const boldMatch = line.match(NUMBERED_CHECK);
    if (boldMatch) {
      const number = parseInt(boldMatch[1], 10);
      const title = boldMatch[2];
      const descLines: string[] = [boldMatch[3]];
      i++;

      // Gather continuation lines (non-numbered, non-fenced)
      while (i < lines.length) {
        const next = lines[i];
        if (NUMBERED_CHECK.test(next) || FENCE_OPEN.test(next)) {
          break;
        }
        descLines.push(next);
        i++;
      }

      // Trim trailing blank lines
      while (descLines.length > 0 && descLines[descLines.length - 1].trim() === '') {
        descLines.pop();
      }

      const description = descLines.join('\n').trim();
      checks.push({
        number,
        title,
        description,
        classification: 'semantic',
      });

      continue;
    }

    // -- Numbered check without bold title (plain) --
    const plainMatch = line.match(NUMBERED_PLAIN);
    if (plainMatch) {
      const number = parseInt(plainMatch[1], 10);
      const descLines: string[] = [plainMatch[2]];
      i++;

      while (i < lines.length) {
        const next = lines[i];
        if (NUMBERED_CHECK.test(next) || FENCE_OPEN.test(next)) {
          break;
        }
        descLines.push(next);
        i++;
      }

      while (descLines.length > 0 && descLines[descLines.length - 1].trim() === '') {
        descLines.pop();
      }

      const description = descLines.join('\n').trim();
      checks.push({
        number,
        title: '',
        description,
        classification: 'semantic',
      });

      continue;
    }

    // -- Skip blank / non-matching lines --
    i++;
  }

  return { checks, aiBlock };
}
