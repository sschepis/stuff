import type { OutputDescription, OutputSpec } from '../types/ast.js';

// ── Regular expressions ──────────────────────────────────────────

/**
 * Match output bullet format:
 *   - **output_name** (type): description
 *   - **output_name** (type, schema: ...): description
 */
const OUTPUT_PATTERN = /^-\s+\*\*(\w+)\*\*\s+\(([^)]+)\):\s*(.*)/;

/** Match ### Output Format subsection heading */
const FORMAT_HEADING = /^###\s+Output\s+Format/i;

/**
 * Parse the raw content of a ## Output section into an OutputSpec.
 *
 * Extracts bullet-item output descriptions and an optional
 * ### Output Format subsection.
 */
export function parseOutputSection(rawContent: string): OutputSpec {
  const lines = rawContent.split('\n');
  const descriptions: OutputDescription[] = [];
  let format: string | undefined;

  let i = 0;
  let inFormatSection = false;
  const formatLines: string[] = [];

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    // Check for ### Output Format heading
    if (FORMAT_HEADING.test(trimmed)) {
      inFormatSection = true;
      i++;
      continue;
    }

    // If another ### heading appears, stop the format section
    if (inFormatSection && trimmed.startsWith('### ')) {
      inFormatSection = false;
    }

    if (inFormatSection) {
      formatLines.push(line);
      i++;
      continue;
    }

    // Parse output description bullets
    const match = trimmed.match(OUTPUT_PATTERN);
    if (match) {
      const name = match[1];
      const parenContent = match[2];
      const description = match[3].trim();

      // Extract just the type (first comma-separated part)
      const type = parenContent.split(',')[0].trim();

      descriptions.push({ name, type, description });
    }

    i++;
  }

  // Build the format string if we collected any content
  if (formatLines.length > 0) {
    const trimmedFormat = formatLines.join('\n').trim();
    if (trimmedFormat) {
      format = trimmedFormat;
    }
  }

  const result: OutputSpec = { descriptions };
  if (format !== undefined) {
    result.format = format;
  }
  return result;
}
