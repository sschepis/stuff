/**
 * Error thrown when parsing a Talkdown document fails.
 *
 * Carries optional location metadata so callers can produce
 * human-readable diagnostics.
 */
export class TalkdownParseError extends Error {
  /** Absolute or relative path of the file being parsed (if known). */
  filePath?: string;
  /** 1-based line number where the error was detected (if known). */
  line?: number;

  constructor(message: string, options?: { filePath?: string; line?: number }) {
    super(message);
    this.name = 'TalkdownParseError';
    this.filePath = options?.filePath;
    this.line = options?.line;

    // Restore prototype chain (required when extending built-ins in TS).
    Object.setPrototypeOf(this, TalkdownParseError.prototype);
  }
}
