import type { VerdictField, VerdictSpec } from '../types/ast.js';

// ── Regular expressions ──────────────────────────────────────────

/**
 * Match verdict bullet format:
 *   - **field_name** (type): description
 *   - **field_name**: description
 */
const VERDICT_PATTERN = /^-\s+\*\*(\w+)\*\*(?:\s+\([^)]+\))?:\s*(.*)/;

/**
 * Parse the raw content of a ## Verdict section into a VerdictSpec.
 *
 * Each bullet item follows the format:
 *   `- **field_name** (type): description text`
 * or simply:
 *   `- **field_name**: description text`
 */
export function parseVerdict(rawContent: string): VerdictSpec {
  const fields: VerdictField[] = [];
  const lines = rawContent.split('\n');

  for (const line of lines) {
    const trimmed = line.trim();
    const match = trimmed.match(VERDICT_PATTERN);
    if (!match) continue;

    fields.push({
      name: match[1],
      description: match[2].trim(),
    });
  }

  return { fields };
}
