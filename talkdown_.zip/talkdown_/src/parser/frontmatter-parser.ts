import { parse } from 'yaml';
import type {
  DocumentType,
  Frontmatter,
  InputDeclaration,
  InputType,
  OutputDeclaration,
  OutputType,
} from '../types/ast.js';
import { TalkdownParseError } from './errors.js';

// ── Constants ──────────────────────────────────────────────────────

const VALID_TYPES: readonly DocumentType[] = [
  'directive',
  'step',
  'process',
  'guard',
  'persona',
  'schema',
  'trigger',
  'test',
] as const;

const VALID_INPUT_TYPES: readonly InputType[] = ['text', 'file', 'data', 'url'];
const VALID_OUTPUT_TYPES: readonly OutputType[] = ['text', 'file', 'data'];

// ── Helpers ────────────────────────────────────────────────────────

function isRecord(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function requireString(
  obj: Record<string, unknown>,
  key: string,
  context: string,
): string {
  const val = obj[key];
  if (typeof val !== 'string' || val.trim().length === 0) {
    throw new TalkdownParseError(
      `${context}: "${key}" is required and must be a non-empty string`,
    );
  }
  return val;
}

function parseInputEntry(raw: unknown, index: number): InputDeclaration {
  if (!isRecord(raw)) {
    throw new TalkdownParseError(
      `inputs[${index}] must be an object, got ${typeof raw}`,
    );
  }

  const name = requireString(raw, 'name', `inputs[${index}]`);
  const typeVal = requireString(raw, 'type', `inputs[${index}]`);
  if (!(VALID_INPUT_TYPES as readonly string[]).includes(typeVal)) {
    throw new TalkdownParseError(
      `inputs[${index}].type must be one of ${VALID_INPUT_TYPES.join(', ')}, got "${typeVal}"`,
    );
  }
  const description = requireString(raw, 'description', `inputs[${index}]`);

  const required =
    raw['required'] !== undefined ? Boolean(raw['required']) : false;

  const schema =
    typeof raw['schema'] === 'string' ? raw['schema'] : undefined;

  return {
    name,
    type: typeVal as InputType,
    required,
    description,
    ...(schema !== undefined && { schema }),
  };
}

function parseOutputEntry(raw: unknown, index: number): OutputDeclaration {
  if (!isRecord(raw)) {
    throw new TalkdownParseError(
      `outputs[${index}] must be an object, got ${typeof raw}`,
    );
  }

  const name = requireString(raw, 'name', `outputs[${index}]`);
  const typeVal = requireString(raw, 'type', `outputs[${index}]`);
  if (!(VALID_OUTPUT_TYPES as readonly string[]).includes(typeVal)) {
    throw new TalkdownParseError(
      `outputs[${index}].type must be one of ${VALID_OUTPUT_TYPES.join(', ')}, got "${typeVal}"`,
    );
  }
  const description = requireString(raw, 'description', `outputs[${index}]`);

  const schema =
    typeof raw['schema'] === 'string' ? raw['schema'] : undefined;

  return {
    name,
    type: typeVal as OutputType,
    description,
    ...(schema !== undefined && { schema }),
  };
}

// ── Public API ─────────────────────────────────────────────────────

/**
 * Parse a YAML string (the content between the `---` fences) into a
 * validated {@link Frontmatter} object.
 */
export function parseFrontmatter(yaml: string): Frontmatter {
  let raw: unknown;
  try {
    raw = parse(yaml);
  } catch (err) {
    throw new TalkdownParseError(
      `Invalid YAML in frontmatter: ${(err as Error).message}`,
    );
  }

  if (!isRecord(raw)) {
    throw new TalkdownParseError(
      'Frontmatter must be a YAML mapping (key: value pairs)',
    );
  }

  // ── type ──
  const typeVal = requireString(raw, 'type', 'frontmatter');
  if (!(VALID_TYPES as readonly string[]).includes(typeVal)) {
    throw new TalkdownParseError(
      `frontmatter.type must be one of ${VALID_TYPES.join(', ')}, got "${typeVal}"`,
    );
  }

  // ── title & description ──
  const title = requireString(raw, 'title', 'frontmatter');
  const description = requireString(raw, 'description', 'frontmatter');

  // ── inputs ──
  let inputs: InputDeclaration[] = [];
  if (raw['inputs'] !== undefined) {
    if (!Array.isArray(raw['inputs'])) {
      throw new TalkdownParseError('frontmatter.inputs must be an array');
    }
    inputs = (raw['inputs'] as unknown[]).map(parseInputEntry);
  }

  // ── outputs ──
  let outputs: OutputDeclaration[] = [];
  if (raw['outputs'] !== undefined) {
    if (!Array.isArray(raw['outputs'])) {
      throw new TalkdownParseError('frontmatter.outputs must be an array');
    }
    outputs = (raw['outputs'] as unknown[]).map(parseOutputEntry);
  }

  // ── tags ──
  let tags: string[] = [];
  if (raw['tags'] !== undefined) {
    if (!Array.isArray(raw['tags'])) {
      throw new TalkdownParseError('frontmatter.tags must be an array');
    }
    tags = (raw['tags'] as unknown[]).map((t, i) => {
      if (typeof t !== 'string') {
        throw new TalkdownParseError(
          `frontmatter.tags[${i}] must be a string, got ${typeof t}`,
        );
      }
      return t;
    });
  }

  // ── optional string fields ──
  const persona =
    typeof raw['persona'] === 'string' ? raw['persona'] : undefined;
  const target =
    typeof raw['target'] === 'string' ? raw['target'] : undefined;

  return {
    type: typeVal as DocumentType,
    title,
    description,
    inputs,
    outputs,
    tags,
    ...(persona !== undefined && { persona }),
    ...(target !== undefined && { target }),
  };
}
