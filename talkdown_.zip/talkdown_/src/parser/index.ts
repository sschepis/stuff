import type { TalkdownDocument, Section } from '../types/ast.js';
import { splitMarkdown } from './markdown-splitter.js';
import { parseFrontmatter } from './frontmatter-parser.js';
import { parseSections, findSection } from './section-parser.js';
import { parseExecution } from './execution-parser.js';
import { parseRouting } from './routing-parser.js';
import { parseGuardChecks } from './guard-parser.js';
import { parseSchemaFields, parseSchemaConstraints } from './schema-parser.js';
import { parseTestCases, parseTestAssertions } from './test-parser.js';
import { parseInputSection } from './input-parser.js';
import { parseOutputSection } from './output-parser.js';
import { parseVerdict } from './verdict-parser.js';
import { TalkdownParseError } from './errors.js';

function extractIntroduction(sections: Section[]): string {
  const h1 = sections.find(s => s.level === 1);
  if (!h1) return '';
  const lines = h1.rawContent.split('\n');
  const introLines: string[] = [];
  for (const line of lines) {
    if (line.trim().startsWith('## ')) break;
    introLines.push(line);
  }
  return introLines.join('\n').trim();
}

function sectionContent(sections: Section[], heading: string): string | undefined {
  const s = findSection(sections, heading);
  return s?.rawContent?.trim() || undefined;
}

function parseProcessSteps(rawContent: string): { number: number; name: string; path: string; description: string }[] {
  const steps: { number: number; name: string; path: string; description: string }[] = [];
  const lines = rawContent.split('\n');

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed.startsWith('|') || trimmed.includes('---')) continue;

    const cells = trimmed.replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim());
    if (cells.length < 3) continue;

    const stepNum = parseInt(cells[0], 10);
    if (isNaN(stepNum)) continue;

    const linkMatch = cells[1].match(/\[([^\]]+)\]\(([^)]+)\)/);
    const name = linkMatch ? linkMatch[1] : cells[1];
    const path = linkMatch ? linkMatch[2] : '';

    const descIdx = cells.length >= 4 ? (cells.length === 5 ? 4 : 3) : 2;
    const description = cells[descIdx] ?? '';

    steps.push({ number: stepNum, name, path, description });
  }

  return steps;
}

function parseTriggerEvent(rawContent: string): { source: string; condition: string; frequency: string } {
  const result = { source: '', condition: '', frequency: '' };
  const lines = rawContent.split('\n');

  for (const line of lines) {
    const trimmed = line.trim().replace(/^[-*]\s+/, '');
    const sourceMatch = trimmed.match(/^\*\*Source\*\*[:\s]+(.*)/i);
    if (sourceMatch) result.source = sourceMatch[1].trim();
    const condMatch = trimmed.match(/^\*\*Condition\*\*[:\s]+(.*)/i);
    if (condMatch) result.condition = condMatch[1].trim();
    const freqMatch = trimmed.match(/^\*\*Frequency\*\*[:\s]+(.*)/i);
    if (freqMatch) result.frequency = freqMatch[1].trim();
  }

  return result;
}

function parseTriggerTarget(rawContent: string): { process: string; mappings: { from: string; to: string }[] } {
  const result: { process: string; mappings: { from: string; to: string }[] } = {
    process: '',
    mappings: [],
  };
  const lines = rawContent.split('\n');

  for (const line of lines) {
    const trimmed = line.trim().replace(/^[-*]\s+/, '');
    const processMatch = trimmed.match(/^\*\*Process\*\*[:\s]+\[?([^\]]+)\]?/i);
    if (processMatch) result.process = processMatch[1].trim();

    const mappingMatch = trimmed.match(/^\*\*Input mapping\*\*[:\s]+(.*)/i);
    if (mappingMatch) {
      const pairs = mappingMatch[1].split(',');
      for (const pair of pairs) {
        const parts = pair.split('->').map(s => s.trim());
        if (parts.length === 2) {
          result.mappings.push({ from: parts[0], to: parts[1] });
        }
      }
    }
  }

  return result;
}

function parseSchemaExample(rawContent: string): unknown {
  const lines = rawContent.split('\n');
  let inFence = false;
  const codeLines: string[] = [];

  for (const line of lines) {
    if (line.trim().startsWith('```') && !inFence) {
      inFence = true;
      continue;
    }
    if (line.trim().startsWith('```') && inFence) {
      break;
    }
    if (inFence) {
      codeLines.push(line);
    }
  }

  if (codeLines.length === 0) return undefined;

  try {
    return JSON.parse(codeLines.join('\n'));
  } catch {
    return codeLines.join('\n');
  }
}

export function parseDocument(filePath: string, content: string): TalkdownDocument {
  const { yaml, body } = splitMarkdown(content);
  const frontmatter = parseFrontmatter(yaml);
  const sections = parseSections(body);

  const doc: TalkdownDocument = {
    filePath,
    frontmatter,
    title: frontmatter.title,
    introduction: extractIntroduction(sections),
  };

  doc.context = sectionContent(sections, 'Context');

  const inputSection = findSection(sections, 'Inputs');
  if (inputSection) {
    doc.inputDescriptions = parseInputSection(inputSection.rawContent);
  }

  switch (frontmatter.type) {
    case 'directive': {
      const execSection = findSection(sections, 'Execution');
      if (execSection) doc.execution = parseExecution(execSection.rawContent);
      const outSection = findSection(sections, 'Output');
      if (outSection) doc.output = parseOutputSection(outSection.rawContent);
      break;
    }

    case 'step': {
      const execSection = findSection(sections, 'Execution');
      if (execSection) doc.execution = parseExecution(execSection.rawContent);
      const outSection = findSection(sections, 'Output');
      if (outSection) doc.output = parseOutputSection(outSection.rawContent);
      const routeSection = findSection(sections, 'Routing');
      if (routeSection) doc.routing = parseRouting(routeSection.rawContent);
      break;
    }

    case 'process': {
      const stepsSection = findSection(sections, 'Steps');
      if (stepsSection) doc.steps = parseProcessSteps(stepsSection.rawContent);
      const outSection = findSection(sections, 'Output');
      if (outSection) doc.output = parseOutputSection(outSection.rawContent);
      const routeSection = findSection(sections, 'Routing');
      if (routeSection) doc.routing = parseRouting(routeSection.rawContent);
      break;
    }

    case 'guard': {
      const checksSection = findSection(sections, 'Checks');
      if (checksSection) {
        const result = parseGuardChecks(checksSection.rawContent);
        doc.checks = result.checks;
        doc.checksAIBlock = result.aiBlock;
      }
      const verdictSection = findSection(sections, 'Verdict');
      if (verdictSection) doc.verdict = parseVerdict(verdictSection.rawContent);
      const routeSection = findSection(sections, 'Routing');
      if (routeSection) doc.routing = parseRouting(routeSection.rawContent);
      break;
    }

    case 'persona': {
      const identity = sectionContent(sections, 'Identity');
      const expertise = sectionContent(sections, 'Expertise');
      const behavior = sectionContent(sections, 'Behavior');
      if (identity && expertise && behavior) {
        doc.personaSections = { identity, expertise, behavior };
      }
      break;
    }

    case 'schema': {
      const fieldsSection = findSection(sections, 'Fields');
      if (fieldsSection) doc.fields = parseSchemaFields(fieldsSection.rawContent);
      const constraintsSection = findSection(sections, 'Constraints');
      if (constraintsSection) doc.constraints = parseSchemaConstraints(constraintsSection.rawContent);
      const exampleSection = findSection(sections, 'Example');
      if (exampleSection) doc.schemaExample = parseSchemaExample(exampleSection.rawContent);
      break;
    }

    case 'trigger': {
      const eventSection = findSection(sections, 'Event');
      if (eventSection) doc.event = parseTriggerEvent(eventSection.rawContent);
      const targetSection = findSection(sections, 'Target');
      if (targetSection) doc.triggerTarget = parseTriggerTarget(targetSection.rawContent);
      break;
    }

    case 'test': {
      const casesSection = findSection(sections, 'Cases');
      if (casesSection) doc.cases = parseTestCases(casesSection.rawContent);
      const assertionsSection = findSection(sections, 'Assertions');
      if (assertionsSection) doc.assertions = parseTestAssertions(assertionsSection.rawContent);
      break;
    }
  }

  return doc;
}

export { TalkdownParseError } from './errors.js';
export { findSection } from './section-parser.js';
