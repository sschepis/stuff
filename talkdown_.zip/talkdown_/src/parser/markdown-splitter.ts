import { TalkdownParseError } from './errors.js';

/**
 * Split a Talkdown document into its YAML frontmatter and markdown body.
 *
 * The first line **must** be `---`.  The closing `---` delimiter is matched
 * only when we are not inside a fenced code block (tracked by counting
 * ``` toggles).
 */
export function splitMarkdown(content: string): { yaml: string; body: string } {
  const lines = content.split('\n');

  if (lines.length === 0 || lines[0].trim() !== '---') {
    throw new TalkdownParseError(
      'Document must begin with a YAML frontmatter block (first line must be "---")',
      { line: 1 },
    );
  }

  let inCodeFence = false;
  let closingIndex = -1;

  for (let i = 1; i < lines.length; i++) {
    const trimmed = lines[i].trim();

    // Toggle code-fence state on lines that start with ``` (ignoring lang tag).
    if (trimmed.startsWith('```')) {
      inCodeFence = !inCodeFence;
      continue;
    }

    // Only recognise the closing `---` when we are outside code fences.
    if (!inCodeFence && trimmed === '---') {
      closingIndex = i;
      break;
    }
  }

  if (closingIndex === -1) {
    throw new TalkdownParseError(
      'No closing "---" found for YAML frontmatter block',
    );
  }

  const yaml = lines.slice(1, closingIndex).join('\n');
  const body = lines.slice(closingIndex + 1).join('\n');

  return { yaml, body };
}
