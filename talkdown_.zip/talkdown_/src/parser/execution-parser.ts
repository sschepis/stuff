import type { ExecutionBlock } from '../types/ast.js';
import { parseTemplate } from './template-parser.js';

const NUMBERED_LINE = /^(\d+)\.\s+(.*)/;
const FENCE_OPEN = /^```(\w*)\s*$/;
const FENCE_CLOSE = /^```\s*$/;

/**
 * Parse the raw content of an ## Execution section into ordered
 * execution blocks: numbered NL steps, ```ai blocks, and
 * ```<lang> code blocks.
 */
export function parseExecution(rawContent: string): ExecutionBlock[] {
  const lines = rawContent.split('\n');
  const blocks: ExecutionBlock[] = [];

  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // -- Fenced block --
    const fenceMatch = line.match(FENCE_OPEN);
    if (fenceMatch) {
      const language = fenceMatch[1] || '';
      const contentLines: string[] = [];
      i++; // skip opening fence

      while (i < lines.length && !FENCE_CLOSE.test(lines[i])) {
        contentLines.push(lines[i]);
        i++;
      }
      i++; // skip closing fence

      const raw = contentLines.join('\n');

      if (language === 'ai') {
        blocks.push({
          kind: 'ai_block',
          template: parseTemplate(raw),
        });
      } else {
        blocks.push({
          kind: 'code_block',
          language,
          source: raw,
        });
      }

      continue;
    }

    // -- Numbered step --
    const numMatch = line.match(NUMBERED_LINE);
    if (numMatch) {
      const number = parseInt(numMatch[1], 10);
      const textLines: string[] = [numMatch[2]];
      i++;

      // Consecutive non-numbered, non-fenced continuation lines
      // belong to the same step.
      while (i < lines.length) {
        const next = lines[i];
        if (NUMBERED_LINE.test(next) || FENCE_OPEN.test(next)) break;
        textLines.push(next);
        i++;
      }

      // Trim trailing blank lines
      while (textLines.length > 0 && textLines[textLines.length - 1].trim() === '') {
        textLines.pop();
      }

      blocks.push({
        kind: 'nl_step',
        number,
        text: textLines.join('\n'),
      });

      continue;
    }

    // -- Skip blank / non-matching lines --
    i++;
  }

  return blocks;
}
