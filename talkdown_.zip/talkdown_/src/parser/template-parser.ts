import type {
  TemplateContent,
  TemplateExpr,
  VariableRef,
  PropertyAccess,
  FilterExpr,
  Filter,
  FilterArg,
} from '../types/ast.js';

const BLOCK_OPEN_RE = /^\{\{#if\s+(\S+?)\}\}/;
const BLOCK_CLOSE = '{{/if}}';
const EXPR_RE = /\{\{(.+?)\}\}/;

export function parseTemplate(text: string): TemplateContent[] {
  if (!text.includes('{{')) {
    return [{ kind: 'literal', text }];
  }
  return parseSegments(text);
}

function parseSegments(text: string): TemplateContent[] {
  const nodes: TemplateContent[] = [];
  let remaining = text;

  while (remaining.length > 0) {
    const blockMatch = BLOCK_OPEN_RE.exec(remaining);
    if (blockMatch && remaining.indexOf(blockMatch[0]) === 0) {
      const variable = blockMatch[1];
      const afterOpen = remaining.slice(blockMatch[0].length);
      const closeIdx = findMatchingClose(afterOpen);
      if (closeIdx === -1) {
        nodes.push({ kind: 'literal', text: remaining });
        break;
      }

      const bodyText = afterOpen.slice(0, closeIdx);
      const body = parseSegments(bodyText);
      nodes.push({ kind: 'conditional', variable, body });
      remaining = afterOpen.slice(closeIdx + BLOCK_CLOSE.length);
      continue;
    }

    const exprIdx = remaining.indexOf('{{');
    if (exprIdx === -1) {
      nodes.push({ kind: 'literal', text: remaining });
      break;
    }

    if (exprIdx > 0) {
      nodes.push({ kind: 'literal', text: remaining.slice(0, exprIdx) });
      remaining = remaining.slice(exprIdx);
      continue;
    }

    const blockCheck = BLOCK_OPEN_RE.exec(remaining);
    if (blockCheck && remaining.indexOf(blockCheck[0]) === 0) {
      const variable = blockCheck[1];
      const afterOpen = remaining.slice(blockCheck[0].length);
      const closeIdx = findMatchingClose(afterOpen);
      if (closeIdx === -1) {
        nodes.push({ kind: 'literal', text: remaining });
        break;
      }
      const bodyText = afterOpen.slice(0, closeIdx);
      const body = parseSegments(bodyText);
      nodes.push({ kind: 'conditional', variable, body });
      remaining = afterOpen.slice(closeIdx + BLOCK_CLOSE.length);
      continue;
    }

    const match = EXPR_RE.exec(remaining);
    if (!match) {
      nodes.push({ kind: 'literal', text: remaining });
      break;
    }

    const fullMatch = match[0];
    const inner = match[1].trim();

    nodes.push(parseExpression(inner));
    remaining = remaining.slice(fullMatch.length);
  }

  return nodes;
}

function findMatchingClose(text: string): number {
  let depth = 1;
  let pos = 0;

  while (pos < text.length && depth > 0) {
    const nextOpen = text.indexOf('{{#if ', pos);
    const nextClose = text.indexOf(BLOCK_CLOSE, pos);

    if (nextClose === -1) {
      return -1;
    }

    if (nextOpen !== -1 && nextOpen < nextClose) {
      depth++;
      pos = nextOpen + 6;
    } else {
      depth--;
      if (depth === 0) {
        return nextClose;
      }
      pos = nextClose + BLOCK_CLOSE.length;
    }
  }

  return -1;
}

function parseExpression(inner: string): TemplateExpr {
  const segments = splitPipe(inner);

  if (segments.length > 1) {
    const base = parseBaseExpr(segments[0].trim());
    const filters = segments.slice(1).map(parseFilter);
    return { kind: 'filter', operand: base, filters };
  }

  return parseBaseExpr(inner);
}

function parseBaseExpr(name: string): VariableRef | PropertyAccess {
  const trimmed = name.trim();
  if (trimmed.includes('.')) {
    const parts = trimmed.split('.');
    return {
      kind: 'property_access',
      root: parts[0],
      path: parts.slice(1),
    };
  }
  return { kind: 'variable_ref', name: trimmed };
}

function splitPipe(expr: string): string[] {
  const results: string[] = [];
  let current = '';
  let depth = 0;

  for (let i = 0; i < expr.length; i++) {
    const ch = expr[i];

    if (ch === '(') {
      depth++;
      current += ch;
    } else if (ch === ')') {
      depth--;
      current += ch;
    } else if (
      depth === 0 &&
      ch === ' ' &&
      expr[i + 1] === '|' &&
      expr[i + 2] === ' '
    ) {
      results.push(current);
      current = '';
      i += 2;
    } else {
      current += ch;
    }
  }

  if (current.length > 0) {
    results.push(current);
  }

  return results;
}

function parseFilter(segment: string): Filter {
  const trimmed = segment.trim();
  const parenIdx = trimmed.indexOf('(');

  if (parenIdx === -1) {
    return { name: trimmed };
  }

  const name = trimmed.slice(0, parenIdx).trim();
  const argsStr = trimmed.slice(parenIdx + 1, trimmed.lastIndexOf(')'));
  const args = parseFilterArgs(argsStr);

  return args.length > 0 ? { name, args } : { name };
}

function parseFilterArgs(argsStr: string): FilterArg[] {
  const args: FilterArg[] = [];
  const pairRe = /(\w+)\s*=\s*"([^"]*)"|\s*(\w+)\s*=\s*'([^']*)'/g;
  let match: RegExpExecArray | null;

  while ((match = pairRe.exec(argsStr)) !== null) {
    const key = match[1] ?? match[3];
    const value = match[2] ?? match[4];
    args.push({ key, value });
  }

  return args;
}
