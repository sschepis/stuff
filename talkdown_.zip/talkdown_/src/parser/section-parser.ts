import type { Section } from '../types/ast.js';

// ── Heading regex ──────────────────────────────────────────────────
// Matches lines like "# Title", "## Subtitle", "### Sub-sub" etc.
const HEADING_RE = /^(#{1,6})\s+(.+)$/;

/**
 * Parse the markdown body of a Talkdown document into a tree of
 * {@link Section} nodes, respecting code-fence boundaries so that
 * `#` characters inside fenced blocks are not mistaken for headings.
 */
export function parseSections(body: string): Section[] {
  const lines = body.split('\n');

  // First pass: collect flat list of heading positions while
  // tracking code-fence state.
  interface RawHeading {
    lineIndex: number;
    level: number;
    text: string;
  }

  const headings: RawHeading[] = [];
  let inCodeFence = false;

  for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trim();

    if (trimmed.startsWith('```')) {
      inCodeFence = !inCodeFence;
      continue;
    }

    if (inCodeFence) continue;

    const match = HEADING_RE.exec(lines[i]);
    if (match) {
      headings.push({
        lineIndex: i,
        level: match[1].length,
        text: match[2].trim(),
      });
    }
  }

  // Second pass: turn flat heading list into sections with rawContent.
  // rawContent is everything between this heading line and the next
  // heading at the same or higher (lower number) level.
  const flatSections: (Section & { _lineIndex: number })[] = headings.map(
    (h, idx) => {
      const startLine = h.lineIndex + 1; // line after the heading
      const endLine =
        idx + 1 < headings.length ? headings[idx + 1].lineIndex : lines.length;
      const rawContent = lines.slice(startLine, endLine).join('\n');

      return {
        heading: h.text,
        level: h.level,
        rawContent,
        children: [],
        _lineIndex: h.lineIndex,
      };
    },
  );

  // Third pass: nest children under their parent sections.
  return buildTree(flatSections);
}

/**
 * Build a nested section tree from a flat list ordered by document
 * position.  A section at level N becomes a child of the nearest
 * prior section at level N-1.  Top-level sections are those whose
 * level equals the minimum level found, or that have no eligible
 * parent.
 *
 * Each parent's rawContent is trimmed to contain only the prose
 * between its own heading and the first child heading.
 */
function buildTree(
  flat: (Section & { _lineIndex: number })[],
): Section[] {
  const roots: Section[] = [];
  const stack: Section[] = [];

  for (const item of flat) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { _lineIndex, ...section } = item;

    // Pop stack until we find a parent with a strictly lower level.
    while (stack.length > 0 && stack[stack.length - 1].level >= section.level) {
      stack.pop();
    }

    if (stack.length === 0) {
      roots.push(section);
    } else {
      const parent = stack[stack.length - 1];
      parent.children.push(section);

      // Trim parent rawContent so it contains only the prose
      // introduction before its first child heading.
      trimParentContent(parent);
    }

    stack.push(section);
  }

  return roots;
}

/**
 * Trim a parent section's rawContent so it contains only the prose
 * introduction before its first child heading.
 */
function trimParentContent(parent: Section): void {
  if (parent.children.length === 0) return;

  const firstChildHeading = parent.children[0].heading;
  const marker = '#'.repeat(parent.children[0].level) + ' ' + firstChildHeading;
  const idx = parent.rawContent.indexOf(marker);
  if (idx !== -1) {
    parent.rawContent = parent.rawContent.slice(0, idx);
  }
}

/**
 * Find a section by its heading text (case-insensitive).
 * Searches the top-level list and all nested children.
 */
export function findSection(
  sections: Section[],
  heading: string,
): Section | undefined {
  const target = heading.toLowerCase();

  for (const section of sections) {
    if (section.heading.toLowerCase() === target) {
      return section;
    }
    const found = findSection(section.children, heading);
    if (found) return found;
  }

  return undefined;
}
