import type { InputDescription } from '../types/ast.js';

// ── Regular expressions ──────────────────────────────────────────

/**
 * Match input bullet format:
 *   - **input_name** (type, required): description
 *   - **input_name** (type, optional): description
 *   - **input_name** (type, required, schema: ...): description
 */
const INPUT_PATTERN = /^-\s+\*\*(\w+)\*\*\s+\(([^)]+)\):\s*(.*)/;

/**
 * Parse the raw content of a ## Inputs section into InputDescription
 * items.
 *
 * Each bullet item is expected to follow the format:
 *   `- **name** (type, required|optional): description text`
 */
export function parseInputSection(rawContent: string): InputDescription[] {
  const inputs: InputDescription[] = [];
  const lines = rawContent.split('\n');

  for (const line of lines) {
    const trimmed = line.trim();
    const match = trimmed.match(INPUT_PATTERN);
    if (!match) continue;

    const name = match[1];
    const parenContent = match[2];
    const description = match[3].trim();

    // Parse parenthesized content: "type, required" or "type, optional, schema: ..."
    const parts = parenContent.split(',').map((p) => p.trim());
    const type = parts[0] || '';

    // Look for required/optional in the remaining parts
    let requiredText = '';
    for (let i = 1; i < parts.length; i++) {
      const part = parts[i].toLowerCase();
      if (part === 'required' || part === 'optional') {
        requiredText = part;
        break;
      }
    }

    inputs.push({ name, type, requiredText, description });
  }

  return inputs;
}
