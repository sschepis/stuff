import type {
  TemplateContent,
  TemplateLiteral,
  TemplateExpr,
  VariableRef,
  PropertyAccess,
  FilterExpr,
  ConditionalBlock,
  Filter,
} from '../types/ast.js';

/**
 * Provides variable resolution for template expansion.
 */
export class TemplateContext {
  private data: Record<string, unknown>;

  constructor(data: Record<string, unknown>) {
    this.data = data;
  }

  /**
   * Look up a variable by name.
   */
  resolve(name: string): unknown {
    return this.data[name];
  }

  /**
   * Dot-notation resolution: resolve object name, then traverse path segments.
   */
  resolveProperty(object: string, path: string[]): unknown {
    let current: unknown = this.data[object];
    for (const segment of path) {
      if (current == null || typeof current !== 'object') {
        return undefined;
      }
      current = (current as Record<string, unknown>)[segment];
    }
    return current;
  }

  /**
   * Check if a variable is truthy for conditional blocks.
   */
  isTruthy(name: string): boolean {
    const value = this.resolve(name);
    if (value == null) return false;
    if (typeof value === 'boolean') return value;
    if (typeof value === 'number') return value !== 0;
    if (typeof value === 'string') return value.length > 0;
    if (Array.isArray(value)) return value.length > 0;
    return true;
  }
}

/**
 * Expands TemplateContent arrays into strings using a TemplateContext.
 */
export class TemplateEngine {
  /**
   * Expand an array of TemplateContent nodes into a single string.
   */
  expand(template: TemplateContent[], context: TemplateContext): string {
    return template.map((node) => this.expandNode(node, context)).join('');
  }

  private expandNode(node: TemplateContent, context: TemplateContext): string {
    switch (node.kind) {
      case 'literal':
        return (node as TemplateLiteral).text;

      case 'variable_ref':
        return this.valueToString(context.resolve((node as VariableRef).name));

      case 'property_access':
        return this.valueToString(
          context.resolveProperty((node as PropertyAccess).root, (node as PropertyAccess).path)
        );

      case 'filter':
        return this.expandFilter(node as FilterExpr, context);

      case 'conditional':
        return this.expandConditional(node as ConditionalBlock, context);

      default:
        return '';
    }
  }

  private expandFilter(node: FilterExpr, context: TemplateContext): string {
    // Resolve the base operand value
    let value: unknown;
    if (node.operand.kind === 'variable_ref') {
      value = context.resolve(node.operand.name);
    } else {
      value = context.resolveProperty(node.operand.root, node.operand.path);
    }

    // Apply each filter in order
    for (const filter of node.filters) {
      value = this.applyFilter(value, filter);
    }

    return this.valueToString(value);
  }

  private applyFilter(value: unknown, filter: Filter): unknown {
    switch (filter.name) {
      case 'length': {
        if (Array.isArray(value)) return value.length;
        if (typeof value === 'string') return value.length;
        return 0;
      }

      case 'filter': {
        if (!Array.isArray(value)) return value;
        if (!filter.args || filter.args.length === 0) return value;
        // Filter array items where item[key] === value for each arg
        return value.filter((item: unknown) => {
          if (item == null || typeof item !== 'object') return false;
          return filter.args!.every(
            (arg) => (item as Record<string, unknown>)[arg.key] === arg.value
          );
        });
      }

      default:
        // Unknown filter: pass through
        return value;
    }
  }

  private expandConditional(node: ConditionalBlock, context: TemplateContext): string {
    if (context.isTruthy(node.variable)) {
      return this.expand(node.body, context);
    }
    return '';
  }

  private valueToString(value: unknown): string {
    if (value === undefined || value === null) return '';
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (Array.isArray(value)) return JSON.stringify(value);
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  }
}
