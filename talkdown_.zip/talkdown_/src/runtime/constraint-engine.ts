import type {
  CompiledExpr,
  StringLength,
  WordCount,
  EnumCheck,
  Required,
  Populated,
  NotEmpty,
  NumericCompare,
  ArrayLength,
  ConditionalRule,
  SumEquality,
  FieldEquals,
  And,
  Or,
  SizeOp,
  ComparisonOp,
  ConstraintResult,
} from '../types/compiled.js';

export type { ConstraintResult } from '../types/compiled.js';

/**
 * Resolve a field value from a data object, supporting dot-notation paths.
 */
function resolveField(data: Record<string, unknown>, field: string): unknown {
  const parts = field.split('.');
  let current: unknown = data;
  for (const part of parts) {
    if (current == null || typeof current !== 'object') {
      return undefined;
    }
    current = (current as Record<string, unknown>)[part];
  }
  return current;
}

/**
 * Compare a numeric value using a size operator (lte/gte/eq/between).
 */
function compareWithSizeOp(
  actual: number,
  op: SizeOp,
  value: number,
  value2?: number
): boolean {
  switch (op) {
    case 'eq':
      return actual === value;
    case 'lte':
      return actual <= value;
    case 'gte':
      return actual >= value;
    case 'between':
      return actual >= value && actual <= (value2 ?? value);
  }
}

/**
 * Compare a numeric value using a comparison operator (gt/gte/lt/lte/eq).
 */
function compareWithComparisonOp(
  actual: number,
  op: ComparisonOp,
  value: number
): boolean {
  switch (op) {
    case 'eq':
      return actual === value;
    case 'lte':
      return actual <= value;
    case 'gte':
      return actual >= value;
    case 'lt':
      return actual < value;
    case 'gt':
      return actual > value;
  }
}

/**
 * Format size op description for human-readable output.
 */
function formatSizeOp(op: SizeOp, value: number, value2?: number): string {
  if (op === 'between') {
    return `between ${value} and ${value2 ?? value}`;
  }
  return `${op} ${value}`;
}

/**
 * Evaluates compiled constraint expressions against data.
 */
export class ConstraintEngine {
  /**
   * Evaluate a single compiled expression against data.
   */
  evaluate(expr: CompiledExpr, data: Record<string, unknown>): ConstraintResult {
    switch (expr.kind) {
      case 'string_length':
        return this.evalStringLength(expr, data);
      case 'word_count':
        return this.evalWordCount(expr, data);
      case 'enum_check':
        return this.evalEnumCheck(expr, data);
      case 'required':
        return this.evalRequired(expr, data);
      case 'populated':
        return this.evalPopulated(expr, data);
      case 'not_empty':
        return this.evalNotEmpty(expr, data);
      case 'numeric_compare':
        return this.evalNumericCompare(expr, data);
      case 'array_length':
        return this.evalArrayLength(expr, data);
      case 'conditional_rule':
        return this.evalConditionalRule(expr, data);
      case 'sum_equality':
        return this.evalSumEquality(expr, data);
      case 'field_equals':
        return this.evalFieldEquals(expr, data);
      case 'and':
        return this.evalAnd(expr, data);
      case 'or':
        return this.evalOr(expr, data);
    }
  }

  /**
   * Evaluate all expressions, returning aggregate results.
   */
  evaluateAll(
    exprs: CompiledExpr[],
    data: Record<string, unknown>
  ): { pass: boolean; results: ConstraintResult[] } {
    const results = exprs.map((expr) => this.evaluate(expr, data));
    const pass = results.every((r) => r.pass);
    return { pass, results };
  }

  private evalStringLength(expr: StringLength, data: Record<string, unknown>): ConstraintResult {
    const value = resolveField(data, expr.field);
    if (typeof value !== 'string') {
      return {
        pass: false,
        detail: `Field '${expr.field}' is not a string (got ${typeof value})`,
        field: expr.field,
      };
    }
    const len = value.length;
    const pass = compareWithSizeOp(len, expr.op, expr.value, expr.value2);
    return {
      pass,
      detail: pass
        ? `String length ${len} satisfies ${formatSizeOp(expr.op, expr.value, expr.value2)}`
        : `String length ${len} does not satisfy ${formatSizeOp(expr.op, expr.value, expr.value2)}`,
      field: expr.field,
    };
  }

  private evalWordCount(expr: WordCount, data: Record<string, unknown>): ConstraintResult {
    const value = resolveField(data, expr.field);
    if (typeof value !== 'string') {
      return {
        pass: false,
        detail: `Field '${expr.field}' is not a string (got ${typeof value})`,
        field: expr.field,
      };
    }
    const trimmed = value.trim();
    const count = trimmed.length === 0 ? 0 : trimmed.split(/\s+/).length;
    const pass = compareWithSizeOp(count, expr.op, expr.value, expr.value2);
    return {
      pass,
      detail: pass
        ? `Word count ${count} satisfies ${formatSizeOp(expr.op, expr.value, expr.value2)}`
        : `Word count ${count} does not satisfy ${formatSizeOp(expr.op, expr.value, expr.value2)}`,
      field: expr.field,
    };
  }

  private evalEnumCheck(expr: EnumCheck, data: Record<string, unknown>): ConstraintResult {
    const value = resolveField(data, expr.field);
    const strValue = String(value);
    const pass = expr.allowed.includes(strValue);
    return {
      pass,
      detail: pass
        ? `Value '${strValue}' is in allowed set [${expr.allowed.join(', ')}]`
        : `Value '${strValue}' is not in allowed set [${expr.allowed.join(', ')}]`,
      field: expr.field,
    };
  }

  private evalRequired(expr: Required, data: Record<string, unknown>): ConstraintResult {
    const value = resolveField(data, expr.field);
    const pass = value !== undefined;
    return {
      pass,
      detail: pass
        ? `Field '${expr.field}' is present`
        : `Field '${expr.field}' is required but missing`,
      field: expr.field,
    };
  }

  private evalPopulated(expr: Populated, data: Record<string, unknown>): ConstraintResult {
    const value = resolveField(data, expr.field);
    const pass = this.isPopulated(value);
    return {
      pass,
      detail: pass
        ? `Field '${expr.field}' is populated`
        : `Field '${expr.field}' is not populated`,
      field: expr.field,
    };
  }

  private evalNotEmpty(expr: NotEmpty, data: Record<string, unknown>): ConstraintResult {
    const value = resolveField(data, expr.field);
    const pass = this.isPopulated(value);
    return {
      pass,
      detail: pass
        ? `Field '${expr.field}' is not empty`
        : `Field '${expr.field}' is empty or missing`,
      field: expr.field,
    };
  }

  private isPopulated(value: unknown): boolean {
    if (value === undefined || value === null) return false;
    if (typeof value === 'string') return value.length > 0;
    if (Array.isArray(value)) return value.length > 0;
    return true;
  }

  private evalNumericCompare(expr: NumericCompare, data: Record<string, unknown>): ConstraintResult {
    const value = resolveField(data, expr.field);
    const num = Number(value);
    if (isNaN(num)) {
      return {
        pass: false,
        detail: `Field '${expr.field}' is not a valid number (got '${String(value)}')`,
        field: expr.field,
      };
    }
    const pass = compareWithComparisonOp(num, expr.op, expr.value);
    return {
      pass,
      detail: pass
        ? `Value ${num} satisfies ${expr.op} ${expr.value}`
        : `Value ${num} does not satisfy ${expr.op} ${expr.value}`,
      field: expr.field,
    };
  }

  private evalArrayLength(expr: ArrayLength, data: Record<string, unknown>): ConstraintResult {
    const value = resolveField(data, expr.field);
    if (!Array.isArray(value)) {
      return {
        pass: false,
        detail: `Field '${expr.field}' is not an array (got ${typeof value})`,
        field: expr.field,
      };
    }
    const len = value.length;
    const pass = compareWithSizeOp(len, expr.op, expr.value, expr.value2);
    return {
      pass,
      detail: pass
        ? `Array length ${len} satisfies ${formatSizeOp(expr.op, expr.value, expr.value2)}`
        : `Array length ${len} does not satisfy ${formatSizeOp(expr.op, expr.value, expr.value2)}`,
      field: expr.field,
    };
  }

  private evalConditionalRule(expr: ConditionalRule, data: Record<string, unknown>): ConstraintResult {
    const conditionResult = this.evaluate(expr.condition, data);
    if (!conditionResult.pass) {
      // Vacuously true: condition not met, so the rule passes
      return {
        pass: true,
        detail: `Conditional rule vacuously true (condition not met: ${conditionResult.detail})`,
      };
    }
    // Condition met: evaluate the consequent
    const thenResult = this.evaluate(expr.then, data);
    return {
      pass: thenResult.pass,
      detail: thenResult.pass
        ? `Conditional rule passed: ${thenResult.detail}`
        : `Conditional rule failed: condition met but then-clause failed: ${thenResult.detail}`,
      field: thenResult.field,
    };
  }

  private evalSumEquality(expr: SumEquality, data: Record<string, unknown>): ConstraintResult {
    let sum = 0;
    for (const fieldName of expr.fields) {
      const value = resolveField(data, fieldName);
      if (Array.isArray(value)) {
        sum += value.length;
      } else {
        const n = Number(value);
        sum += isNaN(n) ? 0 : n;
      }
    }

    let total: number;
    if (expr.total.kind === 'literal') {
      total = expr.total.value;
    } else {
      const refValue = resolveField(data, expr.total.field);
      if (Array.isArray(refValue)) {
        total = refValue.length;
      } else {
        const n = Number(refValue);
        total = isNaN(n) ? 0 : n;
      }
    }

    const pass = sum === total;
    return {
      pass,
      detail: pass
        ? `Sum of [${expr.fields.join(', ')}] equals ${total}`
        : `Sum of [${expr.fields.join(', ')}] is ${sum}, expected ${total}`,
    };
  }

  private evalFieldEquals(expr: FieldEquals, data: Record<string, unknown>): ConstraintResult {
    const value = resolveField(data, expr.field);
    const pass = String(value) === expr.value;
    return {
      pass,
      detail: pass
        ? `Field '${expr.field}' equals '${expr.value}'`
        : `Field '${expr.field}' is '${String(value)}', expected '${expr.value}'`,
      field: expr.field,
    };
  }

  private evalAnd(expr: And, data: Record<string, unknown>): ConstraintResult {
    const results = expr.exprs.map((e: CompiledExpr) => this.evaluate(e, data));
    const pass = results.every((r: ConstraintResult) => r.pass);
    const failedDetails = results
      .filter((r: ConstraintResult) => !r.pass)
      .map((r: ConstraintResult) => r.detail);
    return {
      pass,
      detail: pass
        ? `All ${results.length} conditions passed`
        : `Failed: ${failedDetails.join('; ')}`,
    };
  }

  private evalOr(expr: Or, data: Record<string, unknown>): ConstraintResult {
    const results = expr.exprs.map((e: CompiledExpr) => this.evaluate(e, data));
    const pass = results.some((r: ConstraintResult) => r.pass);
    return {
      pass,
      detail: pass
        ? `At least one condition passed`
        : `None of ${results.length} conditions passed: ${results.map((r: ConstraintResult) => r.detail).join('; ')}`,
    };
  }
}
