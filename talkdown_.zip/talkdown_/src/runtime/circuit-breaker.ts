/**
 * Circuit breaker that prevents runaway execution loops in workflow steps.
 *
 * Tracks per-step execution counts and consecutive self-loop iterations
 * to detect and halt infinite loops.
 */
export class CircuitBreaker {
  private maxSelfLoops: number;
  private maxStepExecutions: number;

  /** Total execution count per step path. */
  private executionCounts: Map<string, number> = new Map();

  /** Consecutive execution count for self-loop detection. */
  private consecutiveCounts: Map<string, number> = new Map();

  /** The most recently executed step path. */
  private lastStep: string | null = null;

  constructor(maxSelfLoops: number = 3, maxStepExecutions: number = 100) {
    this.maxSelfLoops = maxSelfLoops;
    this.maxStepExecutions = maxStepExecutions;
  }

  /**
   * Record that a step has been executed. Updates both total and
   * consecutive execution tracking.
   */
  recordExecution(stepPath: string): void {
    // Update total execution count
    const current = this.executionCounts.get(stepPath) ?? 0;
    this.executionCounts.set(stepPath, current + 1);

    // Track consecutive executions (self-loops)
    if (this.lastStep === stepPath) {
      const consecutive = this.consecutiveCounts.get(stepPath) ?? 1;
      this.consecutiveCounts.set(stepPath, consecutive + 1);
    } else {
      // Reset consecutive count for this step when a different step ran in between
      this.consecutiveCounts.set(stepPath, 1);
    }

    this.lastStep = stepPath;
  }

  /**
   * Check if the total execution count for a step exceeds the maximum.
   */
  isTripped(stepPath: string): boolean {
    const count = this.executionCounts.get(stepPath) ?? 0;
    return count > this.maxStepExecutions;
  }

  /**
   * Check if consecutive executions of the same step exceed the self-loop limit.
   */
  isSelfLoopTripped(stepPath: string): boolean {
    const consecutive = this.consecutiveCounts.get(stepPath) ?? 0;
    return consecutive > this.maxSelfLoops;
  }

  /**
   * Return a human-readable report of the circuit breaker state for a step.
   */
  getReport(stepPath: string): string {
    const total = this.executionCounts.get(stepPath) ?? 0;
    const consecutive = this.consecutiveCounts.get(stepPath) ?? 0;
    const tripped = this.isTripped(stepPath);
    const selfLoopTripped = this.isSelfLoopTripped(stepPath);

    const lines: string[] = [
      `Circuit breaker report for '${stepPath}':`,
      `  Total executions: ${total} / ${this.maxStepExecutions} max`,
      `  Consecutive runs: ${consecutive} / ${this.maxSelfLoops} max`,
    ];

    if (tripped) {
      lines.push(`  STATUS: TRIPPED - total execution limit exceeded`);
    } else if (selfLoopTripped) {
      lines.push(`  STATUS: TRIPPED - self-loop limit exceeded`);
    } else {
      lines.push(`  STATUS: OK`);
    }

    return lines.join('\n');
  }

  /**
   * Reset all tracking state.
   */
  reset(): void {
    this.executionCounts.clear();
    this.consecutiveCounts.clear();
    this.lastStep = null;
  }
}
