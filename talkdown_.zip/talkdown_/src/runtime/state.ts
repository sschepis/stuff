import { TemplateContext } from './template-engine.js';

/**
 * Manages workflow execution state: initial inputs, accumulated step outputs,
 * and variable resolution with proper precedence.
 *
 * Variable resolution precedence:
 * 1. Current document's own frontmatter inputs
 * 2. Outputs from the most recently completed step that declared that output name
 * 3. If multiple prior steps produced same-named output, most recent step wins
 */
export class WorkflowState {
  private inputs: Record<string, unknown>;

  /**
   * Outputs keyed by step path, each containing that step's output map.
   * Insertion order is preserved (Map guarantees this), so we can find
   * the most recent step that produced a given output name.
   */
  private stepOutputs: Map<string, Record<string, unknown>> = new Map();

  /** Ordered list of step paths as they were executed. */
  private stepOrder: string[] = [];

  /** Current step being executed. */
  private currentStepPath: string | null = null;

  constructor(inputs: Record<string, unknown>) {
    this.inputs = { ...inputs };
  }

  /**
   * Look up an input value by name.
   */
  getInput(name: string): unknown {
    return this.inputs[name];
  }

  /**
   * Look up an output by name. If multiple steps produced the same output
   * name, the most recent step wins.
   */
  getOutput(name: string): unknown {
    // Walk step order in reverse to find the most recent step with this output
    for (let i = this.stepOrder.length - 1; i >= 0; i--) {
      const stepPath = this.stepOrder[i];
      const outputs = this.stepOutputs.get(stepPath);
      if (outputs && name in outputs) {
        return outputs[name];
      }
    }
    return undefined;
  }

  /**
   * Resolve a variable name. Checks inputs first, then outputs.
   */
  resolve(name: string): unknown {
    // 1. Check inputs first (frontmatter inputs take precedence)
    if (name in this.inputs) {
      return this.inputs[name];
    }

    // 2. Check outputs (most recent step wins)
    return this.getOutput(name);
  }

  /**
   * Dot-notation resolution through the state. Resolves the root object
   * name, then traverses the path segments.
   */
  resolveProperty(object: string, path: string[]): unknown {
    let current: unknown = this.resolve(object);
    for (const segment of path) {
      if (current == null || typeof current !== 'object') {
        return undefined;
      }
      current = (current as Record<string, unknown>)[segment];
    }
    return current;
  }

  /**
   * Store outputs from a completed step. These become available for
   * subsequent variable resolution.
   */
  accumulateOutputs(stepPath: string, outputs: Record<string, unknown>): void {
    this.stepOutputs.set(stepPath, { ...outputs });
    this.stepOrder.push(stepPath);
  }

  /**
   * Set the current step path.
   */
  setCurrentStep(stepPath: string): void {
    this.currentStepPath = stepPath;
  }

  /**
   * Get the current step path.
   */
  getCurrentStep(): string | null {
    return this.currentStepPath;
  }

  /**
   * Convert the current state to a TemplateContext for template expansion.
   * Merges inputs and all outputs into a single flat record, with proper
   * precedence (inputs override outputs, later outputs override earlier ones).
   */
  toContext(): TemplateContext {
    const merged: Record<string, unknown> = {};

    // Layer outputs in order (earliest first, so later ones overwrite)
    for (const stepPath of this.stepOrder) {
      const outputs = this.stepOutputs.get(stepPath);
      if (outputs) {
        Object.assign(merged, outputs);
      }
    }

    // Inputs take highest precedence
    Object.assign(merged, this.inputs);

    return new TemplateContext(merged);
  }

  /**
   * Serialize the full state for inspection or persistence.
   */
  snapshot(): Record<string, unknown> {
    const outputs: Record<string, Record<string, unknown>> = {};
    for (const [stepPath, stepOutputMap] of this.stepOutputs) {
      outputs[stepPath] = { ...stepOutputMap };
    }

    return {
      inputs: { ...this.inputs },
      outputs,
      stepOrder: [...this.stepOrder],
      currentStep: this.currentStepPath,
    };
  }
}
