export type DocumentType =
  | 'directive'
  | 'step'
  | 'process'
  | 'guard'
  | 'persona'
  | 'schema'
  | 'trigger'
  | 'test';

export type InputType = 'text' | 'file' | 'data' | 'url';

export type OutputType = 'text' | 'file' | 'data';

export type CheckClassification = 'deterministic' | 'semantic' | 'hybrid';

export interface InputDeclaration {
  name: string;
  type: InputType;
  required: boolean;
  description: string;
  schema?: string;
}

export interface OutputDeclaration {
  name: string;
  type: OutputType;
  description: string;
  schema?: string;
}

/** @deprecated Use InputDeclaration */
export type InputDef = InputDeclaration;
/** @deprecated Use OutputDeclaration */
export type OutputDef = OutputDeclaration;

export interface Section {
  heading: string;
  level: number;
  rawContent: string;
  children: Section[];
}

export interface InputDescription {
  name: string;
  type: string;
  requiredText: string;
  description: string;
}

export interface OutputDescription {
  name: string;
  type: string;
  description: string;
}

export interface OutputSpec {
  descriptions: OutputDescription[];
  format?: string;
}

export interface VerdictField {
  name: string;
  description: string;
}

export interface VerdictSpec {
  fields: VerdictField[];
}

export interface Frontmatter {
  type: DocumentType;
  title: string;
  description: string;
  inputs?: InputDeclaration[];
  outputs?: OutputDeclaration[];
  tags?: string[];
  persona?: string;
  target?: string;
}

export interface FilterArg {
  key: string;
  value: string;
}

export interface Filter {
  name: string;
  args?: FilterArg[];
}

export type TemplateExpr =
  | VariableRef
  | PropertyAccess
  | FilterExpr
  | ConditionalBlock;

export interface VariableRef {
  kind: 'variable_ref';
  name: string;
}

export interface PropertyAccess {
  kind: 'property_access';
  root: string;
  path: string[];
}

export interface FilterExpr {
  kind: 'filter';
  operand: VariableRef | PropertyAccess;
  filters: Filter[];
}

export interface ConditionalBlock {
  kind: 'conditional';
  variable: string;
  body: TemplateContent[];
}

export type TemplateContent = TemplateLiteral | TemplateExpr;

export interface TemplateLiteral {
  kind: 'literal';
  text: string;
}

export type ExecutionBlock = NLStep | AIBlock | CodeBlock;

export interface NLStep {
  kind: 'nl_step';
  number: number;
  text: string;
}

export interface AIBlock {
  kind: 'ai_block';
  template: TemplateContent[];
}

export interface CodeBlock {
  kind: 'code_block';
  language: string;
  source: string;
}

export type Routing = LinearRoute | ConditionalRoute | GuardRoute | TerminalRoute;

export interface LinearRoute {
  kind: 'linear';
  next: string;
}

export interface ConditionalBranch {
  condition: string;
  then: string;
}

export interface ConditionalRoute {
  kind: 'conditional';
  branches: ConditionalBranch[];
  default: string;
}

export interface GuardRoute {
  kind: 'guard';
  onPass: string;
  onFail: string;
}

export interface TerminalRoute {
  kind: 'terminal';
}

export interface GuardCheck {
  number: number;
  title: string;
  description: string;
  classification: CheckClassification;
}

export interface SchemaField {
  name: string;
  type: string;
  required: boolean;
  description: string;
  subfields?: SchemaField[];
}

export interface SchemaConstraint {
  raw: string;
}

export interface TestInput {
  name: string;
  value: string;
}

export interface TestExpectation {
  field: string;
  condition: string;
}

export interface TestCase {
  name: string;
  number: number;
  inputs: TestInput[];
  expected: TestExpectation[];
}

export interface TestAssertion {
  text: string;
}

export interface ProcessStep {
  number: number;
  name: string;
  path: string;
  description: string;
}

export interface PersonaSections {
  identity: string;
  expertise: string;
  behavior: string;
}

export interface TriggerEvent {
  source: string;
  condition: string;
  frequency: string;
}

export interface TriggerInputMapping {
  from: string;
  to: string;
}

export interface TriggerTarget {
  process: string;
  mappings: TriggerInputMapping[];
}

export interface TalkdownDocument {
  frontmatter: Frontmatter;
  title: string;
  introduction: string;
  filePath: string;

  context?: string;
  inputDescriptions?: InputDescription[];
  execution?: ExecutionBlock[];
  output?: OutputSpec;
  routing?: Routing;

  checks?: GuardCheck[];
  checksAIBlock?: AIBlock;
  verdict?: VerdictSpec;

  personaSections?: PersonaSections;

  fields?: SchemaField[];
  constraints?: SchemaConstraint[];
  schemaExample?: unknown;

  event?: TriggerEvent;
  triggerTarget?: TriggerTarget;

  steps?: ProcessStep[];

  cases?: TestCase[];
  assertions?: TestAssertion[];
}
