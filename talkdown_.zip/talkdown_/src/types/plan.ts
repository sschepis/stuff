import type { Frontmatter, SchemaField } from './ast.js';

export type ExecutionMode = 'deterministic' | 'llm' | 'hybrid';

export type PlanNodeKind =
  | 'validate_inputs'
  | 'load_persona'
  | 'template_expand'
  | 'execute_nl_step'
  | 'execute_ai_block'
  | 'execute_code_block'
  | 'validate_schema'
  | 'deterministic_check'
  | 'llm_guard_check'
  | 'compute_verdict'
  | 'evaluate_routing'
  | 'deterministic_route'
  | 'llm_route'
  | 'circuit_breaker'
  | 'accumulate_output'
  | 'format_output'
  | 'workflow_step'
  | 'workflow_entry'
  | 'workflow_exit';

export type PlanNodeConfig =
  | ValidateInputsConfig
  | LoadPersonaConfig
  | TemplateExpandConfig
  | ExecuteNLStepConfig
  | ExecuteAIBlockConfig
  | ExecuteCodeBlockConfig
  | ValidateSchemaConfig
  | DeterministicCheckConfig
  | LLMGuardCheckConfig
  | ComputeVerdictConfig
  | EvaluateRoutingConfig
  | DeterministicRouteConfig
  | LLMRouteConfig
  | CircuitBreakerConfig
  | AccumulateOutputConfig
  | FormatOutputConfig
  | WorkflowStepConfig
  | WorkflowEntryConfig
  | WorkflowExitConfig;

export interface ValidateInputsConfig {
  kind: 'validate_inputs';
  requiredInputs: string[];
}

export interface LoadPersonaConfig {
  kind: 'load_persona';
  personaPath: string;
}

export interface TemplateExpandConfig {
  kind: 'template_expand';
  templateIndex: number;
}

export interface ExecuteNLStepConfig {
  kind: 'execute_nl_step';
  stepNumber: number;
  text: string;
}

export interface ExecuteAIBlockConfig {
  kind: 'execute_ai_block';
  blockIndex: number;
}

export interface ExecuteCodeBlockConfig {
  kind: 'execute_code_block';
  language: string;
  blockIndex: number;
}

export interface ValidateSchemaConfig {
  kind: 'validate_schema';
  schemaPath: string;
  direction: 'input' | 'output';
  fieldName: string;
}

export interface DeterministicCheckConfig {
  kind: 'deterministic_check';
  checkNumber: number;
}

export interface LLMGuardCheckConfig {
  kind: 'llm_guard_check';
  checkNumber: number;
  prompt: string;
}

export interface ComputeVerdictConfig {
  kind: 'compute_verdict';
  checkNodeIds: string[];
}

export interface EvaluateRoutingConfig {
  kind: 'evaluate_routing';
}

export interface DeterministicRouteConfig {
  kind: 'deterministic_route';
  targetPath: string;
}

export interface LLMRouteConfig {
  kind: 'llm_route';
  conditions: string[];
}

export interface CircuitBreakerConfig {
  kind: 'circuit_breaker';
  maxIterations: number;
  stepId: string;
}

export interface AccumulateOutputConfig {
  kind: 'accumulate_output';
  fieldName: string;
}

export interface FormatOutputConfig {
  kind: 'format_output';
  outputFields: string[];
}

export interface WorkflowStepConfig {
  kind: 'workflow_step';
  stepPath: string;
  stepNumber: number;
}

export interface WorkflowEntryConfig {
  kind: 'workflow_entry';
  processPath: string;
}

export interface WorkflowExitConfig {
  kind: 'workflow_exit';
}

export interface PlanNode {
  id: string;
  kind: PlanNodeKind;
  label: string;
  inputs: string[];
  executionMode: ExecutionMode;
  documentPath?: string;
  config: PlanNodeConfig;
}

export interface DocumentEntry {
  path: string;
  frontmatter: Frontmatter;
}

export interface WorkflowStateSchema {
  fields: SchemaField[];
}

export interface ExecutionPlan {
  entryNode: string;
  nodes: Map<string, PlanNode>;
  documents: Map<string, DocumentEntry>;
  workflowState: WorkflowStateSchema;
}
