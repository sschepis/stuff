export type ComparisonOp = 'gt' | 'gte' | 'lt' | 'lte' | 'eq';

export type SizeOp = 'lte' | 'gte' | 'eq' | 'between';

export type SumTotal =
  | { kind: 'field_ref'; field: string }
  | { kind: 'literal'; value: number };

export type CompiledExpr =
  | StringLength
  | WordCount
  | EnumCheck
  | Required
  | Populated
  | NotEmpty
  | NumericCompare
  | ArrayLength
  | ConditionalRule
  | SumEquality
  | FieldEquals
  | And
  | Or;

export interface StringLength {
  kind: 'string_length';
  field: string;
  op: SizeOp;
  value: number;
  value2?: number;
}

export interface WordCount {
  kind: 'word_count';
  field: string;
  op: SizeOp;
  value: number;
  value2?: number;
}

export interface EnumCheck {
  kind: 'enum_check';
  field: string;
  allowed: string[];
}

export interface Required {
  kind: 'required';
  field: string;
}

export interface Populated {
  kind: 'populated';
  field: string;
}

export interface NotEmpty {
  kind: 'not_empty';
  field: string;
}

export interface NumericCompare {
  kind: 'numeric_compare';
  field: string;
  op: ComparisonOp;
  value: number;
}

export interface ArrayLength {
  kind: 'array_length';
  field: string;
  op: SizeOp;
  value: number;
  value2?: number;
}

export interface ConditionalRule {
  kind: 'conditional_rule';
  condition: CompiledExpr;
  then: CompiledExpr;
}

export interface SumEquality {
  kind: 'sum_equality';
  fields: string[];
  total: SumTotal;
}

export interface FieldEquals {
  kind: 'field_equals';
  field: string;
  value: string;
}

export interface And {
  kind: 'and';
  exprs: CompiledExpr[];
}

export interface Or {
  kind: 'or';
  exprs: CompiledExpr[];
}

export interface ConstraintResult {
  pass: boolean;
  detail: string;
  field?: string;
}

import type { GuardCheck, TalkdownDocument, CheckClassification } from './ast.js';

export interface ClassifiedConstraint {
  raw: string;
  classification: 'deterministic' | 'semantic';
  compiled?: CompiledExpr;
}

export interface ClassifiedGuardCheck {
  original: GuardCheck;
  classification: CheckClassification;
  deterministicGates: CompiledExpr[];
  semanticResidual: string | null;
}

export interface ClassifiedCondition {
  raw: string;
  classification: 'deterministic' | 'semantic';
  compiled?: CompiledExpr;
}

export interface AnalyzedDocument {
  document: TalkdownDocument;
  classifiedConstraints?: ClassifiedConstraint[];
  classifiedChecks?: ClassifiedGuardCheck[];
  classifiedRouting?: ClassifiedCondition[];
  stats: {
    totalElements: number;
    deterministic: number;
    semantic: number;
    hybrid: number;
  };
}
