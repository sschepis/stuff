---
type: guard
title: "Guard Title"
description: "One-line description of what this guard validates"
inputs:
  - name: output_to_validate
    type: text
    required: true
    description: "The output from the previous step to validate"
tags: [quality, validation]
---

# Guard Title

Brief description of what this guard checks and what quality bar it enforces.

## Inputs

- **output_to_validate** (text, required): The output from the preceding step. Describe what you expect it to contain.

## Checks

1. First validation criterion
2. Second validation criterion

```ai
Evaluate the following output against these quality criteria:

{{output_to_validate}}

For each criterion, determine:
- **Status**: pass or fail
- **Details**: Why it passed or what specifically failed

Criteria:
1. [First criterion]
2. [Second criterion]
3. [Third criterion]
```

## Verdict

- **result** (text): `pass` if all checks succeed, `fail` if any check fails.
- **feedback** (text): Specific, actionable feedback on what failed and how to fix it. Empty if all checks pass.

## Routing

- on_pass: ./next-step.md
- on_fail: ./previous-step.md
