---
type: trigger
title: "Trigger Name"
description: "One-line description of what event activates this trigger"
target: ./process.md
tags: [automation, domain]
---

# Trigger Name

Brief description of when this trigger fires and what workflow it activates.

## Event

Describe the event or condition that activates this trigger:

- **Source**: Where the event originates (e.g., file system, API, schedule, user action)
- **Condition**: What specifically must happen for the trigger to fire
- **Frequency**: How often this event can occur (one-time, recurring, on-demand)

## Inputs

What data the event provides to the target workflow:

- **event_data** (text): Description of the data available when the event fires

## Target

- **Process**: [Target Workflow] — the process to activate. The target path is declared in the frontmatter `target` field above.
- **Input mapping**:
  - `event_data` → `workflow_input_name`
