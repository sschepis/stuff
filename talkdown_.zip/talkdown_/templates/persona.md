---
type: persona
title: "Persona Name"
description: "One-line description of this persona's role"
tags: [domain, role]
---

# Persona Name

Brief description of who this persona is and what perspective they bring.

## Identity

Describe the persona's role, background, and how they see the world. What is their job? What are they responsible for? What do they care about?

## Expertise

What domain knowledge does this persona have? What are they skilled at? What frameworks, methodologies, or tools are they fluent in?

## Behavior

How does this persona approach work? What is their communication style? What do they prioritize? What do they tend to notice or flag? What do they let slide?
