---
type: process
title: "Process Title"
description: "One-line description of this workflow"
inputs:
  - name: initial_input
    type: text
    required: true
    description: "The starting input for this workflow"
outputs:
  - name: final_output
    type: text
    description: "The final deliverable of this workflow"
tags: [category]
---

# Process Title

Brief description of the workflow's purpose and what it accomplishes end-to-end.

## Steps

| Step | Document | Description |
|------|----------|-------------|
| 1 | [Step Name](./01-step-name.md) | What this step does |
| 2 | [Step Name](./02-step-name.md) | What this step does |
| 3 | [Step Name](./03-step-name.md) | What this step does |

## Flow

Describe how control flows through the steps:

1. Start at **Step 1**
2. Each step routes to the next upon completion
3. Steps may self-loop for iterative refinement
4. The workflow completes when the final step routes to `none`

## Routing

- next: ./01-step-name.md
