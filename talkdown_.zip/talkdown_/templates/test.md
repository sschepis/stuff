---
type: test
title: "Test Name"
description: "One-line description of what this test validates"
target: ./directive-or-step.md
tags: [testing, domain]
---

# Test Name

Brief description of what behavior is being tested and why it matters.

## Target

[Directive or Step Name] — the document under test. The target path is declared in the frontmatter `target` field above.

## Cases

### Case 1: Happy path

**Input:**
- `input_name`: "A well-formed input value"

**Expected Output:**
- `output_name` should contain a valid result
- The result should follow the output format specification

### Case 2: Edge case — empty input

**Input:**
- `input_name`: ""

**Expected Output:**
- Should report that `input_name` is required and missing

### Case 3: Edge case — ambiguous input

**Input:**
- `input_name`: "A vague or ambiguous value"

**Expected Output:**
- Should produce a reasonable result or ask for clarification
- Should not hallucinate or produce confident-sounding nonsense

## Assertions

- All required output fields must be present
- Output format must match the target's `### Output Format` specification
- No fabricated data — outputs must derive from the provided inputs
