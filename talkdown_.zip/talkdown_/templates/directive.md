---
type: directive
title: "Directive Title"
description: "One-line description of what this directive does"
inputs:
  - name: input_name
    type: text
    required: true
    description: "Description of this input"
outputs:
  - name: output_name
    type: text
    description: "Description of this output"
tags: [category]
---

# Directive Title

Brief description of what this directive does and when to use it.

## Inputs

- **input_name** (text, required): Detailed description of the input, including any constraints, expected format, or examples.

## Execution

1. First step of the execution process
2. Second step

```ai
Optional AI prompt block for generative sub-tasks.
Use {{input_name}} to reference inputs.
```

3. Additional steps after the AI block

## Output

- **output_name** (text): Description of the output, including format requirements.

### Output Format

Specify the exact structure of the expected output here.
