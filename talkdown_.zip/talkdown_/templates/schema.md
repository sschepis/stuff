---
type: schema
title: "Schema Name"
description: "One-line description of what data this schema defines"
tags: [data, domain]
---

# Schema Name

Brief description of what this data represents and where it's used in workflows.

## Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `field_name` | string | yes | What this field contains |
| `another_field` | number | no | What this field represents |
| `nested_object` | object | yes | A structured sub-object (see below) |

### nested_object

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `sub_field` | string | yes | Description |

## Constraints

- `field_name` must not be empty
- `another_field` must be between 0 and 100 when provided
- At least one of `field_a` or `field_b` must be present

## Example

```json
{
  "field_name": "example value",
  "another_field": 42,
  "nested_object": {
    "sub_field": "nested value"
  }
}
```
