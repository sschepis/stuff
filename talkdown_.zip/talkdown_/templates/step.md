---
type: step
title: "Step Title"
description: "One-line description of what this step does"
inputs:
  - name: previous_output
    type: text
    required: true
    description: "Output from the previous step"
outputs:
  - name: step_output
    type: text
    description: "What this step produces"
tags: [category]
---

# Step Title

Brief description of this step's role in the overall workflow.

## Context

Optional persona, domain knowledge, or framing to adopt while executing this step.

## Inputs

- **previous_output** (text, required): The output from the preceding step. Expected to contain specific data or structure from the prior stage.

## Execution

1. Review the input from the previous step
2. Perform the core work of this step

```ai
Optional AI prompt block for generative sub-tasks.
Use {{previous_output}} to reference inputs.
```

3. Validate and refine the results

## Output

- **step_output** (text): Description of what this step produces.

### Output Format

Specify the exact structure of the expected output here.

## Routing

- if: "the output meets completion criteria"
  then: ./next-step.md
- default: ./this-step.md
