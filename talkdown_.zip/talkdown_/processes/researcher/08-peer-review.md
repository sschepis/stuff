---
type: step
title: "Peer Review Simulation"
description: "Simulate academic peer review to evaluate the research paper and identify remaining issues."
inputs:
  - name: research_paper
    type: file
    required: true
    description: "The draft research paper to review"
outputs:
  - name: peer_review
    type: file
    description: "Peer review report with critiques and recommendations"
tags: [research, peer-review, evaluation, quality-assurance]
---

# Peer Review Simulation

Simulate a rigorous academic peer review of the research paper, evaluating it against publication standards and identifying remaining weaknesses.

## Context

You are simulating the role of an independent academic peer reviewer. Apply the standards of a top-tier journal: evaluate novelty, rigor, clarity, and significance. Be constructive but thorough.

## Inputs

- **research_paper**: The draft research paper from step 07. Read {{research_paper}} as the submission to review.

## Execution

1. Read the complete research paper as an independent reviewer would.
2. Evaluate the paper for novelty, significance, and contribution to the field.
3. Assess the methodology, including mathematical models and simulations.
4. Check logical consistency, soundness of arguments, and quality of evidence.
5. Identify weaknesses, errors, and areas requiring additional clarification or experimentation.
6. Provide specific, actionable suggestions for improving the paper.
7. Render a recommendation: accept, revise, or reject (with justification).

```ai
Perform a peer review of the following research paper:

{{research_paper}}

Evaluate against these criteria:
- **Novelty**: Does this make a new contribution?
- **Significance**: Is the contribution meaningful?
- **Rigor**: Are the methods sound and well-documented?
- **Clarity**: Is the paper well-written and well-organized?
- **Completeness**: Are there gaps in the argument or evidence?

Provide:
- Summary of the paper's contributions
- Major concerns (must be addressed)
- Minor concerns (should be addressed)
- Specific suggestions for improvement
- Overall recommendation with justification
```

## Output

A peer review report with detailed critiques and recommendations for improving the paper.

### Output Format

A markdown document (`peer_review.md`) with:
- Summary of contributions
- Major concerns
- Minor concerns
- Specific suggestions
- Overall recommendation (accept / revise / reject)

## Routing

- if: "peer review is complete and all issues are documented"
  then: ./01-literature-review.md
- default: ./08-peer-review.md
