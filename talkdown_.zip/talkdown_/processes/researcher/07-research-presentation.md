---
type: step
title: "Research Presentation"
description: "Compile all refined research into a coherent, presentation-ready research paper."
inputs:
  - name: refined_hypotheses
    type: file
    required: true
    description: "Refined hypotheses from the refinement step"
  - name: refined_models
    type: file
    required: true
    description: "Refined mathematical models"
  - name: refined_simulations
    type: file
    required: true
    description: "Refined simulation scripts and results"
  - name: literature_review
    type: file
    required: true
    description: "Literature review report for context and citations"
outputs:
  - name: research_paper
    type: file
    description: "A complete, presentation-ready research paper"
tags: [research, presentation, writing, publication]
---

# Research Presentation

Compile all refined research artifacts into a coherent, well-structured research paper suitable for presentation or publication.

## Context

You are a researcher preparing your work for presentation. Synthesize the literature review, hypotheses, models, simulations, and refinements into a unified narrative that clearly communicates the research contributions.

## Inputs

- **refined_hypotheses**: The refined hypotheses. Read {{refined_hypotheses}}.
- **refined_models**: The refined mathematical models. Read {{refined_models}}.
- **refined_simulations**: The refined simulation scripts and results. Read {{refined_simulations}}.
- **literature_review**: The literature review for context and citations. Read {{literature_review}}.

## Execution

1. Organize the research into a standard academic paper structure.
2. Write an introduction grounding the work in the literature review.
3. Present hypotheses with clear motivation and context.
4. Describe mathematical models with full formal detail.
5. Present simulation design, methodology, and results.
6. Discuss findings, implications, and limitations.
7. Write a conclusion summarizing contributions and future directions.
8. Assess whether the paper is complete and ready for peer review.

```ai
Compile the following research artifacts into a presentation-ready research paper:

Literature Review: {{literature_review}}
Hypotheses: {{refined_hypotheses}}
Mathematical Models: {{refined_models}}
Simulations: {{refined_simulations}}

Structure the paper with:
- Abstract
- Introduction (grounded in literature review)
- Hypotheses and Theoretical Framework
- Mathematical Models
- Simulation Design and Results
- Discussion
- Conclusion and Future Work
- References
```

## Output

A complete, presentation-ready research paper that synthesizes all research artifacts into a coherent narrative.

### Output Format

A markdown document (`research_paper.md`) following standard academic paper structure with all sections fully developed.

## Routing

- if: "research paper is complete and ready for review"
  then: ./08-peer-review.md
- default: ./07-research-presentation.md
