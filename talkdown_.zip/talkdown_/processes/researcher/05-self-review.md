---
type: step
title: "Self-Review and Critique"
description: "Critically evaluate all research work so far, assessing logic, assumptions, and scientific rigor."
inputs:
  - name: hypotheses
    type: file
    required: true
    description: "Generated hypotheses"
  - name: mathematical_models
    type: file
    required: true
    description: "Mathematical model descriptions"
  - name: simulation_scripts
    type: file
    required: true
    description: "Simulation design and scripts"
outputs:
  - name: self_review
    type: file
    description: "Review report with critiques, improvement suggestions, and justifications"
tags: [research, review, critique, quality-assurance]
---

# Self-Review and Critique

Employ a methodical approach to critique the research work produced so far, identifying weaknesses and areas for improvement.

## Context

You are acting as a critical reviewer of your own research. Apply rigorous scientific standards to evaluate the hypotheses, mathematical models, and simulations. Be thorough and honest about weaknesses.

## Inputs

- **hypotheses**: The generated hypotheses from step 02. Read {{hypotheses}}.
- **mathematical_models**: The mathematical models from step 03. Read {{mathematical_models}}.
- **simulation_scripts**: The simulation designs from step 04. Read {{simulation_scripts}}.

## Execution

1. Review each hypothesis for logical consistency, testability, and grounding in the literature.
2. Evaluate each mathematical model for correctness, completeness, and fidelity to its hypothesis.
3. Assess each simulation for accurate implementation of its model and proper validation.
4. Generate a critical analysis assessing logic, assumptions, and scientific rigor across all work.
5. Identify specific areas for improvement and suggest concrete changes.
6. Assess whether the critique is thorough enough to proceed to refinement.

```ai
Critically review the following research artifacts:

Hypotheses: {{hypotheses}}
Mathematical Models: {{mathematical_models}}
Simulations: {{simulation_scripts}}

For each artifact, evaluate:
- Logical consistency and soundness
- Assumptions: are they justified and explicit?
- Scientific rigor: does this meet publication standards?
- Completeness: are there gaps or missing elements?

Provide specific, actionable suggestions for improvement.
```

## Output

A review report containing critiques, suggestions for improvement, and justifications for each recommendation.

### Output Format

A markdown document (`self_review.md`) organized by:
- Hypothesis critiques
- Model critiques
- Simulation critiques
- Cross-cutting concerns
- Prioritized list of recommended improvements

## Routing

- if: "critique is thorough and actionable"
  then: ./06-research-refinement.md
- default: ./05-self-review.md
