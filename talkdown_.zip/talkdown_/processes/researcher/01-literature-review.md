---
type: step
title: "Literature Review and Analysis"
description: "Analyze academic papers to identify key findings, gaps, and opportunities for further study."
inputs:
  - name: source_papers
    type: file
    required: true
    description: "Directory of academic papers in markdown format"
outputs:
  - name: literature_review
    type: file
    description: "Report summarizing the research landscape, key findings, methodologies, and gaps"
tags: [research, literature-review, analysis]
---

# Literature Review and Analysis

Read and deeply analyze academic papers in the research domain, synthesizing findings into a comprehensive landscape report that identifies gaps and opportunities.

## Context

You are a scientific researcher conducting a thorough literature review. Your goal is to understand the current state of knowledge, identify methodological patterns, and find opportunities for novel contributions.

## Inputs

- **source_papers**: A directory containing academic papers in markdown format. Read all files in {{source_papers}} and its subfolders to locate the papers for review.

## Execution

1. Read each paper in the source directory, deeply considering the material and its implications.
2. Identify key findings, methodologies, research gaps, and opportunities for further study.
3. Extract and parse mathematical models mentioned in the papers.
4. Use the principle of equivalence to make connections between the papers.
5. Synthesize the analysis into a structured report.

```ai
Analyze the following academic papers from {{source_papers}}.

For each paper:
- Summarize the key findings and contributions
- Note the methodology used
- Identify mathematical models presented
- Flag any limitations or gaps

Then synthesize across all papers:
- What patterns emerge across the literature?
- Where are the research gaps?
- What connections exist between papers (especially via equivalence principles)?
- What opportunities exist for further study?
```

## Output

A report summarizing the current landscape of research and potential areas for exploration. Append to and occasionally update this report as the research continues.

### Output Format

A markdown document (`literature_review.md`) with sections for:
- Paper-by-paper analysis
- Cross-cutting themes and connections
- Identified research gaps
- Recommended areas for exploration

## Routing

- if: "literature review is sufficiently comprehensive"
  then: ./02-hypothesis-generation.md
