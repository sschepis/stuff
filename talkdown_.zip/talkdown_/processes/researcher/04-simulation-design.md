---
type: step
title: "Simulation Design"
description: "Create computational simulations to validate the mathematical models."
inputs:
  - name: mathematical_models
    type: file
    required: true
    description: "Descriptions and formulas of the proposed mathematical models"
outputs:
  - name: simulation_scripts
    type: file
    description: "Simulation scripts ready for execution"
  - name: simulations_directory
    type: file
    description: "Directory of simulation files named after their corresponding models"
tags: [research, simulation, computational, validation]
---

# Simulation Design

Translate mathematical models into computational simulations that can be executed to validate hypotheses.

## Context

You are a computational researcher designing simulations to test mathematical models. The simulations should faithfully implement the models and produce measurable, interpretable results.

## Inputs

- **mathematical_models**: Descriptions and formulas of the proposed mathematical models. Read {{mathematical_models}} to understand what needs to be simulated.

## Execution

1. For each mathematical model, design a computational simulation.
2. Script code to simulate each model computationally.
3. Define parameters, initial conditions, and simulation boundaries.
4. Set up simulation environments and validate code functionality.
5. Name simulation files after their corresponding models.
6. Save all scripts in a `simulations/` directory.
7. Assess whether the simulations are complete and functional.

```ai
For each model in {{mathematical_models}}:

- Design a simulation that implements the model's equations
- Define:
  - Input parameters and their default values
  - Simulation boundaries and termination conditions
  - Output metrics and how to interpret them
- Write the simulation script
- Validate that the code runs and produces expected output
- Save to simulations/ directory with a descriptive filename
```

## Output

Simulation scripts ready for execution, saved in the `simulations/` directory with files named after their corresponding models.

### Output Format

- Individual simulation scripts in `simulations/`, one per model
- A summary document describing each simulation, its parameters, and expected outputs

## Routing

- if: "simulations are complete and validated"
  then: ./05-self-review.md
- default: ./04-simulation-design.md
