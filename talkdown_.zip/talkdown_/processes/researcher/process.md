---
type: process
title: "Research Process"
description: "Iterative scientific research workflow from literature review through peer review, with self-loops for depth and a full cycle back to literature review for continuous refinement."
inputs:
  - name: research_domain
    type: text
    required: true
    description: "The scientific domain or topic area to research"
  - name: source_papers
    type: file
    required: true
    description: "Directory or collection of academic papers to review"
outputs:
  - name: research_paper
    type: file
    description: "Finalized research paper incorporating hypotheses, models, simulations, and peer review feedback"
  - name: simulations
    type: file
    description: "Simulation scripts validating the mathematical models"
  - name: peer_review
    type: file
    description: "Peer review report with recommendations"
tags: [research, scientific-method, iterative]
---

# Research Process

A structured scientific research workflow that moves from literature review through hypothesis generation, mathematical modeling, simulation design, self-review, refinement, presentation, and peer review. The process is iterative: most steps can self-loop for deeper work, and the final peer review step cycles back to literature review for continuous improvement.

## Steps

| Step | File | Description |
|------|------|-------------|
| 01 | [Literature Review](./01-literature-review.md) | Analyze academic papers, identify gaps and opportunities |
| 02 | [Hypothesis Generation](./02-hypothesis-generation.md) | Formulate testable hypotheses from the literature |
| 03 | [Mathematical Modeling](./03-mathematical-modeling.md) | Build formal models to represent hypotheses |
| 04 | [Simulation Design](./04-simulation-design.md) | Create computational simulations for the models |
| 05 | [Self-Review](./05-self-review.md) | Critically evaluate all work so far |
| 06 | [Research Refinement](./06-research-refinement.md) | Refine hypotheses, models, and simulations based on critique |
| 07 | [Research Presentation](./07-research-presentation.md) | Compile findings into a presentable research paper |
| 08 | [Peer Review](./08-peer-review.md) | Simulate peer review and identify remaining issues |

## Flow

```
01-literature-review
        |
        v
02-hypothesis-generation  <--+
        |                     |  (self-loop)
        +---------------------+
        |
        v
03-mathematical-modeling   <--+
        |                     |  (self-loop)
        +---------------------+
        |
        v
04-simulation-design       <--+
        |                     |  (self-loop)
        +---------------------+
        |
        v
05-self-review             <--+
        |                     |  (self-loop)
        +---------------------+
        |
        v
06-research-refinement     <--+
        |                     |  (self-loop)
        +---------------------+
        |
        v
07-research-presentation   <--+
        |                     |  (self-loop)
        +---------------------+
        |
        v
08-peer-review             <--+
        |                     |  (self-loop)
        +---> 01-literature-review  (full cycle)
```

Each step may self-loop to iterate on its own output before advancing. Step 08 routes back to step 01 to begin a new research cycle with accumulated knowledge.

## Routing

- next: ./01-literature-review.md
