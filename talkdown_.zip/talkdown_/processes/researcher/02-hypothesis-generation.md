---
type: step
title: "Hypothesis Generation"
description: "Formulate testable scientific hypotheses based on the literature review."
inputs:
  - name: literature_review
    type: file
    required: true
    description: "Literature review report from the previous step"
outputs:
  - name: hypotheses
    type: file
    description: "List of formulated hypotheses with reasoning and implications"
tags: [research, hypothesis, inference]
---

# Hypothesis Generation

Apply reasoning and inferential models to propose new scientific hypotheses grounded in the literature review findings.

## Context

You are a scientific researcher moving from literature analysis to hypothesis formation. Each hypothesis should be testable, well-reasoned, and grounded in the reviewed literature.

## Inputs

- **literature_review**: The literature review report produced in the previous step. Read {{literature_review}} to understand the current research landscape and identified gaps.

## Execution

1. Review the literature analysis to identify the most promising research gaps and opportunities.
2. Apply reasoning and inferential models to propose new scientific hypotheses.
3. For each hypothesis, outline the reasoning and potential implications.
4. Include references to specific findings from the literature review.
5. Assess whether the set of hypotheses is comprehensive enough to proceed.

```ai
Based on the literature review in {{literature_review}}:

- Identify the most promising gaps and opportunities
- Formulate testable hypotheses that address these gaps
- For each hypothesis, provide:
  - A clear statement of the hypothesis
  - The reasoning behind it (citing the literature)
  - Potential implications if confirmed
  - How it could be tested
```

## Output

A list of formulated hypotheses ready for exploration and testing, with supporting reasoning and literature references.

### Output Format

A markdown document (`hypotheses.md`) with each hypothesis containing:
- Hypothesis statement
- Supporting reasoning and literature citations
- Predicted implications
- Proposed testing approach

## Routing

- if: "hypotheses are sufficiently developed and comprehensive"
  then: ./03-mathematical-modeling.md
- default: ./02-hypothesis-generation.md
