---
type: step
title: "Mathematical Modeling"
description: "Develop formal mathematical models to represent and test the generated hypotheses."
inputs:
  - name: hypotheses
    type: file
    required: true
    description: "List of hypotheses requiring mathematical formalization"
outputs:
  - name: mathematical_models
    type: file
    description: "Detailed descriptions of mathematical models including formulas, assumptions, and variables"
tags: [research, mathematical-modeling, formalization]
---

# Mathematical Modeling

Define and document mathematical models that formally represent the hypotheses, enabling rigorous testing through simulation.

## Context

You are a researcher constructing mathematical models to formalize hypotheses. Each model should be precise enough to implement computationally while faithfully representing the theoretical claims.

## Inputs

- **hypotheses**: The list of hypotheses generated in the previous step. Read {{hypotheses}} to understand what needs to be modeled mathematically.

## Execution

1. Define the scope and structure of each model based on the hypotheses and literature review.
2. Use computational techniques to create or extend the mathematical models.
3. Document the assumptions underlying each model.
4. Specify all variables, parameters, and their domains.
5. Write out the formulas and equations that constitute each model.
6. Assess whether the models are sufficiently developed to proceed to simulation.

```ai
For each hypothesis in {{hypotheses}}:

- Define a mathematical model that formalizes the hypothesis
- Document:
  - Assumptions and constraints
  - Variables and parameters (with domains and units)
  - Core equations and formulas
  - Expected behavior and boundary conditions
- Explain how the model maps to the hypothesis it represents
```

## Output

Detailed descriptions of proposed mathematical models, including formulas, assumptions, and variables.

### Output Format

A markdown document (`mathematical_models.md`) with each model containing:
- Model name and corresponding hypothesis
- Assumptions and constraints
- Variable and parameter definitions
- Equations and formulas
- Expected behavior

## Routing

- if: "mathematical models are complete and ready for simulation"
  then: ./04-simulation-design.md
- default: ./03-mathematical-modeling.md
