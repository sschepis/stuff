---
type: step
title: "Research Refinement"
description: "Refine hypotheses, models, and simulations based on self-review critique."
inputs:
  - name: self_review
    type: file
    required: true
    description: "Critique report from the self-review step"
  - name: hypotheses
    type: file
    required: true
    description: "Original hypotheses to be refined"
  - name: mathematical_models
    type: file
    required: true
    description: "Original mathematical models to be improved"
  - name: simulation_scripts
    type: file
    required: true
    description: "Original simulation scripts to be updated"
outputs:
  - name: refined_hypotheses
    type: file
    description: "Updated hypotheses incorporating critique feedback"
  - name: refined_models
    type: file
    description: "Improved mathematical models"
  - name: refined_simulations
    type: file
    description: "Updated simulation scripts"
  - name: refinement_log
    type: file
    description: "Document of changes made and rationale behind them"
tags: [research, refinement, iteration, improvement]
---

# Research Refinement

Update and improve all research artifacts based on the self-review critique, documenting every change and its rationale.

## Context

You are a researcher incorporating feedback from critical self-review. Apply the suggested improvements systematically, ensuring each change is justified and documented.

## Inputs

- **self_review**: The critique report from step 05. Read {{self_review}} for the specific improvements to address.
- **hypotheses**: The original hypotheses. Read {{hypotheses}}.
- **mathematical_models**: The original models. Read {{mathematical_models}}.
- **simulation_scripts**: The original simulations. Read {{simulation_scripts}}.

## Execution

1. Review the critique report and prioritize the suggested improvements.
2. Update and refine hypotheses to address identified weaknesses.
3. Improve mathematical models as suggested in the critique.
4. Update simulation scripts to reflect model improvements.
5. Document every change made and the rationale behind it.
6. Assess whether refinements are sufficient to proceed to presentation.

```ai
Based on the critique in {{self_review}}, refine the research artifacts:

Hypotheses: {{hypotheses}}
Models: {{mathematical_models}}
Simulations: {{simulation_scripts}}

For each suggested improvement:
- Apply the change
- Document what was changed and why
- Verify the change doesn't introduce new issues

Produce refined versions of all artifacts plus a change log.
```

## Output

Refined hypotheses, updated models, and improved simulations, along with a refinement log documenting all changes.

### Output Format

- Updated `hypotheses.md` with refinements
- Updated `mathematical_models.md` with improvements
- Updated simulation scripts in `simulations/`
- A `refinement_log.md` documenting each change and its rationale

## Routing

- if: "refinements are complete and address all critical feedback"
  then: ./07-research-presentation.md
- default: ./06-research-refinement.md
