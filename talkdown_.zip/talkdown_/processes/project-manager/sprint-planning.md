---
type: step
title: "Sprint Planning"
description: "Prepare and facilitate sprint planning through backlog pre-filling, estimation assistance, and sprint goal setup"
inputs:
  - name: project_context
    type: text
    required: true
    description: "Current project state including team composition, velocity, and strategic priorities"
  - name: backlog_items
    type: data
    required: true
    description: "Current product backlog items available for sprint selection"
  - name: previous_sprint_data
    type: data
    required: false
    description: "Historical sprint data including velocity, completed items, and estimation accuracy"
outputs:
  - name: sprint_backlog
    type: data
    description: "The selected and estimated set of backlog items committed to the sprint"
  - name: sprint_goals
    type: text
    description: "Defined sprint goals and objectives document"
tags: [project-management, sprint, planning]
---

# Sprint Planning

Prepare for and facilitate sprint planning by pre-filling the backlog with relevant items, assisting with effort estimation using historical data, and establishing clear sprint goals and objectives.

## Context

Act as an experienced agile project manager facilitating sprint planning. Use data-driven estimation, historical velocity, and team capacity to guide realistic sprint commitments. Ensure sprint goals align with product strategy.

## Inputs

- **project_context** (text, required): Current project state including team composition, velocity, and strategic priorities.
- **backlog_items** (data, required): Current product backlog items available for sprint selection.
- **previous_sprint_data** (data, optional): Historical sprint data for estimation calibration.

## Execution

1. Review and pre-fill the sprint backlog with candidate items

```ai
Review the following backlog items and recommend which should be considered for the upcoming sprint:

{{backlog_items}}

Project context: {{project_context}}

Consider:
- Business value and strategic alignment
- Dependencies between items
- Team capacity and historical velocity from {{previous_sprint_data}}
- Risk of carrying items forward

Produce a prioritized list of recommended sprint candidates with rationale for each inclusion.
```

2. Generate effort estimations for each candidate item

```ai
For each of the following sprint candidate items, suggest an effort estimation:

{{backlog_items}}

Historical data: {{previous_sprint_data}}

Use historical completion data to calibrate estimates. For each item provide:
- Estimated effort (story points or time-based, matching team convention)
- Confidence level (high / medium / low)
- Comparable completed items that informed the estimate
- Risks that could affect the estimate

Flag any items where estimation confidence is low and recommend discussion points for the team.
```

3. Define sprint goals and link tasks to objectives

```ai
Based on the prioritized backlog candidates and project context, draft sprint goals:

Project context: {{project_context}}
Selected items: {{backlog_items}}

For each proposed sprint goal:
- State the goal clearly and concisely
- List which backlog items contribute to this goal
- Identify how success will be measured
- Note any dependencies or risks to goal achievement

Produce a sprint objective document suitable for distribution to the team.
```

## Output

- **sprint_backlog** (data): The finalized set of backlog items selected for the sprint, each with effort estimates and goal associations.
- **sprint_goals** (text): A sprint objective document detailing goals, linked tasks, and success criteria.

### Output Format

```markdown
## Sprint Backlog
| Item | Priority | Estimate | Goal | Confidence |
|------|----------|----------|------|------------|
| ...  | ...      | ...      | ...  | ...        |

## Sprint Goals
### Goal 1: [Goal Name]
- Description: ...
- Success Criteria: ...
- Contributing Items: ...
```

## Routing

- next: ./daily-standups.md
- related: ./backlog-refinement.md
