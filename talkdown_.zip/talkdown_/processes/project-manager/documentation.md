---
type: step
title: "Documentation"
description: "Create, update, manage, and archive project documentation throughout the project lifecycle"
inputs:
  - name: project_context
    type: text
    required: true
    description: "Current project state and documentation needs"
  - name: existing_documents
    type: data
    required: false
    description: "Inventory of existing project documents with their status and last update dates"
  - name: document_request
    type: text
    required: false
    description: "Specific document creation or update request"
outputs:
  - name: document_inventory
    type: data
    description: "Updated inventory of all project documents with status, access settings, and review dates"
  - name: documents_produced
    type: data
    description: "New or updated documents generated during this step"
tags: [project-management, documentation]
---

# Documentation

Manage the full lifecycle of project documentation including creation of new documents, updating existing ones, managing access permissions, and archiving documents that are no longer active. Ensure the project maintains a healthy, current, and accessible documentation set.

## Context

Act as a documentation manager who ensures the project's knowledge base is complete, current, and accessible to those who need it. Maintain consistency in document structure and naming conventions. Proactively identify documentation gaps.

## Inputs

- **project_context** (text, required): Current project state and documentation needs.
- **existing_documents** (data, optional): Inventory of existing project documents.
- **document_request** (text, optional): Specific document to create or update.

## Execution

1. Assess the current documentation landscape and identify gaps

```ai
Review the current project documentation inventory:

Project context: {{project_context}}
Existing documents: {{existing_documents}}

Identify:
- Documents that are missing but expected for this project phase
- Documents that are outdated and need revision
- Documents with unclear ownership or access settings
- Documents that should be archived (no longer active or relevant)

Produce a documentation health report with recommended actions.
```

2. Create or update documents as needed

```ai
Based on the documentation assessment and any specific requests:

Document request: {{document_request}}
Project context: {{project_context}}

For each document to create or update:
- Define the document type, purpose, and intended audience
- Draft the content using the project's standard document templates
- Set appropriate access permissions (who can view, edit, comment)
- Assign a document owner responsible for keeping it current
- Set a review date for the next scheduled update

Produce the document content and metadata.
```

3. Manage document access and archival

```ai
Review document access settings and archival status:

Existing documents: {{existing_documents}}

For documents flagged for archival:
- Confirm they are no longer needed for active reference
- Ensure they are preserved in the project archive
- Update any links or references that pointed to archived documents

For active documents:
- Verify access settings match current team composition
- Ensure new team members have appropriate access
- Flag any documents with overly broad or narrow access
```

## Output

- **document_inventory** (data): Updated inventory of all project documents.
- **documents_produced** (data): New or updated documents.

### Output Format

```markdown
## Documentation Report

### Document Inventory
| Document | Type | Owner | Status | Last Updated | Next Review |
|----------|------|-------|--------|--------------|-------------|
| ...      | ...  | ...   | ...    | ...          | ...         |

### Gaps Identified
| Missing Document | Priority | Recommended Owner |
|------------------|----------|-------------------|
| ...              | ...      | ...               |

### Archival Actions
| Document | Action | Reason |
|----------|--------|--------|
| ...      | ...    | ...    |
```

## Routing

- related: ./communication.md
- related: ./reporting.md
