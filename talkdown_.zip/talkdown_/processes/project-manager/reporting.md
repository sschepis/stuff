---
type: step
title: "Project Reporting"
description: "Generate and distribute project status updates including sprint summaries, resource utilization, and overall progress"
inputs:
  - name: project_context
    type: text
    required: true
    description: "Current project state for generating updates"
  - name: report_type
    type: text
    required: false
    description: "Type of update to generate (sprint, resource-utilization, progress, or all)"
  - name: sprint_data
    type: data
    required: false
    description: "Sprint-specific data for sprint updates"
  - name: resource_data
    type: data
    required: false
    description: "Resource allocation and utilization data"
  - name: distribution_list
    type: data
    required: false
    description: "Recipients for distribution with their preferences"
outputs:
  - name: generated_updates
    type: data
    description: "Generated status updates in the requested formats"
  - name: distribution_log
    type: data
    description: "Record of update distribution"
tags: [project-management, reporting]
---

# Project Reporting

Generate comprehensive project status updates covering sprint performance, resource utilization, and overall project progress. Distribute updates to stakeholders according to their preferences and schedules.

## Context

Act as a project analyst who transforms raw project data into clear, actionable insights. Updates should tell a story: what happened, why it matters, and what should be done about it. Tailor detail level and format to the audience.

## Inputs

- **project_context** (text, required): Current project state for context.
- **report_type** (text, optional): Type of update to generate. Defaults to all.
- **sprint_data** (data, optional): Sprint data for sprint-specific updates.
- **resource_data** (data, optional): Resource data for utilization analysis.
- **distribution_list** (data, optional): Recipients and their preferences.

## Execution

1. Generate sprint performance updates

```ai
Create a sprint performance update:

Project context: {{project_context}}
Sprint data: {{sprint_data}}

Include:
- Sprint goal achievement (goals set vs. goals met)
- Velocity trend (current sprint vs. rolling average)
- Committed vs. completed items
- Carry-over items and reasons
- Quality metrics (defects found, test coverage)
- Team capacity utilization
- Key accomplishments and challenges

Present data clearly with trends and comparisons to previous sprints.
```

2. Generate resource utilization analysis

```ai
Create a resource utilization analysis:

Project context: {{project_context}}
Resource data: {{resource_data}}

Include:
- Team member allocation vs. actual utilization
- Over-allocated and under-allocated resources
- Skill coverage gaps
- Availability forecasts for upcoming sprints
- Recommendations for resource optimization

Highlight any resource risks that could impact project delivery.
```

3. Generate overall project progress update

```ai
Create a project progress update:

Project context: {{project_context}}

Include:
- Overall project health status (on track, at risk, off track)
- Milestone progress (completed, upcoming, overdue)
- Budget status (planned vs. actual spend)
- Scope changes since last update
- Key risks and their mitigation status
- Decisions needed from stakeholders
- Forecast for next period

Produce an executive summary suitable for stakeholder review.
```

4. Distribute updates to stakeholders

```ai
Prepare updates for distribution:

Distribution list: {{distribution_list}}

For each recipient:
- Select the appropriate update(s) based on their role and preferences
- Adjust detail level (executive summary vs. detailed)
- Schedule distribution according to the agreed cadence
- Log the distribution for project records
```

## Output

- **generated_updates** (data): Generated status updates.
- **distribution_log** (data): Record of distribution.

### Output Format

```markdown
## Sprint Performance
- Velocity: X points (trend: +/- Y%)
- Goal Achievement: X/Y goals met
- Completion Rate: X%

## Resource Utilization
- Average Utilization: X%
- Over-allocated: [names]
- Under-allocated: [names]

## Project Progress
- Health: [On Track / At Risk / Off Track]
- Budget: X% consumed, Y% timeline elapsed
- Next Milestone: [name] due [date]

## Distribution Log
| Update | Recipient | Date | Channel |
|--------|-----------|------|---------|
| ...    | ...       | ...  | ...     |
```

## Routing

- related: ./sprint-review.md
- related: ./communication.md
- related: ./stakeholder-management.md
