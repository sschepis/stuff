---
type: process
title: "Project Manager"
description: "Comprehensive project management capabilities spanning sprint lifecycle, communication, risk, quality, and stakeholder management"
inputs:
  - name: project_context
    type: text
    required: true
    description: "Overview of the project including goals, team composition, timeline, and current status"
  - name: management_area
    type: text
    required: false
    description: "Specific management area to focus on (e.g., sprint-planning, risk, reporting). If omitted, the full suite of capabilities is available."
outputs:
  - name: management_artifacts
    type: data
    description: "Plans, reports, action items, and recommendations produced by the invoked management steps"
tags: [project-management, agile, process-orchestration]
---

# Project Manager

A modular project management process that provides a comprehensive set of capabilities for managing agile projects. Unlike a linear pipeline, this process is organized as a collection of related steps that can be invoked individually or in combination depending on current project needs.

## Step Inventory

### Sprint Lifecycle

Steps that support the iterative sprint cycle from planning through retrospective.

| Step | File | Description |
|------|------|-------------|
| Sprint Planning | [sprint-planning.md](./sprint-planning.md) | Backlog pre-filling, estimation, and sprint goal setup |
| Daily Standups | [daily-standups.md](./daily-standups.md) | Status collection, aggregation, and standup summary distribution |
| Sprint Review | [sprint-review.md](./sprint-review.md) | Work item aggregation, review meeting prep, and agenda distribution |
| Sprint Retrospective | [sprint-retrospective.md](./sprint-retrospective.md) | Feedback collection, insight compilation, and action item creation |
| Backlog Refinement | [backlog-refinement.md](./backlog-refinement.md) | Prioritization, outdated item cleanup, redundancy detection, and efficiency optimization |

### Task and Issue Management

Steps for tracking work items and managing project dependencies.

| Step | File | Description |
|------|------|-------------|
| Issue and Task Flow | [issue-task-flow.md](./issue-task-flow.md) | Work item creation, status synchronization, and notification management |
| Dependencies | [dependencies.md](./dependencies.md) | Dependency tracking, status updates, and stakeholder notification |

### Communication and Reporting

Steps for project communication, documentation, and status reporting.

| Step | File | Description |
|------|------|-------------|
| Communication | [communication.md](./communication.md) | Notification delivery, communication facilitation, and schedule planning |
| Reporting | [reporting.md](./reporting.md) | Sprint reports, resource utilization reports, and progress reports |
| Documentation | [documentation.md](./documentation.md) | Document creation, updates, access management, and archival |

### Risk and Quality

Steps for identifying and managing risks and maintaining quality standards.

| Step | File | Description |
|------|------|-------------|
| Risk Management | [risk-management.md](./risk-management.md) | Risk identification, assessment, classification, mitigation, and notification |
| Quality Management | [quality-management.md](./quality-management.md) | Quality standards definition, assurance activities, and quality control |

### Resources and Procurement

Steps for resource planning and procurement management.

| Step | File | Description |
|------|------|-------------|
| Resource Forecasting | [resource-forecasting.md](./resource-forecasting.md) | Historical analysis, resource prediction, and sprint resource planning |
| Procurement | [procurement.md](./procurement.md) | Procurement planning, execution, and control |

### Stakeholder Management

| Step | File | Description |
|------|------|-------------|
| Stakeholder Management | [stakeholder-management.md](./stakeholder-management.md) | Stakeholder identification, engagement planning, and engagement control |

## Flow

This process is non-linear. Steps are invoked based on the current phase and needs of the project:

```
                    +---------------------------+
                    |      Project Context      |
                    +---------------------------+
                               |
          +--------------------+--------------------+
          |                    |                    |
          v                    v                    v
   Sprint Lifecycle    Task Management    Communication
   +---------------+  +---------------+  +---------------+
   | Planning       |  | Issue/Task    |  | Communication |
   | Daily Standups |  |   Flow        |  | Reporting     |
   | Review         |  | Dependencies  |  | Documentation |
   | Retrospective  |  +---------------+  +---------------+
   | Backlog        |
   |   Refinement   |         |                    |
   +---------------+          |                    |
          |                   v                    v
          |            Risk & Quality      Resources & Procurement
          |            +---------------+   +-------------------+
          |            | Risk Mgmt     |   | Resource Forecast |
          |            | Quality Mgmt  |   | Procurement       |
          |            +---------------+   +-------------------+
          |                   |                    |
          +-------------------+--------------------+
                              |
                              v
                   Stakeholder Management
                   +---------------------+
                   | Stakeholder Mgmt    |
                   +---------------------+
```

### Common Invocation Patterns

- **Sprint start**: sprint-planning -> backlog-refinement -> resource-forecasting
- **Daily operations**: daily-standups -> issue-task-flow -> communication
- **Sprint end**: sprint-review -> sprint-retrospective -> reporting
- **Ongoing governance**: risk-management -> quality-management -> stakeholder-management
- **Ad hoc**: Any step can be invoked independently when the situation demands it

## Routing

- default: Evaluate {{management_area}} and route to the appropriate step file, or present the full inventory for selection.
