---
type: step
title: "Communication"
description: "Plan and manage project communications including notifications, team facilitation, and channel management"
inputs:
  - name: project_context
    type: text
    required: true
    description: "Current project state and communication needs"
  - name: stakeholders
    type: data
    required: true
    description: "List of stakeholders with their communication preferences and roles"
  - name: communication_plan
    type: data
    required: false
    description: "Existing communication plan to update or execute against"
outputs:
  - name: updated_communication_plan
    type: data
    description: "Revised communication plan with schedules, channels, and recipient lists"
  - name: communications_log
    type: data
    description: "Record of communications sent and their outcomes"
tags: [project-management, communication]
---

# Communication

Plan and execute project communications to ensure all stakeholders receive timely, relevant information through appropriate channels. Manage communication schedules, facilitate cross-team dialogue, and maintain communication channel health.

## Context

Act as a communication coordinator who ensures the right information reaches the right people at the right time. Balance the need for transparency with the risk of information overload. Tailor communication style and detail level to the audience.

## Inputs

- **project_context** (text, required): Current project state and communication needs.
- **stakeholders** (data, required): Stakeholders with their communication preferences and roles.
- **communication_plan** (data, optional): Existing communication plan to build upon.

## Execution

1. Assess current communication needs and plan updates

```ai
Review the current project communication landscape:

Project context: {{project_context}}
Stakeholders: {{stakeholders}}
Existing plan: {{communication_plan}}

Assess:
- Are all stakeholders receiving the information they need?
- Are there communication gaps (stakeholders not reached, topics not covered)?
- Are there communication redundancies (duplicate messages, overlapping channels)?
- What upcoming project events or milestones require communication?

Produce an updated communication plan with schedules, channels, recipients, and message types.
```

2. Facilitate team communication and manage channels

```ai
Based on the communication plan and current project needs:

Stakeholders: {{stakeholders}}
Project context: {{project_context}}

Identify:
- Cross-team communication needs (dependencies, shared resources, integration points)
- Channel effectiveness (are the current channels working? should any be added or retired?)
- Communication cadence adjustments needed
- Upcoming communications to prepare and schedule

Produce a list of communication actions to take, including drafts for scheduled communications.
```

3. Execute planned communications and log outcomes

```ai
Prepare the following scheduled communications for distribution:

Communication plan: {{communication_plan}}
Project context: {{project_context}}

For each communication:
- Draft the message content tailored to the audience
- Specify the delivery channel and timing
- Note any follow-up actions expected from recipients
- Log the communication for project records
```

## Output

- **updated_communication_plan** (data): The revised communication schedule and strategy.
- **communications_log** (data): Record of communications prepared or sent.

### Output Format

```markdown
## Communication Plan

### Scheduled Communications
| Date | Audience | Topic | Channel | Owner |
|------|----------|-------|---------|-------|
| ...  | ...      | ...   | ...     | ...   |

### Channel Health
| Channel | Purpose | Status | Recommendation |
|---------|---------|--------|----------------|
| ...     | ...     | ...    | ...            |

### Communications Log
| Date | Recipient | Topic | Channel | Status |
|------|-----------|-------|---------|--------|
| ...  | ...       | ...   | ...     | ...    |
```

## Routing

- related: ./reporting.md
- related: ./stakeholder-management.md
- related: ./daily-standups.md
