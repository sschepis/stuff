---
type: step
title: "Sprint Review"
description: "Prepare and facilitate sprint review meetings by aggregating completed work, generating summaries, and distributing agendas"
inputs:
  - name: sprint_id
    type: text
    required: true
    description: "Identifier for the sprint being reviewed"
  - name: sprint_goals
    type: text
    required: true
    description: "The goals that were set at the beginning of the sprint"
  - name: completed_work_items
    type: data
    required: true
    description: "List of work items completed during the sprint"
  - name: stakeholders
    type: data
    required: false
    description: "List of stakeholders to invite and distribute materials to"
outputs:
  - name: sprint_review_package
    type: data
    description: "Complete sprint review package including summary report, meeting agenda, and distribution materials"
tags: [project-management, sprint, review]
---

# Sprint Review

Prepare for the sprint review meeting by aggregating all completed work items, generating a summary of accomplishments against sprint goals, creating a structured meeting agenda, and distributing materials to the team and stakeholders.

## Context

Act as a sprint review facilitator focused on demonstrating value delivered during the sprint. Ensure the review connects completed work to sprint goals and product strategy, and provides clear visibility to stakeholders.

## Inputs

- **sprint_id** (text, required): Identifier for the sprint under review.
- **sprint_goals** (text, required): The goals set at sprint start.
- **completed_work_items** (data, required): Work items completed during the sprint.
- **stakeholders** (data, optional): Stakeholders to invite and distribute materials to.

## Execution

1. Aggregate and summarize completed work items

```ai
Review the following completed work items for sprint {{sprint_id}}:

{{completed_work_items}}

Original sprint goals:
{{sprint_goals}}

Produce a sprint accomplishment summary that:
- Groups completed items by sprint goal
- Highlights items completed beyond the original commitment
- Notes any committed items that were not completed, with reasons
- Calculates completion percentage against sprint goals
- Identifies key deliverables and their business impact
```

2. Generate the sprint review meeting agenda

```ai
Create a sprint review meeting agenda for sprint {{sprint_id}}:

Sprint goals: {{sprint_goals}}
Completed work summary: {{completed_work_items}}
Stakeholders: {{stakeholders}}

The agenda should include:
- Welcome and sprint overview (goals recap)
- Demonstration of completed work (ordered by business impact)
- Metrics review (velocity, goal completion, quality)
- Items not completed and carry-forward plan
- Stakeholder feedback and Q&A time
- Next sprint preview

Allocate time estimates for each agenda section.
```

3. Prepare distribution materials and schedule the review meeting

```ai
Prepare a sprint review communication package for distribution:

Sprint: {{sprint_id}}
Stakeholders: {{stakeholders}}

Include:
- Meeting invitation details (purpose, expected duration, preparation needed)
- Pre-read summary of sprint accomplishments
- Agenda with time allocations
- Any demo prerequisites or setup instructions
```

## Output

- **sprint_review_package** (data): Complete sprint review package with summary, agenda, and distribution materials.

### Output Format

```markdown
## Sprint Review Package - Sprint {{sprint_id}}

### Accomplishment Summary
| Goal | Items Committed | Items Completed | Status |
|------|-----------------|-----------------|--------|
| ...  | ...             | ...             | ...    |

### Meeting Agenda
1. [Time] Welcome and Sprint Overview
2. [Time] Work Demonstrations
3. [Time] Metrics Review
4. [Time] Incomplete Items Discussion
5. [Time] Stakeholder Feedback
6. [Time] Next Sprint Preview

### Distribution List
- ...
```

## Routing

- next: ./sprint-retrospective.md
- related: ./reporting.md
