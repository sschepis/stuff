---
type: step
title: "Backlog Refinement"
description: "Refine the product backlog through prioritization, outdated item cleanup, redundancy detection, and efficiency optimization"
inputs:
  - name: backlog_items
    type: data
    required: true
    description: "Current product backlog items to be refined"
  - name: prioritization_criteria
    type: text
    required: false
    description: "Criteria for prioritization (e.g., business value, urgency, dependencies, risk)"
  - name: historical_data
    type: data
    required: false
    description: "Historical sprint and completion data for efficiency optimization"
outputs:
  - name: refined_backlog
    type: data
    description: "The refined and reordered backlog with prioritization, cleanup, and optimization applied"
  - name: refinement_report
    type: text
    description: "Report detailing changes made during refinement including removed, merged, and reprioritized items"
tags: [project-management, backlog, refinement]
---

# Backlog Refinement

Systematically refine the product backlog by prioritizing items against defined criteria, identifying and removing outdated entries, detecting and consolidating redundant items, and optimizing ordering for team efficiency.

## Context

Act as a product backlog steward who ensures the backlog remains a healthy, actionable, and well-ordered artifact. Balance business value against technical feasibility and team capacity. Surface items that need stakeholder decisions.

## Inputs

- **backlog_items** (data, required): Current product backlog items to be refined.
- **prioritization_criteria** (text, optional): Criteria for prioritization. Defaults to business value, urgency, and dependencies.
- **historical_data** (data, optional): Historical sprint data for calibrating efficiency recommendations.

## Execution

1. Prioritize backlog items against defined criteria

```ai
Prioritize the following backlog items:

{{backlog_items}}

Prioritization criteria: {{prioritization_criteria}}

For each item, evaluate against the criteria and assign a priority rank. Consider:
- Business value and strategic alignment
- Urgency and time sensitivity
- Technical dependencies and prerequisite relationships
- Risk of delay or deferral
- Effort required relative to value delivered

Produce a ranked list with justification for the top and bottom quartile placements.
```

2. Identify and flag outdated or irrelevant items

```ai
Review the following backlog items for relevance and currency:

{{backlog_items}}

Flag items that may be outdated or no longer relevant based on:
- Age of the item (when was it last updated or discussed?)
- Alignment with current project goals and strategy
- Whether the underlying need has been addressed by other work
- Whether external conditions have changed making the item moot

For each flagged item, recommend: keep, archive, or remove, with rationale. Items recommended for removal should be surfaced to stakeholders for confirmation.
```

3. Detect and consolidate redundant items

```ai
Scan the following backlog items for redundancy and duplication:

{{backlog_items}}

Identify:
- Exact or near-duplicate items
- Items that overlap significantly in scope
- Items that could be merged into a single, better-defined item

For each redundancy found, propose a consolidation plan:
- Which items to merge
- Suggested combined description
- How to preserve any unique details from each original item
```

4. Optimize backlog ordering for team efficiency

```ai
Recommend an efficiency-optimized ordering for the backlog:

{{backlog_items}}

Historical data: {{historical_data}}

Consider:
- Dependency chains (items that unblock others should come first)
- Team velocity patterns and capacity
- Context-switching costs (group related items together)
- Risk mitigation (address high-risk items earlier)
- Quick wins that build momentum

Produce a recommended ordering with rationale for significant position changes.
```

## Output

- **refined_backlog** (data): The refined backlog with updated priorities, merged items, and optimized ordering.
- **refinement_report** (text): Summary of all refinement actions taken.

### Output Format

```markdown
## Backlog Refinement Report

### Prioritization Changes
| Item | Previous Priority | New Priority | Rationale |
|------|-------------------|--------------|-----------|
| ...  | ...               | ...          | ...       |

### Outdated Items Flagged
| Item | Recommendation | Rationale |
|------|----------------|-----------|
| ...  | ...            | ...       |

### Redundancies Resolved
| Merged Items | Combined Item | Details Preserved |
|--------------|---------------|-------------------|
| ...          | ...           | ...               |

### Optimized Ordering
1. [Item] - [Rationale for position]
2. ...
```

## Routing

- next: ./sprint-planning.md
- related: ./issue-task-flow.md
- related: ./resource-forecasting.md
