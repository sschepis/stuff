---
type: step
title: "Issue and Task Flow"
description: "Manage the lifecycle of work items from creation through completion, including status synchronization and notifications"
inputs:
  - name: incoming_communications
    type: data
    required: false
    description: "Messages, emails, or requests that may contain new tasks or status updates"
  - name: current_work_items
    type: data
    required: true
    description: "Current set of active work items and their statuses"
  - name: notification_preferences
    type: data
    required: false
    description: "Stakeholder notification preferences and subscription settings"
outputs:
  - name: updated_work_items
    type: data
    description: "Work items with updated statuses, new items created, and modifications applied"
  - name: notifications_sent
    type: data
    description: "Log of notifications dispatched to stakeholders"
tags: [project-management, task-management, workflow]
---

# Issue and Task Flow

Manage the full lifecycle of issues and tasks from creation through completion. Monitor communications for new work items and status updates, synchronize task statuses with the project board, and ensure stakeholders receive timely notifications about changes.

## Context

Act as a task flow coordinator who ensures no work items fall through the cracks. Monitor incoming communications for implicit or explicit task requests, keep the project board in sync with actual progress, and proactively notify stakeholders of meaningful status changes.

## Inputs

- **incoming_communications** (data, optional): Messages or requests that may contain new tasks or status updates.
- **current_work_items** (data, required): Active work items and their current statuses.
- **notification_preferences** (data, optional): How and when stakeholders want to be notified.

## Execution

1. Monitor communications and extract new work items

```ai
Review the following incoming communications for task-related content:

{{incoming_communications}}

For each communication, determine:
- Does it describe a new task or issue? If so, extract title, description, priority, and assignee.
- Does it contain a status update for an existing item? If so, identify the item and the new status.
- Does it contain a change request (reassignment, priority change, scope change)? If so, capture the details.

Produce a structured list of actions to take: create, update, or modify work items.
```

2. Create new work items and update existing ones

```ai
Process the following work item actions against the current board:

Current work items: {{current_work_items}}
Actions to process: [extracted from step 1]

For each action:
- New items: Assign a unique identifier, set initial status, link to related items if applicable
- Status updates: Validate the transition is valid, update the item, note the change
- Modifications: Apply changes and document what was modified and why

Produce the updated work item set with a change log.
```

3. Synchronize task statuses and send notifications

```ai
Review the following work item changes and determine which notifications to send:

Updated items: {{current_work_items}}
Notification preferences: {{notification_preferences}}

For each change:
- Identify who needs to be notified (assignee, reporter, watchers, stakeholders)
- Compose a clear, concise notification message
- Respect notification preferences (frequency, channel, severity threshold)

Produce a notification dispatch list with recipients and messages.
```

## Output

- **updated_work_items** (data): Complete set of work items with all changes applied.
- **notifications_sent** (data): Log of all notifications dispatched.

### Output Format

```markdown
## Work Item Updates

### New Items Created
| ID | Title | Priority | Assignee | Source |
|----|-------|----------|----------|--------|
| ...| ...   | ...      | ...      | ...    |

### Status Changes
| ID | Title | Previous Status | New Status | Reason |
|----|-------|-----------------|------------|--------|
| ...| ...   | ...             | ...        | ...    |

### Notifications Sent
| Recipient | Subject | Channel |
|-----------|---------|---------|
| ...       | ...     | ...     |
```

## Routing

- next: ./communication.md
- related: ./daily-standups.md
- related: ./dependencies.md
