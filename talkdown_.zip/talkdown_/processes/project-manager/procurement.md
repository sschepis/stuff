---
type: step
title: "Procurement"
description: "Plan, execute, and control project procurement activities including vendor management and contract oversight"
inputs:
  - name: project_context
    type: text
    required: true
    description: "Current project state including budget, timeline, and resource needs"
  - name: procurement_needs
    type: data
    required: true
    description: "List of goods, services, or resources that need to be procured"
  - name: existing_contracts
    type: data
    required: false
    description: "Current active contracts and vendor relationships"
outputs:
  - name: procurement_plan
    type: data
    description: "Updated procurement plan with timelines, vendors, and budget allocations"
  - name: procurement_status
    type: data
    description: "Status report on active and planned procurement activities"
tags: [project-management, procurement]
---

# Procurement

Plan and manage project procurement activities including identifying procurement needs, evaluating options, managing vendor relationships, and controlling procurement execution against budget and timeline constraints.

## Context

Act as a procurement coordinator who ensures the project obtains the goods, services, and resources it needs on time and within budget. Balance cost, quality, and delivery speed. Maintain clear records of all procurement decisions and contracts.

## Inputs

- **project_context** (text, required): Current project state including budget and timeline.
- **procurement_needs** (data, required): Goods, services, or resources to be procured.
- **existing_contracts** (data, optional): Active contracts and vendor relationships.

## Execution

1. Develop or update the procurement plan

```ai
Review the project's procurement needs and develop a procurement plan:

Project context: {{project_context}}
Procurement needs: {{procurement_needs}}
Existing contracts: {{existing_contracts}}

For each procurement need:
- Specify what is being procured and why
- Define evaluation criteria (cost, quality, delivery time, reliability)
- Identify potential vendors or sources
- Estimate budget and timeline
- Determine the procurement method (competitive bid, sole source, framework agreement)
- Identify risks and mitigation strategies

Produce a structured procurement plan with priorities and timelines.
```

2. Execute procurement activities and manage vendors

```ai
For active procurement items, manage the execution:

Procurement needs: {{procurement_needs}}
Existing contracts: {{existing_contracts}}

Track:
- Status of each procurement activity (planning, solicitation, evaluation, contracting, delivery)
- Vendor performance against contract terms
- Budget expenditure vs. planned allocation
- Delivery timeline adherence
- Quality of goods or services received

Flag any procurement items that are behind schedule, over budget, or not meeting quality standards.
```

3. Control procurement and manage contract compliance

```ai
Review active contracts and procurement activities for compliance:

Existing contracts: {{existing_contracts}}
Project context: {{project_context}}

For each active contract:
- Verify deliverables are being met according to schedule
- Check budget consumption against projections
- Assess vendor relationship health
- Identify contracts approaching renewal or expiration
- Note any contract modifications needed

Produce a procurement control report with recommended actions.
```

## Output

- **procurement_plan** (data): Updated procurement plan with priorities and timelines.
- **procurement_status** (data): Status of all active and planned procurement activities.

### Output Format

```markdown
## Procurement Report

### Procurement Plan
| Item | Vendor | Budget | Timeline | Status | Method |
|------|--------|--------|----------|--------|--------|
| ...  | ...    | ...    | ...      | ...    | ...    |

### Active Contracts
| Contract | Vendor | Value | Expiry | Performance | Issues |
|----------|--------|-------|--------|-------------|--------|
| ...      | ...    | ...   | ...    | ...         | ...    |

### Budget Summary
- Total Procurement Budget: ...
- Committed: ...
- Spent: ...
- Remaining: ...
```

## Routing

- related: ./resource-forecasting.md
- related: ./risk-management.md
