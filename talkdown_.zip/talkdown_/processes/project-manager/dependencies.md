---
type: step
title: "Dependencies"
description: "Track and manage project dependencies including status monitoring, impact analysis, and stakeholder notification"
inputs:
  - name: project_dependencies
    type: data
    required: true
    description: "List of project dependencies with their current status, owners, and expected delivery dates"
  - name: project_plan
    type: data
    required: false
    description: "Overall project plan for assessing dependency impact on timelines"
outputs:
  - name: dependency_status_report
    type: data
    description: "Updated dependency status report with risk assessments and recommended actions"
  - name: dependency_notifications
    type: data
    description: "Notifications generated for dependency status changes"
tags: [project-management, dependencies]
---

# Dependencies

Track and manage all project dependencies to prevent bottlenecks and delays. Monitor dependency status, analyze the impact of changes on the project timeline, and proactively notify stakeholders when dependencies are at risk.

## Context

Act as a dependency tracker who maintains visibility across all project dependencies, both internal and external. Proactively identify risks before they become blockers and ensure responsible parties are aware of their obligations and timelines.

## Inputs

- **project_dependencies** (data, required): Current dependencies with status, owners, and expected delivery dates.
- **project_plan** (data, optional): Overall project plan for timeline impact analysis.

## Execution

1. Review and update the status of all project dependencies

```ai
Review the following project dependencies and assess their current status:

{{project_dependencies}}

For each dependency:
- Verify the current status (on track, at risk, blocked, completed)
- Check if the expected delivery date is still realistic
- Identify any new information that affects the dependency
- Note any dependencies that have been resolved since the last review

Produce an updated dependency register with current statuses.
```

2. Analyze the impact of dependency changes on the project

```ai
Analyze the impact of dependency status changes on the project:

Dependencies: {{project_dependencies}}
Project plan: {{project_plan}}

For each at-risk or blocked dependency:
- What project tasks or milestones are affected?
- What is the potential delay if the dependency is not resolved?
- Are there alternative approaches or workarounds?
- What escalation path should be followed?

Produce an impact analysis with recommended mitigation actions.
```

3. Generate and distribute dependency status notifications

```ai
Based on the dependency status review, determine which notifications need to be sent:

Dependencies: {{project_dependencies}}

For each dependency with a status change or approaching deadline:
- Identify the stakeholders who need to be informed
- Compose a notification with the dependency status, impact, and any required actions
- Prioritize notifications by severity (blocked > at risk > informational)

Produce a notification list with recipients and messages.
```

## Output

- **dependency_status_report** (data): Updated dependency register with statuses, impact analysis, and recommended actions.
- **dependency_notifications** (data): Notifications to be sent regarding dependency changes.

### Output Format

```markdown
## Dependency Status Report

### Dependency Register
| Dependency | Owner | Status | Due Date | Impact if Late | Mitigation |
|------------|-------|--------|----------|----------------|------------|
| ...        | ...   | ...    | ...      | ...            | ...        |

### At-Risk Dependencies
| Dependency | Risk Level | Affected Tasks | Recommended Action |
|------------|------------|----------------|--------------------|
| ...        | ...        | ...            | ...                |

### Notifications
| Recipient | Dependency | Message | Priority |
|-----------|------------|---------|----------|
| ...       | ...        | ...     | ...      |
```

## Routing

- related: ./risk-management.md
- related: ./issue-task-flow.md
- related: ./reporting.md
