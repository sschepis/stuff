---
type: step
title: "Risk Management"
description: "Identify, assess, classify, mitigate, and monitor project risks using data-driven analysis and proactive notification"
inputs:
  - name: project_context
    type: text
    required: true
    description: "Current project state including timeline, scope, and known constraints"
  - name: project_data
    type: data
    required: false
    description: "Project analytics data for risk identification (velocity trends, burndown, quality metrics)"
  - name: known_risks
    type: data
    required: false
    description: "Previously identified risks and their current status"
  - name: stakeholders
    type: data
    required: false
    description: "Stakeholders to notify about risk changes"
outputs:
  - name: risk_register
    type: data
    description: "Updated risk register with all identified risks, assessments, classifications, and mitigation plans"
  - name: risk_notifications
    type: data
    description: "Notifications generated for new or changed risks"
tags: [project-management, risk]
---

# Risk Management

Comprehensively manage project risks through continuous identification using project analytics, systematic assessment and classification, proactive mitigation planning, and timely stakeholder notification. This step combines risk discovery, analysis, response planning, and monitoring into a unified workflow.

## Context

Act as a risk manager who proactively identifies threats before they become issues. Use both qualitative judgment and quantitative project data to assess risks. Ensure every significant risk has an owner, a mitigation strategy, and a monitoring plan. Communicate risks clearly without causing unnecessary alarm.

## Inputs

- **project_context** (text, required): Current project state including timeline, scope, and constraints.
- **project_data** (data, optional): Project analytics for data-driven risk identification.
- **known_risks** (data, optional): Previously identified risks and their status.
- **stakeholders** (data, optional): Stakeholders to notify about risk changes.

## Execution

1. Identify risks from project data and context analysis

```ai
Analyze the following project information to identify potential risks:

Project context: {{project_context}}
Project analytics data: {{project_data}}
Known risks: {{known_risks}}

Look for risks across these categories:
- Schedule risks (velocity trends, milestone proximity, dependency delays)
- Scope risks (requirements changes, feature creep, unclear acceptance criteria)
- Resource risks (team capacity, skill gaps, key person dependencies)
- Technical risks (architecture decisions, integration complexity, technical debt)
- External risks (vendor dependencies, regulatory changes, market shifts)
- Budget risks (cost overruns, unplanned expenses, procurement delays)

For each newly identified risk, provide:
- Clear description of the risk event
- Category classification
- Trigger conditions (what would cause this risk to materialize)
- Early warning indicators to monitor
```

2. Assess and classify identified risks

```ai
Assess each identified risk for impact and likelihood:

Known risks: {{known_risks}}
Newly identified risks: [from step 1]

For each risk:
- Likelihood: rate as very low / low / medium / high / very high
- Impact: rate as negligible / minor / moderate / major / critical
- Overall risk score (likelihood x impact matrix)
- Urgency: how soon could this risk materialize?
- Proximity: how close is the risk to materializing based on current indicators?

Classify risks into priority tiers:
- Critical: immediate action required
- High: action plan needed this sprint
- Medium: monitor and prepare contingency
- Low: accept and monitor periodically

Produce an updated risk register sorted by priority.
```

3. Develop mitigation strategies for high-priority risks

```ai
For each critical and high-priority risk, develop a mitigation strategy:

Risk register: {{known_risks}}

For each risk requiring action:
- Recommended response strategy (avoid, mitigate, transfer, or accept)
- Specific mitigation actions with owners and deadlines
- Contingency plan if the risk materializes despite mitigation
- Residual risk after mitigation is applied
- Cost of mitigation vs. cost of risk materialization
- Monitoring approach (what to watch, how often, who watches)

Ensure every critical risk has an assigned owner and a concrete next action.
```

4. Generate risk notifications for stakeholders

```ai
Based on the updated risk register, determine which notifications to send:

Risk register: {{known_risks}}
Stakeholders: {{stakeholders}}

Generate notifications for:
- Newly identified critical or high risks
- Risks that have changed status (escalated, de-escalated, materialized, closed)
- Risks approaching their trigger conditions
- Mitigation actions that are overdue

For each notification:
- Identify the appropriate recipients based on risk ownership and impact
- Compose a clear message with the risk, its current status, and any required actions
- Set appropriate urgency level

Produce a notification dispatch list.
```

## Output

- **risk_register** (data): Complete risk register with assessments, classifications, and mitigation plans.
- **risk_notifications** (data): Notifications to send regarding risk changes.

### Output Format

```markdown
## Risk Register

### Critical Risks
| Risk | Category | Likelihood | Impact | Owner | Mitigation | Status |
|------|----------|------------|--------|-------|------------|--------|
| ...  | ...      | ...        | ...    | ...   | ...        | ...    |

### High Risks
| Risk | Category | Likelihood | Impact | Owner | Mitigation | Status |
|------|----------|------------|--------|-------|------------|--------|
| ...  | ...      | ...        | ...    | ...   | ...        | ...    |

### Medium and Low Risks
| Risk | Category | Score | Monitoring Approach |
|------|----------|-------|---------------------|
| ...  | ...      | ...   | ...                 |

### Risk Trend
- New risks this period: X
- Risks closed: X
- Risks escalated: X
- Overall risk posture: [Improving / Stable / Deteriorating]

### Notifications
| Recipient | Risk | Message | Urgency |
|-----------|------|---------|---------|
| ...       | ...  | ...     | ...     |
```

## Routing

- related: ./dependencies.md
- related: ./quality-management.md
- related: ./stakeholder-management.md
