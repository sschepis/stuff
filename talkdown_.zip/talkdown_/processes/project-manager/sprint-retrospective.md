---
type: step
title: "Sprint Retrospective"
description: "Facilitate sprint retrospectives by collecting feedback, compiling insights, and creating actionable improvement items"
inputs:
  - name: sprint_id
    type: text
    required: true
    description: "Identifier for the sprint being retrospected"
  - name: team_members
    type: data
    required: true
    description: "List of team members participating in the retrospective"
  - name: sprint_metrics
    type: data
    required: false
    description: "Sprint performance metrics (velocity, burndown, quality data)"
outputs:
  - name: retrospective_summary
    type: text
    description: "Compiled retrospective insights with categorized feedback"
  - name: action_items
    type: data
    description: "Actionable improvement items to be tracked in the next sprint"
tags: [project-management, sprint, retrospective]
---

# Sprint Retrospective

Facilitate an effective sprint retrospective by collecting structured feedback from team members, compiling and analyzing the feedback for patterns and insights, and producing actionable improvement items that can be tracked in subsequent sprints.

## Context

Act as a retrospective facilitator focused on continuous improvement. Create a psychologically safe environment for honest feedback. Look for systemic patterns rather than individual blame, and ensure action items are specific, measurable, and assigned.

## Inputs

- **team_members** (data, required): Team members participating in the retrospective.
- **sprint_id** (text, required): Identifier for the sprint being retrospected.
- **sprint_metrics** (data, optional): Sprint performance data to ground the discussion.

## Execution

1. Prepare and distribute the feedback collection form

```ai
Create a retrospective feedback form for sprint {{sprint_id}}:

Team members: {{team_members}}
Sprint metrics: {{sprint_metrics}}

The form should collect:
- What went well this sprint (keep doing)
- What did not go well (stop doing or change)
- What new practices should we try (start doing)
- Rate team collaboration (1-5 scale)
- Rate sprint planning accuracy (1-5 scale)
- Any specific shout-outs or acknowledgments
- Open comments

Distribute to all team members with a clear deadline for responses.
```

2. Compile and analyze the collected feedback

```ai
Analyze the following retrospective feedback from sprint {{sprint_id}}:

Team responses: {{team_members}}
Sprint metrics: {{sprint_metrics}}

Compile the feedback into:
- Categorized themes (process, tools, communication, technical, team dynamics)
- Frequency analysis (how many people raised each theme)
- Sentiment summary (overall team morale indicators)
- Comparison with previous retrospective action items (were they addressed?)
- Top 3-5 most impactful areas for improvement

Highlight patterns that appear across multiple team members.
```

3. Generate actionable improvement items

```ai
Based on the compiled retrospective insights for sprint {{sprint_id}}, create specific action items:

For each action item:
- Clear description of the improvement
- Owner responsible for driving it
- Definition of done (how we know it's addressed)
- Target sprint for completion
- Priority (high / medium / low)

Limit to 3-5 high-impact action items to avoid overloading the team. Ensure they are specific enough to track and measure.
```

## Output

- **retrospective_summary** (text): Categorized feedback insights with patterns and sentiment analysis.
- **action_items** (data): Specific improvement items with owners, deadlines, and success criteria.

### Output Format

```markdown
## Retrospective Summary - Sprint {{sprint_id}}

### What Went Well
- ...

### Areas for Improvement
- ...

### Action Items
| Action | Owner | Target Sprint | Priority | Done Criteria |
|--------|-------|---------------|----------|---------------|
| ...    | ...   | ...           | ...      | ...           |

### Team Sentiment
- Collaboration: X/5
- Planning Accuracy: X/5
- Overall Morale: [Assessment]
```

## Routing

- next: ./sprint-planning.md
- related: ./reporting.md
- related: ./quality-management.md
