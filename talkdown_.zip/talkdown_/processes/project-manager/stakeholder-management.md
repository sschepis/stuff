---
type: step
title: "Stakeholder Management"
description: "Identify stakeholders, plan engagement strategies, manage ongoing engagement, and monitor stakeholder satisfaction"
inputs:
  - name: project_context
    type: text
    required: true
    description: "Current project state and stakeholder landscape"
  - name: stakeholder_registry
    type: data
    required: false
    description: "Existing stakeholder registry with roles, interests, and engagement levels"
  - name: engagement_feedback
    type: data
    required: false
    description: "Feedback or signals about stakeholder satisfaction and engagement"
outputs:
  - name: updated_stakeholder_registry
    type: data
    description: "Updated stakeholder registry with engagement plans and status"
  - name: engagement_actions
    type: data
    description: "Specific engagement actions to take with stakeholders"
tags: [project-management, stakeholder]
---

# Stakeholder Management

Identify and categorize project stakeholders, develop tailored engagement strategies for each, manage ongoing engagement activities, and monitor stakeholder satisfaction to ensure project support and alignment.

## Context

Act as a stakeholder relationship manager who ensures all stakeholders are appropriately engaged based on their influence, interest, and needs. Balance proactive communication with respect for stakeholders' time. Anticipate stakeholder concerns before they become issues.

## Inputs

- **project_context** (text, required): Current project state and stakeholder landscape.
- **stakeholder_registry** (data, optional): Existing stakeholder registry.
- **engagement_feedback** (data, optional): Feedback about stakeholder satisfaction.

## Execution

1. Identify and categorize stakeholders

```ai
Review and update the stakeholder registry for the project:

Project context: {{project_context}}
Existing registry: {{stakeholder_registry}}

For each stakeholder (existing and newly identified):
- Name and role
- Level of influence on the project (high / medium / low)
- Level of interest in the project (high / medium / low)
- Key concerns and expectations
- Preferred communication style and frequency
- Relationship to other stakeholders

Categorize stakeholders using the influence-interest matrix:
- High influence, high interest: Manage closely
- High influence, low interest: Keep satisfied
- Low influence, high interest: Keep informed
- Low influence, low interest: Monitor

Produce an updated stakeholder registry.
```

2. Develop engagement strategies for each stakeholder category

```ai
Create engagement plans tailored to each stakeholder category:

Stakeholder registry: {{stakeholder_registry}}
Project context: {{project_context}}

For each stakeholder or stakeholder group:
- Communication frequency and channels
- Level of detail in communications
- Decision points where their input is needed
- Potential concerns to proactively address
- Relationship-building activities
- Escalation procedures

Ensure engagement plans align with the overall communication plan and project timeline.
```

3. Monitor and adjust stakeholder engagement

```ai
Assess the current state of stakeholder engagement and recommend adjustments:

Stakeholder registry: {{stakeholder_registry}}
Engagement feedback: {{engagement_feedback}}
Project context: {{project_context}}

Evaluate:
- Are stakeholders receiving the right level of engagement?
- Are there signs of disengagement or dissatisfaction?
- Have any stakeholders' influence or interest levels changed?
- Are there upcoming project events that require stakeholder preparation?
- Are there conflicts between stakeholder interests that need mediation?

Produce a list of engagement actions with priorities and owners.
```

## Output

- **updated_stakeholder_registry** (data): Updated registry with engagement plans and current status.
- **engagement_actions** (data): Specific actions to take with stakeholders.

### Output Format

```markdown
## Stakeholder Registry

### Stakeholder Map
| Stakeholder | Role | Influence | Interest | Category | Engagement Plan |
|-------------|------|-----------|----------|----------|-----------------|
| ...         | ...  | ...       | ...      | ...      | ...             |

### Engagement Actions
| Stakeholder | Action | Priority | Owner | Due Date |
|-------------|--------|----------|-------|----------|
| ...         | ...    | ...      | ...   | ...      |

### Engagement Health
| Stakeholder | Satisfaction | Trend | Notes |
|-------------|-------------|-------|-------|
| ...         | ...         | ...   | ...   |
```

## Routing

- related: ./communication.md
- related: ./risk-management.md
