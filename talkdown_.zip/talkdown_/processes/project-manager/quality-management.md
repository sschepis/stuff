---
type: step
title: "Quality Management"
description: "Define quality standards, conduct quality assurance activities, and perform quality control across project deliverables"
inputs:
  - name: project_context
    type: text
    required: true
    description: "Current project state including deliverables, standards, and quality requirements"
  - name: quality_standards
    type: data
    required: false
    description: "Existing quality standards and acceptance criteria for the project"
  - name: deliverables
    type: data
    required: false
    description: "Project deliverables to be assessed for quality"
outputs:
  - name: quality_plan
    type: data
    description: "Updated quality management plan with standards, metrics, and review schedules"
  - name: quality_report
    type: text
    description: "Quality assessment report covering assurance findings and control results"
tags: [project-management, quality]
---

# Quality Management

Establish and maintain project quality standards, conduct quality assurance activities to verify processes are being followed, and perform quality control on deliverables to ensure they meet acceptance criteria.

## Context

Act as a quality manager who ensures project deliverables meet defined standards and stakeholder expectations. Focus on both process quality (are we doing things right?) and product quality (is the output right?). Emphasize prevention over detection.

## Inputs

- **project_context** (text, required): Current project state and quality requirements.
- **quality_standards** (data, optional): Existing quality standards and acceptance criteria.
- **deliverables** (data, optional): Deliverables to assess for quality.

## Execution

1. Define or review quality standards and metrics

```ai
Review and update the quality standards for the project:

Project context: {{project_context}}
Existing standards: {{quality_standards}}

For each area of the project:
- Define measurable quality criteria and acceptance thresholds
- Identify key quality metrics to track
- Establish review cadence and responsibility
- Set escalation procedures for quality failures
- Ensure standards are realistic and aligned with project constraints

Produce an updated quality management plan.
```

2. Conduct quality assurance activities

```ai
Assess whether project processes are being followed and are effective:

Project context: {{project_context}}
Quality standards: {{quality_standards}}

Review:
- Are defined processes being followed consistently?
- Are there process gaps that could lead to quality issues?
- Are quality checkpoints being observed at key milestones?
- Are team members trained on quality expectations?
- What process improvements would prevent quality issues?

Produce a quality assurance findings report with recommendations.
```

3. Perform quality control on deliverables

```ai
Evaluate project deliverables against quality standards:

Deliverables: {{deliverables}}
Quality standards: {{quality_standards}}

For each deliverable:
- Does it meet the defined acceptance criteria?
- Are there defects, gaps, or areas below standard?
- What corrective actions are needed for non-conforming items?
- Are there trends in quality issues that suggest systemic problems?

Produce a quality control report with pass/fail status and corrective action recommendations.
```

## Output

- **quality_plan** (data): Updated quality management plan.
- **quality_report** (text): Quality assessment covering assurance and control findings.

### Output Format

```markdown
## Quality Management Report

### Quality Standards
| Area | Standard | Metric | Threshold | Status |
|------|----------|--------|-----------|--------|
| ...  | ...      | ...    | ...       | ...    |

### Assurance Findings
| Process | Compliance | Finding | Recommendation |
|---------|------------|---------|----------------|
| ...     | ...        | ...     | ...            |

### Control Results
| Deliverable | Criteria Met | Issues Found | Corrective Action |
|-------------|--------------|--------------|-------------------|
| ...         | ...          | ...          | ...               |
```

## Routing

- related: ./sprint-retrospective.md
- related: ./risk-management.md
- related: ./reporting.md
