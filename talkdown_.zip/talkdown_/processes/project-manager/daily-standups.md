---
type: step
title: "Daily Standups"
description: "Facilitate daily standup meetings by collecting status updates, aggregating them, and distributing summary reports"
inputs:
  - name: team_members
    type: data
    required: true
    description: "List of team members expected to provide status updates"
  - name: sprint_goals
    type: text
    required: false
    description: "Current sprint goals for contextualizing status updates"
outputs:
  - name: standup_summary
    type: text
    description: "Aggregated standup summary report with progress, blockers, and action items"
tags: [project-management, sprint, daily-standup]
---

# Daily Standups

Automate the daily standup process by collecting individual status updates from team members, aggregating them into a coherent summary, and distributing the report to the team and relevant stakeholders.

## Context

Act as a standup facilitator who ensures each team member's progress, plans, and blockers are captured and communicated. Focus on identifying blockers and cross-team dependencies that need attention.

## Inputs

- **team_members** (data, required): List of team members expected to provide status updates.
- **sprint_goals** (text, optional): Current sprint goals for contextualizing progress.

## Execution

1. Collect status updates from each team member

```ai
Prepare a status collection template for the following team members:

{{team_members}}

For each team member, gather:
- What they completed since the last standup
- What they plan to work on today
- Any blockers or impediments they are facing
- Any help or collaboration needed from others

Format as a structured collection form.
```

2. Aggregate and analyze the collected updates

```ai
Aggregate the following status updates into a unified standup summary:

Team updates: {{team_members}}
Sprint goals: {{sprint_goals}}

Identify:
- Overall sprint progress relative to goals
- Active blockers and who they affect
- Dependencies between team members' work
- Items at risk of not completing within the sprint
- Patterns (e.g., recurring blockers, workload imbalances)

Highlight any items requiring immediate attention or escalation.
```

3. Distribute the summary report to the team and stakeholders

## Output

- **standup_summary** (text): A formatted standup summary covering progress, blockers, and recommended actions.

### Output Format

```markdown
## Daily Standup Summary - [Date]

### Progress Highlights
- ...

### Active Blockers
| Blocker | Affected Member(s) | Severity | Suggested Action |
|---------|---------------------|----------|------------------|
| ...     | ...                 | ...      | ...              |

### Sprint Goal Progress
- Goal 1: [X]% complete
- Goal 2: [X]% complete

### Action Items
- [ ] ...
```

## Routing

- next: ./issue-task-flow.md
- related: ./sprint-planning.md
- related: ./communication.md
