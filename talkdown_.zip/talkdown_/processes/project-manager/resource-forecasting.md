---
type: step
title: "Resource Forecasting"
description: "Predict future resource needs using historical data and generate resource plans for upcoming sprints"
inputs:
  - name: historical_data
    type: data
    required: true
    description: "Historical project data including velocity, capacity utilization, and team composition over time"
  - name: upcoming_sprints
    type: data
    required: false
    description: "Planned upcoming sprints with their scope and goals"
  - name: current_team
    type: data
    required: false
    description: "Current team composition, skills, and availability"
outputs:
  - name: resource_forecast
    type: data
    description: "Predicted resource needs for upcoming sprints with recommendations"
  - name: resource_plan
    type: data
    description: "Actionable resource allocation plan for the next sprint cycle"
tags: [project-management, resource-planning, forecasting]
---

# Resource Forecasting

Analyze historical project data to predict future resource needs, identify potential capacity gaps, and generate actionable resource plans for upcoming sprints. Enable proactive resource management rather than reactive scrambling.

## Context

Act as a resource planning analyst who uses data-driven forecasting to anticipate resource needs. Balance historical trends with known upcoming changes (team changes, holidays, scope shifts). Provide actionable recommendations that project managers can act on before capacity issues arise.

## Inputs

- **historical_data** (data, required): Historical project data including velocity, capacity, and team metrics.
- **upcoming_sprints** (data, optional): Planned sprints with scope and goals.
- **current_team** (data, optional): Current team composition, skills, and availability.

## Execution

1. Analyze historical data to identify resource patterns and trends

```ai
Analyze the following historical project data to identify resource utilization patterns:

{{historical_data}}

Current team: {{current_team}}

Identify:
- Velocity trends over time (increasing, stable, decreasing)
- Capacity utilization patterns (are there consistent over- or under-utilization periods?)
- Skill demand patterns (which skills are consistently in high demand?)
- Seasonal or cyclical patterns in resource needs
- Correlation between team composition changes and velocity impact
- Areas where resource constraints have historically caused delays

Produce a trend analysis with key insights for forecasting.
```

2. Predict resource needs for upcoming sprints

```ai
Based on the historical analysis, forecast resource needs for upcoming sprints:

Historical analysis: {{historical_data}}
Upcoming sprints: {{upcoming_sprints}}
Current team: {{current_team}}

For each upcoming sprint:
- Predicted capacity needed (based on planned scope and historical velocity)
- Predicted capacity available (based on current team and known availability)
- Gap analysis (where demand exceeds supply)
- Skill-specific needs (are any specialized skills needed that the team lacks?)
- Risk factors that could affect the forecast (holidays, planned absences, dependencies)

Produce a resource forecast with confidence intervals where applicable.
```

3. Generate actionable resource allocation plans

```ai
Create a resource allocation plan based on the forecast:

Resource forecast: [from step 2]
Current team: {{current_team}}
Upcoming sprints: {{upcoming_sprints}}

For each identified gap or optimization opportunity:
- Recommended action (hire, contract, cross-train, redistribute, defer scope)
- Timeline for the action (when must it happen to be effective?)
- Cost implications
- Risk if the action is not taken
- Alternative approaches

Produce a prioritized action plan that can be reviewed and approved by project leadership.
```

## Output

- **resource_forecast** (data): Predicted resource needs with trend analysis and gap identification.
- **resource_plan** (data): Actionable resource allocation recommendations.

### Output Format

```markdown
## Resource Forecast

### Trend Analysis
- Average Velocity: X points/sprint (trend: [direction])
- Average Utilization: X% (target: Y%)
- Key Skill Demands: [list]

### Sprint Forecasts
| Sprint | Capacity Needed | Capacity Available | Gap | Key Risks |
|--------|-----------------|--------------------|----|-----------|
| ...    | ...             | ...                | ...| ...       |

### Resource Plan
| Action | Urgency | Cost | Impact if Skipped | Owner |
|--------|---------|------|-------------------|-------|
| ...    | ...     | ...  | ...               | ...   |

### Skill Gap Analysis
| Skill | Current Coverage | Demand Forecast | Recommendation |
|-------|------------------|-----------------|----------------|
| ...   | ...              | ...             | ...            |
```

## Routing

- related: ./sprint-planning.md
- related: ./procurement.md
- related: ./backlog-refinement.md
