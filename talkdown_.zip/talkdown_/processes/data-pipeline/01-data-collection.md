---
type: step
title: "Data Collection"
description: "Collect raw data on a given topic"
inputs:
  - name: topic
    type: text
    required: true
    description: "The subject area to collect data about"
outputs:
  - name: collected_data
    type: data
    description: "A structured list of relevant data points on the topic"
tags: [data-pipeline]
---

# Data Collection

Gather comprehensive data on the specified topic. This step produces a structured list of data points that will feed into the analysis stage.

## Inputs

- **topic** (text, required): The subject area to collect data about.

## Execution

```ai
Collect data on the topic: {{topic}}.

Generate a comprehensive list of relevant data points, findings, and developments related to {{topic}}. Make the list as thorough as possible, covering recent and significant items.
```

## Output

- A Markdown document containing the collected data under the heading `Collected Data`.

## Routing

- next: ./02-data-analysis.md
