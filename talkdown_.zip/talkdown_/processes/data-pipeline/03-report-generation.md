---
type: step
title: "Report Generation"
description: "Generate a summary report from the analysis"
inputs:
  - name: analysis
    type: data
    required: true
    description: "The impact analysis from the previous step"
outputs:
  - name: report
    type: file
    description: "A summary report file based on the analysis"
tags: [data-pipeline]
---

# Report Generation

Synthesize the analysis into a concise, well-structured summary report. This step produces the final deliverable document.

## Inputs

- **analysis** (data, required): The impact analysis from the previous step, listed under `Impact Analysis`.

## Execution

```ai
Create a summary report based on the impact analysis in the input document.

Structure the report with:
- An executive summary
- Key findings
- Detailed analysis
- Conclusions and recommendations

Save the summary report as `report.md`.
```

## Output

- A summary report file (`report.md`) containing the synthesized findings.

## Routing

- next: ./04-notification.md
