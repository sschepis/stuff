---
type: step
title: "Notification"
description: "Send a notification with the report results"
inputs:
  - name: report
    type: file
    required: true
    description: "The summary report file from the previous step"
outputs: []
tags: [data-pipeline]
---

# Notification

Deliver the final report to stakeholders. This is the terminal step in the pipeline.

## Inputs

- **report** (file, required): The summary report generated in the previous step.

## Execution

```ai
Read the summary report and present its contents as a notification to stakeholders.

Provide a brief overview of the key findings and indicate where the full report can be found.
```

## Output

- No file output. The notification is the final action in the pipeline.

## Routing

- next: none
