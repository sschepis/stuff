---
type: process
title: "Data Pipeline"
description: "Collects, analyzes, and reports on data, then sends a notification"
inputs:
  - name: topic
    type: text
    required: true
    description: "The subject area to collect data about"
outputs:
  - name: report
    type: file
    description: "A summary report of the analysis"
tags: [data-pipeline]
---

# Data Pipeline

A reusable pipeline that collects data on a given topic, analyzes it for impact, generates a summary report, and sends a notification with the results.

## Steps

| Step | File | Description |
|------|------|-------------|
| 01 | [01-data-collection.md](./01-data-collection.md) | Collect raw data on the topic |
| 02 | [02-data-analysis.md](./02-data-analysis.md) | Analyze the collected data for impact |
| 03 | [03-report-generation.md](./03-report-generation.md) | Generate a summary report |
| 04 | [04-notification.md](./04-notification.md) | Send a notification with the results |

## Flow

1. **Data Collection** gathers information on `{{topic}}` and produces a raw data document.
2. **Data Analysis** takes the raw data and evaluates its impact, producing an analysis document.
3. **Report Generation** synthesizes the analysis into a summary report file.
4. **Notification** delivers the final report to stakeholders.

## Routing

- next: ./01-data-collection.md
