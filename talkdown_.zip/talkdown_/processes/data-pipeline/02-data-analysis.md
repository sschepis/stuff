---
type: step
title: "Data Analysis"
description: "Analyze collected data for impact and significance"
inputs:
  - name: collected_data
    type: data
    required: true
    description: "The raw data collected in the previous step"
outputs:
  - name: analysis
    type: data
    description: "An impact analysis of the collected data"
tags: [data-pipeline]
---

# Data Analysis

Analyze the collected data to assess impact, significance, and key trends. This step transforms raw data points into actionable insights.

## Inputs

- **collected_data** (data, required): The structured data collected from the previous step, listed under `Collected Data`.

## Execution

```ai
Analyze the impact and significance of the data listed under `Collected Data` in the input document.

Identify key trends, assess relevance, and evaluate the potential impact of each item. Organize findings by significance.
```

## Output

- A Markdown document containing the results of the analysis under the heading `Impact Analysis`.

## Routing

- next: ./03-report-generation.md
